import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import maya.cmds as cmds
import maya.mel as mel


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class RetimingCmd(om.MPxCommand):

    COMMAND_NAME = "RetimingCmd"

    VALUE_FLAG = ["-v", "-value", om.MSyntax.kDouble]
    INCREMENTAL_FLAG = ["-i", "-incremental"]


    def __init__(self):
        super(RetimingCmd, self).__init__()

        self.anim_curve_change = oma.MAnimCurveChange()

        self.num_keys_updated = 0
        self.max_time = om.MTime(9999999, om.MTime.uiUnit())

    def doIt(self, arg_list):
        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        if arg_db.isFlagSet(RetimingCmd.VALUE_FLAG[0]):
            value = om.MTime(arg_db.flagArgumentDouble(RetimingCmd.VALUE_FLAG[0], 0), om.MTime.uiUnit())
            incremental = arg_db.isFlagSet(RetimingCmd.INCREMENTAL_FLAG[0])
            selection_list = arg_db.getObjectList()

            self.do_retiming(selection_list, value, incremental)
            self.setResult(self.num_keys_updated)

        else:
            raise RuntimeError("A value (-v) must be passed to the commmand")

    def undoIt(self):
        self.anim_curve_change.undoIt()

    def redoIt(self):
        self.anim_curve_change.redoIt()

    def isUndoable(self):
        return self.num_keys_updated > 0


    def do_retiming(self, selection_list, retime_value, incremental):
        range_start_time, range_end_time = self.get_selected_range()

        anim_curves = self.get_anim_curves(selection_list)
        for anim_curve in anim_curves:
            print(anim_curve.name())

    def calculate_retiming(self, anim_curve_fn, range_start_time, range_end_time, retime_value, incremental):
        """
        Return a list of tuples containing all keys that will be retimed on an anim curve
        Tuple format is (key_index, updated_time, original_time)
        """
        num_keys = anim_curve_fn.numKeys
        if num_keys == 0:
            return

        root_retime_key_index = self.find_closest_index(anim_curve_fn, range_start_time)
        if root_retime_key_index < 0:
            return

        last_retime_key_index = self.find_closest_index(anim_curve_fn, range_end_time)

        root_retime_key_time = anim_curve_fn.input(root_retime_key_index)
        key_data = [(root_retime_key_index, root_retime_key_time, root_retime_key_time)]



        return key_data


    def find_closest_index(self, anim_curve_fn, target_time):
        """
        Find closest index without going past the target time
        """
        index = anim_curve_fn.findClosest(target_time)
        closest_time = anim_curve_fn.input(index)
        if closest_time > target_time:
            index -= 1

        return index

    def get_anim_curves(self, selection_list):
        anim_curves = []

        sel_iter = om.MItSelectionList(selection_list)
        while not sel_iter.isDone():
            obj = sel_iter.getDependNode()
            depend_fn = om.MFnDependencyNode(obj)

            self.get_anim_curves_from_connections(depend_fn, anim_curves)

            sel_iter.next()

        return anim_curves

    def get_anim_curves_from_connections(self, depend_fn, anim_curves):
        plugs = depend_fn.getConnections()
        for plug in plugs:
            if plug.isKeyable and not plug.isLocked:
                dg_iter = om.MItDependencyGraph(plug, om.MFn.kAnimCurve, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kBreadthFirst, om.MItDependencyGraph.kNodeLevel)

                while not dg_iter.isDone():
                    if len(dg_iter.getNodePath()) > 2:
                        break

                    anim_curve_fn = oma.MFnAnimCurve(dg_iter.currentNode())
                    anim_curves.append(anim_curve_fn)

                    dg_iter.next()

    def get_selected_range(self):
        playback_slider = mel.eval("$tempVar = $gPlayBackSlider")
        start_frame, end_frame = cmds.timeControl(playback_slider, q=True, rangeArray=True)
        end_frame -= 1

        start_time = om.MTime(start_frame, om.MTime.uiUnit())
        end_time = om.MTime(end_frame, om.MTime.uiUnit())

        return [start_time, end_time]


    @classmethod
    def creator(cls):
        return RetimingCmd()

    @classmethod
    def create_syntax(cls):

        syntax = om.MSyntax()

        syntax.addFlag(*cls.VALUE_FLAG)
        syntax.addFlag(*cls.INCREMENTAL_FLAG)

        syntax.setObjectType(om.MSyntax.kSelectionList, 1)
        syntax.useSelectionAsDefault(True)

        return syntax


def initializePlugin(plugin):
    """
    """
    vendor = "Chris Zurbrigg"
    version = "1.0.0"

    plugin_fn = om.MFnPlugin(plugin, vendor, version)
    try:
        plugin_fn.registerCommand(RetimingCmd.COMMAND_NAME, RetimingCmd.creator, RetimingCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(RetimingCmd.COMMAND_NAME))


def uninitializePlugin(plugin):
    """
    """
    plugin_fn = om.MFnPlugin(plugin)
    try:
        plugin_fn.deregisterCommand(RetimingCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(RetimingCmd.COMMAND_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "retiming_cmd.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.polyCube(); cmds.setKeyframe(); cmds.currentTime(2); cmds.setKeyframe(); cmds.currentTime(3); cmds.setKeyframe(); cmds.currentTime(4); cmds.setKeyframe()')
