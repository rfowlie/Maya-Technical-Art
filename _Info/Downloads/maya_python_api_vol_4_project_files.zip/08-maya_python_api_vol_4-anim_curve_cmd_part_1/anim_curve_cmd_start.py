import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class AnimCurveCmd(om.MPxCommand):

    COMMAND_NAME = "AnimCurveCmd"

    CREATE_CURVE_FLAG = ["-cc", "createCurve"]
    DELETE_CURVE_FLAG = ["-dc", "deleteCurve"]
    SET_KEY_FLAG = ["-set", "-setKey"]
    REMOVE_KEY_FLAG = ["-rem", "-removeKey"]


    def __init__(self):
        super(AnimCurveCmd, self).__init__()

    def doIt(self, arg_list):

        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        selection_list = arg_db.getObjectList()

        self.selected_obj = selection_list.getDependNode(0)
        if self.selected_obj.apiType() != om.MFn.kTransform:
            raise RuntimeError("This command requires a transform node")

        raise RuntimeError("A valid flag is required")

    def undoIt(self):
        pass

    def redoIt(self):
        pass

    def isUndoable(self):
        return True


    @classmethod
    def creator(cls):
        return AnimCurveCmd()

    @classmethod
    def create_syntax(cls):

        syntax = om.MSyntax()

        syntax.addFlag(*cls.CREATE_CURVE_FLAG)
        syntax.addFlag(*cls.DELETE_CURVE_FLAG)
        syntax.addFlag(*cls.SET_KEY_FLAG)
        syntax.addFlag(*cls.REMOVE_KEY_FLAG)

        syntax.setObjectType(om.MSyntax.kSelectionList, 1, 1)
        syntax.useSelectionAsDefault(True)

        return syntax



def initializePlugin(plugin):
    """
    """
    vendor = "Chris Zurbrigg"
    version = "1.0.0"

    plugin_fn = om.MFnPlugin(plugin, vendor, version)
    try:
        plugin_fn.registerCommand(AnimCurveCmd.COMMAND_NAME, AnimCurveCmd.creator, AnimCurveCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(AnimCurveCmd.COMMAND_NAME))


def uninitializePlugin(plugin):
    """
    """
    plugin_fn = om.MFnPlugin(plugin)
    try:
        plugin_fn.deregisterCommand(AnimCurveCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(AnimCurveCmd.COMMAND_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "anim_curve_cmd.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.polyCube()')
