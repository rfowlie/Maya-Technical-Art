import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class AnimCurveCmd(om.MPxCommand):

    COMMAND_NAME = "AnimCurveCmd"

    CREATE_CURVE_FLAG = ["-cc", "createCurve"]
    DELETE_CURVE_FLAG = ["-dc", "deleteCurve"]
    SET_KEY_FLAG = ["-set", "-setKey"]
    REMOVE_KEY_FLAG = ["-rem", "-removeKey"]


    def __init__(self):
        super(AnimCurveCmd, self).__init__()

    def doIt(self, arg_list):

        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        selection_list = arg_db.getObjectList()

        self.selected_obj = selection_list.getDependNode(0)
        if self.selected_obj.apiType() != om.MFn.kTransform:
            raise RuntimeError("This command requires a transform node")

        create_curve_flag = arg_db.isFlagSet(AnimCurveCmd.CREATE_CURVE_FLAG[0])

        attrs = ["tx", "ty", "tz"]

        self.selected_obj = selection_list.getDependNode(0)
        if self.selected_obj.apiType() != om.MFn.kTransform:
            raise RuntimeError("This command requires a transform node")

        if create_curve_flag:
            if not self.create_anim_curves(self.selected_obj, attrs):
                raise RuntimeError("No anim curves were created")
        else:
            raise RuntimeError("A valid flag is required")

    def undoIt(self):
        pass

    def redoIt(self):
        pass

    def isUndoable(self):
        return True

    def create_anim_curves(self, obj, attrs):
        for attr in attrs:
            plug = self.find_plug(obj, attr)
            if not plug or plug.isConnected:
                continue

            anim_curve_fn = oma.MFnAnimCurve()

            try:
                anim_curve_fn.create(plug, oma.MFnAnimCurve.kAnimCurveUnknown)
            except:
                continue

        return True

    def find_plug(self, obj, attr):
        depend_fn = om.MFnDependencyNode(obj)
        try:
            plug = depend_fn.findPlug(attr, False)
        except:
            om.MGlobal.displayWarning("Attribute not found: {0}.{1}".format(depend_fn.name(), attr))
            return None

        return plug


    @classmethod
    def creator(cls):
        return AnimCurveCmd()

    @classmethod
    def create_syntax(cls):

        syntax = om.MSyntax()

        syntax.addFlag(*cls.CREATE_CURVE_FLAG)
        syntax.addFlag(*cls.DELETE_CURVE_FLAG)
        syntax.addFlag(*cls.SET_KEY_FLAG)
        syntax.addFlag(*cls.REMOVE_KEY_FLAG)

        syntax.setObjectType(om.MSyntax.kSelectionList, 1, 1)
        syntax.useSelectionAsDefault(True)

        return syntax



def initializePlugin(plugin):
    """
    """
    vendor = "Chris Zurbrigg"
    version = "1.0.0"

    plugin_fn = om.MFnPlugin(plugin, vendor, version)
    try:
        plugin_fn.registerCommand(AnimCurveCmd.COMMAND_NAME, AnimCurveCmd.creator, AnimCurveCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(AnimCurveCmd.COMMAND_NAME))


def uninitializePlugin(plugin):
    """
    """
    plugin_fn = om.MFnPlugin(plugin)
    try:
        plugin_fn.deregisterCommand(AnimCurveCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(AnimCurveCmd.COMMAND_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "anim_curve_cmd.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.polyCube()')
