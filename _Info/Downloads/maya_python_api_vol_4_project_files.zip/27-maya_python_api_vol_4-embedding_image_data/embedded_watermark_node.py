from PySide2 import QtCore
from PySide2 import QtGui

import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr  # pylint: disable=E0001,E0611
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class WatermarkNode(omui.MPxLocatorNode):

    TYPE_NAME = "watermarknode"
    TYPE_ID = om.MTypeId(0x0007F7FA)
    DRAW_CLASSIFICATION = "drawdb/geometry/watermark"
    DRAW_REGISTRANT_ID = "WatermarkNode"


    def __init__(self):
        super(WatermarkNode, self).__init__()

    @classmethod
    def creator(cls):
        return WatermarkNode()

    @classmethod
    def initialize(cls):
        pass


class WatermarkDrawOverride(omr.MPxDrawOverride):

    NAME = "WatermarkDrawOverride"


    def __init__(self, obj):
        super(WatermarkDrawOverride, self).__init__(obj, None)

        self.image_hex_str = "89504e470d0a1a0a0000000d49484452000000a00000002108060000005e23a050000000097048597300000b1300000b1301009a9c1800000b4749444154789ced9c5990165715c77fdf2ccc302bc33210306c6109a04270123590c454a231d1485cb0e29254a9a565f910b5ca2a1f7cf2c147b7b27029b52c4b2b51630c120c920562302c154c889190143b093b03619b018699cf87ffbdf4edfe6e77df9e199c07bf7f5517ddfd759fbecbb9e7fccfb9672895cb65aaa862a45033d20da8e2ff1b5505ac62445155c02a46145505ac62445197f56357d795d3514013d01f28b76c64d701dde6daca190d94800be6c84303d068ce7b80bec4ef7540333090b87f11b814d85e50ff4611f571c0c8b85c404603ea9f3b4e0340afa77d69a8015acc793fea739148b10d980e4c427dba081c070e00c70ac849432d300d98028c31f7de060e996f24e7e70ab66eadbc97a9800e2603d7a1810c4523700a29a0c5b5e6a805de02dec89151026603e3ccf92ef39e8b36e0dda8e365f31cc079e0307034b0bdd7019da88f2523eb347024d1872cd889b18a5f428ad76dda722640460bb0c89c5f02b611b650015a8185c0f548011b8d8c6e6002f00a5294a160b6f9c634f33d80b3c09ba6edaf12bed88215f0566049781bafe00fc457ef5da8f100db819d64377614f059a480006ba854c019c0673cef96d1849f01fe053c4bba45ac07ee4583eae2321adc6e602df0ef8cb6027c1498ebb9df8794f930f01cf09f0c195380cf99f301f3cefe9cefb69b6fcf438a96c464e05dc01dc84a3d01eccd9199c412e003c03568bc5c74a2057cab69ef0ba89fb91e33540147073ee7620fb02971cf558032f9ae6520f18eaf4369324a6862da91d59d07fc122954a88c3aa0c31c3381556811a4214bc1c79b633ef024b03ae559b72d211cfdbdc07dc0d880675b8105c88a3d8514310fedc0034881f3508316d0a79115ff2d7022eb855005dc8b3ae8b356fd6885bf03b94390e5f80b95aec39da054aee0a08c388c858f8f9513e76f2137da84ac4183f96d2ef025e0c7542a5c39d19eb78183885b4e4696b8064df421e4ca7c70db7adec8a841133fd1dcaf45d6f604b0d923c31de33eb23dc45dc02712f78ea1c57f188d7f1db250d3892cfc286431db818733be3101f81a1a03b74dafa3713e83c6ae0dcdfff54636c01ce0ebc00a4463bc0855c0a780f5542a80e538adc0779cfb2f21f73a1c28e53f7205bd48c1ce22ab3d19b985f799dfe7014b810d397236027f45ca3203f824b280a0894b5340b7ad5bd1e482267a16b08c4811ef4334c4679143701371e5bb00ac045e460b28897ae046f3dd7673ef16b4681ef53c3f06780829afc5cb88caa4cded2ce01e646531ef3e047c0f2dc80a1449c35892ef1e76e57c08b929cc875616903bdcb06eba17d80dfc8638777b4f800cbbd0fa51e0f30891359f88567b1e5c2b7b1af1d01544815c077285834127f079e7ba1bf81132123ee503cddf46b4406d60b69f7465ba97b8f2ad067e9ef13c68ac5600cf3bf75e242393106a01b3301929a0c566c2a3c6e14609b9de9ec4fd4d285206ad7e1be5a621392ec7809344eeb893ca60288906cfbda3c03e6489c11f3084e0fd8efc32b2b4a141c541e08f46c663285391c45422af01b08530be085ab40f2385df8d165e2a8643013fee9c9f05fe360c3287029f62b9fcae0eb9d622f9bd7a226e93e4a545da01715e9c8c2643d0815ca7c516b2a36a1fb69b230d3711e9c65944478aa00cfc29e4c1a1ee842c26b22ca0c0c3ebebff87f071c659cef939f2952f49ca671245996790151b0cea503060717a1032dcfc1b889f0f2746137138107db96a1e6d2816b006f89873bd07718c91c4009593ba10b8ddb9cecba9b9a8459cf153a8bf65601d618b2c99b4af41bcadc3b977a0405b2c5cde7880a12796939888727da0f17c6998e5c7301405bc9da8a130f2ae17d49f8588d7740037a07c94ed673ff0cf0039b7222bd0827277d6aaae4209e9104c44c9d91a14b42c41f9488b2d1457c01ae229913d14dba60b81dbdf3ef2b9ee903058056c4659758b5729ce43ae061a802f67fcfe7bc206b48d28a7e9e25ae06614d4e44dfc3bcde1c37114550e4679dc390b49e1cc4754296d576214da12b5394997979e257ffbb50da55e6acd379214a80e45e67bf0f0cec12ae00789b6c72e131e218d140ea01d8ca1ba93c5e698497602370d9711a77a1445d54345488e7426f1a0c5874bf893e2b501df68264e717ce84681dbb028602770a773bd8962bcea6ae202e267e39c7bab11510f895c2d36a36475094d4207da079d6e7ebf05e5bc7c9366d18dac8b0d184e01bf666809fa3271fe393ee09d9045e27a05577e0bb27059c5102156fc24290b6e300ab88cc84cf750ccfab9ab29642fd83ee77bdf87732821fb20da0a02f1af22ca0722f6bb12f7b6015f45db4da0559f55a9b20e5193efa276b710ed400c1665b4d86f30d7b3102fcc52b2d7886f355e420bea4eb440cac4f3a647cdb3f5e698497619d7199472a9432eb88cc66429d1ee510f2909f2a2699839409773bd8662a904f77b25f215cad615baef64a109f1abc789266511da1c2f8246cfbd5e148058b953f0f3448bb16832ff61aeeb812f124fc30c066ec2791cd18248c33e344fcf98e379b44d68c7f2222aa5b238493c38cadb39ea41db736b8dfc6751358cab70474851e2220a5842e9080b5b5a5404e79cf376f213b1b5c42739af9eae064dca1ee0efcefd3b886aec86826e22326f2d441a9acdbf8f116d7dd5a220a9d5fb46180e38f24ac0470621e336a2b6270b55fb90e5b6988ba2f9229841543dd3877643bc015311055c4abc5e6e25c52a8e219eb39a4a3c8de343177105cc4b5bb805a94f125fd90f10e78679727c98446491ddbd701fec6f9780df39d7e3a9ac6029821ee4de2d6c01402816a13493c57acf331b89b6e81a10a569f13ce74323aacfb40abe17d106ef98862a6003f1b4cb26c47f8ae235223e56072c27bdd6b09378a23b34e96a3bda87ead1ecae470b2af40c891c7d9cb105591bfbfe09e2163d0b3b81a79deb9b5165ca60b181b82b5e86385dde7c2e4434c0f66117fe793c4d5c312799f7f2386c33f00522435546b9d354840621b71159ab3232d933912b49b3163548615cf37e0a25acad05988d6ac656216b7511f1b8a9c0fdc4770dd6105643e8e24dc407979beb05c0ddc83a66612ab22c8de6988036ef273acf6ca05829d54a9493b3c9e8fb113f3b5e4086453f72eddf209ac3e588a3bf800a0ece23ab3b0af1d11b9111b14ada872ad6d3acf85a343fd6952e00be8538ed0ea4a47d8856b422b7fb612a372732a3fe10056c33822dca68c52d0b78773deaa48b6710115f6cae6720253c882c4a07f13220109f0bc9e1f916c37ab45f6d4be5ef41f9283775947caf8b78b095c40efc3585c9e25817032811fe6da23f3c7a10f87e860cdfb5c54ee0a7c0578882a685e63883f8ea65a2a25a17bdc0cf8853141f7e850a52edd87522451f40c6a587a83aa829f1ee73046448f24c7613dabf6c76ee15e18dbe67fb51697c7202a7a08efa94eff18c6fd43ae7a33ddfec47aed846ebf5c037894f4a2d51b54b1e3600bfa0b2e40be23cc9578eb50f156c58cc41aecd856b14eac93612db811f50a9486d6861cfa652f95e474a9ff70761a074ca4fa8e489767b710e32264d8977fe8c6a2873916701a799e310c5b3fef5a497625b6bb01d0537738947941751d5f13af2ebdcce21376fff84d1e7a6bb91cbbadb7cbb1359b8278882894368a1b95b4fb6e2fb288aac7790cd430f22775747fa5fe33d8ddcd45cd3e6f96812f799df7bcdbb0368327d8aee623ff043a2e0628af9bee57956ce1b281a7d8562c1a375d5db100d5980c6c92ef432b2b4478cfc17c9f93b1017a5acff9ca8ab8bb148bb2f517cdfb206b982bcbdc426c4b73a91d5b888267237610365398e1d8853a42f96f1a65db626f0a0f3ec186441dd52ad92b93e17d89656343925c40fd3829406d3e67ef3cdf34493564f54fa95d79f243a10c71c67e40e98361c455632f4cf3bd3506fe45f83ac7d2d9aaf936821646e2ffafe2e385301aba8e26aa3fa5f735431a2a82a6015238aff026c53b38cd2309a840000000049454e44ae426082"
        self.texture = None

        self.update_texture_by_hex_str()

    def __del__(self):
        self.release_texture()

    def release_texture(self):
        if self.texture:
            texture_manager = omr.MRenderer.getTextureManager()
            texture_manager.releaseTexture(self.texture)
            self.texture = None

    def update_texture_by_hex_str(self):
        if self.image_hex_str:
            qimage = QtGui.QImage()

            ba = QtCore.QByteArray(bytearray.fromhex(self.image_hex_str))
            buffer = QtCore.QBuffer(ba)
            if buffer.open(QtCore.QIODevice.ReadOnly):
                qimage.load(buffer, "PNG")
                qimage = qimage.convertToFormat(QtGui.QImage.Format_RGBA8888)
            else:
                om.MGlobal.displayError("Failed to load image data")
                return

            texture_manager = omr.MRenderer.getTextureManager()

            texture_desc = omr.MTextureDescription()
            texture_desc.setToDefault2DTexture()
            texture_desc.fWidth = qimage.width()
            texture_desc.fHeight = qimage.height()

            image_bytes = qimage.constBits().tobytes()

            self.texture = texture_manager.acquireTexture("", texture_desc, image_bytes, False)

            if not self.texture:
                om.MGlobal.displayError("Unsupported image data")

    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):
        self.vp_width = frame_context.getViewportDimensions()[2]

        if self.texture:
            texture_desc = self.texture.textureDescription()
            self.half_width = 0.5 * texture_desc.fWidth
            self.half_height = 0.5 * texture_desc.fHeight

    def supportedDrawAPIs(self):
        return (omr.MRenderer.kAllDevices)

    def hasUIDrawables(self):
        return True

    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        draw_manager.beginDrawable()

        if self.texture:
            draw_manager.setTexture(self.texture)
            draw_manager.setTextureSampler(omr.MSamplerState.kMinMagMipLinear, omr.MSamplerState.kTexClamp)
            draw_manager.setTextureMask(omr.MBlendState.kRGBAChannels)
            draw_manager.setColor(om.MColor((1.0, 1.0, 1.0, 1.0)))

            rect_center = om.MPoint(self.vp_width - (50 + self.half_width), 50 + self.half_height)
            draw_manager.rect2d(rect_center, om.MVector(0.0, 1.0, 0.0), self.half_width, self.half_height, True)

        draw_manager.endDrawable()

    @classmethod
    def creator(cls, obj):
        return WatermarkDrawOverride(obj)


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)

    try:
        plugin_fn.registerNode(WatermarkNode.TYPE_NAME,              # name of the node
                               WatermarkNode.TYPE_ID,                # unique id that identifies node
                               WatermarkNode.creator,                # function/method that returns new instance of class
                               WatermarkNode.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode,              # type of node to be registered
                               WatermarkNode.DRAW_CLASSIFICATION)    # draw-specific classification string (VP2.0)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(WatermarkNode.TYPE_NAME))

    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(WatermarkNode.DRAW_CLASSIFICATION,     # draw-specific classification
                                                      WatermarkNode.DRAW_REGISTRANT_ID,      # unique name to identify registration
                                                      WatermarkDrawOverride.creator)         # function/method that returns new instance of class
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(WatermarkDrawOverride.NAME))


def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)
    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(WatermarkNode.DRAW_CLASSIFICATION, WatermarkNode.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(WatermarkDrawOverride.NAME))

    try:
        plugin_fn.deregisterNode(WatermarkNode.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(WatermarkNode.TYPE_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "embedded_watermark_node.py"

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.createNode("watermarknode")')

