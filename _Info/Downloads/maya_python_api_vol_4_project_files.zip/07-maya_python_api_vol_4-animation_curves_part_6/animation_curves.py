import traceback

import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma


def get_current_time():
    return oma.MAnimControl.currentTime()

def set_value(anim_curve_fn, index, value):
    anim_curve_fn.setValue(index, value)

def set_time(anim_curve_fn, index, time):
    anim_curve_fn.setInput(index, time)

def add_key(obj, attr_name):
    current_time = get_current_time()

    anim_curve_fn = get_anim_curve(obj, attr_name)
    if not anim_curve_fn:
        anim_curve_fn = create_anim_curve(obj, attr_name)
        if not anim_curve_fn:
            return None

    index = anim_curve_fn.find(current_time)
    if index is None:
        return anim_curve_fn.insertKey(current_time)

    return None

def remove_key(obj, attr_name):
    anim_curve_fn = get_anim_curve(obj, attr_name)
    if not anim_curve_fn:
        return

    index = anim_curve_fn.find(get_current_time())
    if not index is None:
        anim_curve_fn.remove(index)

def create_anim_curve(obj, attr_name):
    plug = find_plug(obj, attr_name)
    if not plug or plug.isConnected:
        return None

    anim_curve_fn = oma.MFnAnimCurve()

    try:
        anim_curve_fn.create(plug, oma.MFnAnimCurve.kAnimCurveUnknown)
    except:
        traceback.print_exc()
        return None

    return anim_curve_fn

def get_anim_curve(obj, attr_name):
    plug = find_plug(obj, attr_name)
    if not plug:
        return None

    source_plug = plug.source()
    anim_curve_fn = oma.MFnAnimCurve()

    if anim_curve_fn.hasObj(source_plug.node()):
        anim_curve_fn.setObject(source_plug.node())
        return anim_curve_fn

    return None

def find_plug(obj, attr_name):
    depend_fn = om.MFnDependencyNode(obj)
    try:
        plug = depend_fn.findPlug(attr_name, False)
    except:
        om.MGlobal.displayWarning("Attribute not found: {0}.{1}".format(depend_fn.name(), attr_name))
        return None

    return plug

def display_anim_curve_info(anim_curve_fn):
    print("Num Keys: {0}".format(anim_curve_fn.numKeys))
    print("Static: {0}".format(anim_curve_fn.isStatic))
    print("Pre Infinity Type: {0}".format(anim_curve_fn.preInfinityType))
    print("Post Infinity Type: {0}".format(anim_curve_fn.postInfinityType))

    print("--- KEYS ---")

    for index in range(anim_curve_fn.numKeys):
        display_key_info(anim_curve_fn, index)

def display_key_info(anim_curve_fn, index):
    time = anim_curve_fn.input(index).value
    value = anim_curve_fn.value(index)
    breakdown = anim_curve_fn.isBreakdown(index)
    tangents_locked = anim_curve_fn.tangentsLocked(index)
    in_tangent_type = anim_curve_fn.inTangentType(index)
    in_tangent_values = anim_curve_fn.getTangentXY(index, True)
    out_tangent_type = anim_curve_fn.outTangentType(index)
    out_tangent_values = anim_curve_fn.getTangentXY(index, False)

    output = "[{0}] Time: {1}\tValue: {2}\t".format(index, time, value)
    output += "Breakdown: {0}\n\t\tTangents Locked: {1}\t".format(breakdown, tangents_locked)
    output += "In Tangent: {0} {1}\t".format(in_tangent_type, in_tangent_values)
    output += "Out Tangent: {0} {1}".format(out_tangent_type, out_tangent_values)

    print(output)



if __name__ == "__main__":
    selection = om.MGlobal.getActiveSelectionList()
    if selection.length() > 0:
        obj = selection.getDependNode(0)

        anim_curve_fn = get_anim_curve(obj, "translateY")
        if anim_curve_fn:
            display_anim_curve_info(anim_curve_fn)

    else:
        om.MGlobal.displayError("An object is not selected")








