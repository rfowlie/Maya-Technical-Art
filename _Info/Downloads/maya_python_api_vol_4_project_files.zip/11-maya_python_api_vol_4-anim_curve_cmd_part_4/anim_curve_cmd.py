import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class AnimCurveCmd(om.MPxCommand):

    COMMAND_NAME = "AnimCurveCmd"

    CREATE_CURVE_FLAG = ["-cc", "createCurve"]
    DELETE_CURVE_FLAG = ["-dc", "deleteCurve"]
    SET_KEY_FLAG = ["-set", "-setKey"]
    REMOVE_KEY_FLAG = ["-rem", "-removeKey"]


    def __init__(self):
        super(AnimCurveCmd, self).__init__()

        self.dg_modifier = om.MDGModifier()
        self.dg_changed = False

        self.anim_curve_change = oma.MAnimCurveChange()
        self.anim_modified = False

    def doIt(self, arg_list):

        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        selection_list = arg_db.getObjectList()

        self.selected_obj = selection_list.getDependNode(0)
        if self.selected_obj.apiType() != om.MFn.kTransform:
            raise RuntimeError("This command requires a transform node")

        create_curve_flag = arg_db.isFlagSet(AnimCurveCmd.CREATE_CURVE_FLAG[0])
        delete_curve_flag = arg_db.isFlagSet(AnimCurveCmd.DELETE_CURVE_FLAG[0])
        set_key_flag = arg_db.isFlagSet(AnimCurveCmd.SET_KEY_FLAG[0])

        attrs = ["tx", "ty", "tz"]

        self.selected_obj = selection_list.getDependNode(0)
        if self.selected_obj.apiType() != om.MFn.kTransform:
            raise RuntimeError("This command requires a transform node")

        if create_curve_flag:
            if not self.create_anim_curves(self.selected_obj, attrs):
                raise RuntimeError("No anim curves were created")
        elif delete_curve_flag:
            if not self.delete_anim_curves(self.selected_obj, attrs):
                raise RuntimeError("No anim curves were deleted")
        elif set_key_flag:
            if not self.set_key(self.selected_obj, attrs):
                raise RuntimeError("No keys were set")
        else:
            raise RuntimeError("A valid flag is required")

    def undoIt(self):
        if self.dg_changed:
            self.dg_modifier.undoIt()

        if self.anim_modified:
            self.anim_curve_change.undoIt()

    def redoIt(self):
        if self.dg_changed:
            self.dg_modifier.doIt()

        if self.anim_modified:
            self.anim_curve_change.redoIt()

    def isUndoable(self):
        return True

    def create_anim_curves(self, obj, attrs):
        for attr in attrs:
            plug = self.find_plug(obj, attr)
            if not plug or plug.isConnected:
                continue

            anim_curve_fn = oma.MFnAnimCurve()

            try:
                anim_curve_fn.create(plug, oma.MFnAnimCurve.kAnimCurveUnknown, self.dg_modifier)
                self.dg_changed = True
            except:
                continue

        return self.dg_changed

    def delete_anim_curves(self, obj, attrs):
        for attr in attrs:
            anim_curve_fn = self.get_anim_curve(obj, attr)
            if not anim_curve_fn:
                continue

            self.dg_modifier.deleteNode(anim_curve_fn.object())
            self.dg_changed = True

        if self.dg_changed:
            self.dg_modifier.doIt()

        return self.dg_changed

    def set_key(self, obj, attrs):
        current_time = self.get_current_time()

        for attr in attrs:
            value = self.get_attribute_value(obj, attr)
            if value is None:
                continue

            anim_curve_fn = self.get_anim_curve(obj, attr)
            if not anim_curve_fn:
                continue

            index = anim_curve_fn.find(current_time)
            if index is None:
                anim_curve_fn.addKey(current_time, value, change=self.anim_curve_change)
            else:
                anim_curve_fn.setValue(index, value, change=self.anim_curve_change)

            self.anim_modified = True

        return self.anim_modified

    def find_plug(self, obj, attr):
        depend_fn = om.MFnDependencyNode(obj)
        try:
            plug = depend_fn.findPlug(attr, False)
        except:
            om.MGlobal.displayWarning("Attribute not found: {0}.{1}".format(depend_fn.name(), attr))
            return None

        return plug

    def get_anim_curve(self, obj, attr):
        plug = self.find_plug(obj, attr)
        if not plug:
            return None

        source_plug = plug.source()
        anim_curve_fn = oma.MFnAnimCurve()

        if anim_curve_fn.hasObj(source_plug.node()):
            anim_curve_fn.setObject(source_plug.node())
            return anim_curve_fn

        return None

    def get_current_time(self):
        return oma.MAnimControl.currentTime()

    def get_attribute_value(self, obj, attr):
        plug = self.find_plug(obj, attr)
        if plug:
            return plug.asDouble()

        return None


    @classmethod
    def creator(cls):
        return AnimCurveCmd()

    @classmethod
    def create_syntax(cls):

        syntax = om.MSyntax()

        syntax.addFlag(*cls.CREATE_CURVE_FLAG)
        syntax.addFlag(*cls.DELETE_CURVE_FLAG)
        syntax.addFlag(*cls.SET_KEY_FLAG)
        syntax.addFlag(*cls.REMOVE_KEY_FLAG)

        syntax.setObjectType(om.MSyntax.kSelectionList, 1, 1)
        syntax.useSelectionAsDefault(True)

        return syntax



def initializePlugin(plugin):
    """
    """
    vendor = "Chris Zurbrigg"
    version = "1.0.0"

    plugin_fn = om.MFnPlugin(plugin, vendor, version)
    try:
        plugin_fn.registerCommand(AnimCurveCmd.COMMAND_NAME, AnimCurveCmd.creator, AnimCurveCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(AnimCurveCmd.COMMAND_NAME))


def uninitializePlugin(plugin):
    """
    """
    plugin_fn = om.MFnPlugin(plugin)
    try:
        plugin_fn.deregisterCommand(AnimCurveCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(AnimCurveCmd.COMMAND_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "anim_curve_cmd.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.polyCube()')
