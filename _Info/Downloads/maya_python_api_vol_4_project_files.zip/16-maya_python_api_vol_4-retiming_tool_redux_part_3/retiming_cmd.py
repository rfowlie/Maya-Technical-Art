import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import maya.cmds as cmds
import maya.mel as mel


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class RetimingCmd(om.MPxCommand):

    COMMAND_NAME = "RetimingCmd"

    VALUE_FLAG = ["-v", "-value", om.MSyntax.kDouble]
    INCREMENTAL_FLAG = ["-i", "-incremental"]


    def __init__(self):
        super(RetimingCmd, self).__init__()

        self.anim_curve_change = oma.MAnimCurveChange()

        self.num_keys_updated = 0
        self.max_time = om.MTime(9999999, om.MTime.uiUnit())

    def doIt(self, arg_list):
        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        if arg_db.isFlagSet(RetimingCmd.VALUE_FLAG[0]):
            value = om.MTime(arg_db.flagArgumentDouble(RetimingCmd.VALUE_FLAG[0], 0), om.MTime.uiUnit())
            incremental = arg_db.isFlagSet(RetimingCmd.INCREMENTAL_FLAG[0])
            selection_list = arg_db.getObjectList()

            self.do_retiming(selection_list, value, incremental)
            self.setResult(self.num_keys_updated)

        else:
            raise RuntimeError("A value (-v) must be passed to the commmand")

    def undoIt(self):
        self.anim_curve_change.undoIt()

    def redoIt(self):
        self.anim_curve_change.redoIt()

    def isUndoable(self):
        return self.num_keys_updated > 0

    def do_retiming(self, selection_list, retime_value, incremental):
        pass


    @classmethod
    def creator(cls):
        return RetimingCmd()

    @classmethod
    def create_syntax(cls):

        syntax = om.MSyntax()

        syntax.addFlag(*cls.VALUE_FLAG)
        syntax.addFlag(*cls.INCREMENTAL_FLAG)

        syntax.setObjectType(om.MSyntax.kSelectionList, 1)
        syntax.useSelectionAsDefault(True)

        return syntax


def initializePlugin(plugin):
    """
    """
    vendor = "Chris Zurbrigg"
    version = "1.0.0"

    plugin_fn = om.MFnPlugin(plugin, vendor, version)
    try:
        plugin_fn.registerCommand(RetimingCmd.COMMAND_NAME, RetimingCmd.creator, RetimingCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(RetimingCmd.COMMAND_NAME))


def uninitializePlugin(plugin):
    """
    """
    plugin_fn = om.MFnPlugin(plugin)
    try:
        plugin_fn.deregisterCommand(RetimingCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(RetimingCmd.COMMAND_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "retiming_cmd.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.polyCube(); cmds.setKeyframe(); cmds.currentTime(2); cmds.setKeyframe(); cmds.currentTime(3); cmds.setKeyframe(); cmds.currentTime(4); cmds.setKeyframe()')
