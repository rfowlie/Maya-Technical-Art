from PySide2 import QtCore
from PySide2 import QtGui

import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr  # pylint: disable=E0001,E0611
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class WatermarkCmd(om.MPxCommand):

    COMMAND_NAME = "watermark"

    def __init__(self):
        super(WatermarkCmd, self).__init__()

    def doIt(self, arg_list):
        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        try:
            file_path = arg_db.commandArgumentString(0)
        except:
            self.displayError("Expected a file path argument")
            raise

        self.dag_modifier = om.MDagModifier()

        transform_obj = self.dag_modifier.createNode("transform", om.MObject.kNullObj)
        self.dag_modifier.renameNode(transform_obj, "watermark")

        shape_obj = self.dag_modifier.createNode(WatermarkNode.TYPE_ID, transform_obj)
        self.dag_modifier.renameNode(shape_obj, "watermarkShape")

        depend_fn = om.MFnDependencyNode(shape_obj)
        self.node = depend_fn.userNode()

        self.node.set_image_from_path(file_path)

        self.redoIt()

    def undoIt(self):
        self.dag_modifier.undoIt()

    def redoIt(self):
        self.dag_modifier.doIt()

    def isUndoable(self):
        return True

    @classmethod
    def creator(cls):
        return WatermarkCmd()

    @classmethod
    def create_syntax(cls):
        syntax = om.MSyntax()
        syntax.addArg(om.MSyntax.kString)

        return syntax


class WatermarkData(om.MPxData):

    TYPE_NAME = "watermarkdata"
    TYPE_ID = om.MTypeId(0x0007F7FB)

    BYTE_ORDER = "little"


    def __init__(self):
        super(WatermarkData, self).__init__()

        self._image = QtGui.QImage()

    def get_image(self):
        return self._image

    def set_image(self, new_image):
        self._image = new_image

    def copy(self, src):
        """
        Must be implemented in the derived class
        """
        self._image = src._image

    def name(self):
        """
        Must be implemented in the derived class
        """
        return WatermarkData.TYPE_NAME

    def typeId(self):
        """
        Must be implemented in the derived class
        """
        return WatermarkData.TYPE_ID

    def writeASCII(self):
        args_str = ""

        args_str += str(self._image.width())
        args_str += " "
        args_str += str(self._image.height())
        args_str += " "

        ba = QtCore.QByteArray()
        buffer = QtCore.QBuffer(ba)
        buffer.open(QtCore.QIODevice.WriteOnly)
        if self._image.save(buffer, "PNG"):
            args_str += '"{0}"'.format(ba.toHex().data().decode())
        else:
            args_str += '""'

        return args_str

    def readASCII(self, args, endOfTheLastParsedElement):

        width = args.asInt(endOfTheLastParsedElement)
        endOfTheLastParsedElement += 1
        height = args.asInt(endOfTheLastParsedElement)
        endOfTheLastParsedElement += 1
        print("Image Resolution: {0}x{1}".format(width, height))

        image_str = args.asString(endOfTheLastParsedElement)
        endOfTheLastParsedElement += 1

        ba = QtCore.QByteArray(bytearray.fromhex(image_str))
        buffer = QtCore.QBuffer(ba)
        if buffer.open(QtCore.QIODevice.ReadOnly):
            self._image.load(buffer, "PNG")
            self._image.convertTo(QtGui.QImage.Format_RGBA8888)
        else:
            print("Failed to load image data")

        return endOfTheLastParsedElement

    def writeBinary(self):
        py_ba = bytearray()

        py_ba += self._image.width().to_bytes(2, WatermarkData.BYTE_ORDER)
        py_ba += self._image.height().to_bytes(2, WatermarkData.BYTE_ORDER)

        ba = QtCore.QByteArray()
        buffer = QtCore.QBuffer(ba)
        buffer.open(QtCore.QIODevice.WriteOnly)
        if self._image.save(buffer, "PNG"):
            py_ba += bytearray(ba)

        return py_ba

    def readBinary(self, data, data_size):
        index = 0

        width = int.from_bytes(data[index:index+2], WatermarkData.BYTE_ORDER)
        index += 2
        height = int.from_bytes(data[index:index+2], WatermarkData.BYTE_ORDER)
        index += 2
        print("Image Resolution: {0}x{1}".format(width, height))

        ba = QtCore.QByteArray(data[index:])
        buffer = QtCore.QBuffer(ba)
        if buffer.open(QtCore.QIODevice.ReadOnly):
            self._image.load(buffer, "PNG")
            self._image.convertTo(QtGui.QImage.Format_RGBA8888)

        return data_size

    @classmethod
    def creator(cls):
        return WatermarkData()


class WatermarkNode(omui.MPxLocatorNode):

    TYPE_NAME = "watermarknode"
    TYPE_ID = om.MTypeId(0x0007F7FA)
    DRAW_CLASSIFICATION = "drawdb/geometry/watermark"
    DRAW_REGISTRANT_ID = "WatermarkNode"

    image_data_obj = None


    def __init__(self):
        super(WatermarkNode, self).__init__()

    def get_image(self):
        plug = om.MPlug(self.thisMObject(), self.image_data_obj)
        data_handle = plug.asMDataHandle()
        data = data_handle.asPluginData()
        qimage = data.get_image()
        plug.destructHandle(data_handle)

        return qimage

    def set_image_from_path(self, path):
        qimage = QtGui.QImage(path)
        self.set_image(qimage)

    def set_image(self, qimage):
        formatted_image = qimage.convertToFormat(QtGui.QImage.Format_RGBA8888)

        data = WatermarkData()
        data.set_image(formatted_image)

        plug = om.MPlug(self.thisMObject(), WatermarkNode.image_data_obj)
        plug.setMPxData(data)

    @classmethod
    def creator(cls):
        return WatermarkNode()

    @classmethod
    def initialize(cls):
        typed_attr = om.MFnTypedAttribute()

        default_image_data = om.MFnPluginData().create(WatermarkData.TYPE_ID)
        cls.image_data_obj = typed_attr.create("watermarkData", "wd", WatermarkData.TYPE_ID, default_image_data)
        typed_attr.writable = True
        typed_attr.readable = True
        typed_attr.storable = True
        cls.addAttribute(cls.image_data_obj)


class WatermarkDrawOverride(omr.MPxDrawOverride):

    NAME = "WatermarkDrawOverride"


    def __init__(self, obj):
        super(WatermarkDrawOverride, self).__init__(obj, None)

        self.texture = None

    def __del__(self):
        self.release_texture()

    def release_texture(self):
        if self.texture:
            texture_manager = omr.MRenderer.getTextureManager()
            texture_manager.releaseTexture(self.texture)
            self.texture = None

    def update_texture_data(self, node):
        qimage = node.get_image()

        if qimage and not qimage.isNull():
            texture_manager = omr.MRenderer.getTextureManager()

            texture_desc = omr.MTextureDescription()
            texture_desc.setToDefault2DTexture()
            texture_desc.fWidth = qimage.width()
            texture_desc.fHeight = qimage.height()

            image_bytes = qimage.constBits().tobytes()

            self.texture = texture_manager.acquireTexture("", texture_desc, image_bytes, False)

            if not self.texture:
                om.MGlobal.displayError("Unsupported image data")

    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):
        self.vp_width = frame_context.getViewportDimensions()[2]

        dag_fn = om.MFnDagNode(obj_path)
        node = dag_fn.userNode()

        if not self.texture:
            self.update_texture_data(node)

        if self.texture:
            texture_desc = self.texture.textureDescription()
            self.half_width = 0.5 * texture_desc.fWidth
            self.half_height = 0.5 * texture_desc.fHeight

    def supportedDrawAPIs(self):
        return (omr.MRenderer.kAllDevices)

    def hasUIDrawables(self):
        return True

    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        draw_manager.beginDrawable()

        if self.texture:
            draw_manager.setTexture(self.texture)
            draw_manager.setTextureSampler(omr.MSamplerState.kMinMagMipLinear, omr.MSamplerState.kTexClamp)
            draw_manager.setTextureMask(omr.MBlendState.kRGBAChannels)
            draw_manager.setColor(om.MColor((1.0, 1.0, 1.0, 1.0)))

            rect_center = om.MPoint(self.vp_width - (50 + self.half_width), 50 + self.half_height)
            draw_manager.rect2d(rect_center, om.MVector(0.0, 1.0, 0.0), self.half_width, self.half_height, True)

        draw_manager.endDrawable()

    @classmethod
    def creator(cls, obj):
        return WatermarkDrawOverride(obj)


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)

    try:
        plugin_fn.registerCommand(WatermarkCmd.COMMAND_NAME, WatermarkCmd.creator, WatermarkCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(WatermarkCmd))

    try:
        plugin_fn.registerData(WatermarkData.TYPE_NAME, WatermarkData.TYPE_ID, WatermarkData.creator)
    except:
        om.MGlobal.displayError("Failed to register data type: {0}".format(WatermarkData.TYPE_NAME))

    try:
        plugin_fn.registerNode(WatermarkNode.TYPE_NAME,              # name of the node
                               WatermarkNode.TYPE_ID,                # unique id that identifies node
                               WatermarkNode.creator,                # function/method that returns new instance of class
                               WatermarkNode.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode,              # type of node to be registered
                               WatermarkNode.DRAW_CLASSIFICATION)    # draw-specific classification string (VP2.0)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(WatermarkNode.TYPE_NAME))

    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(WatermarkNode.DRAW_CLASSIFICATION,     # draw-specific classification
                                                      WatermarkNode.DRAW_REGISTRANT_ID,      # unique name to identify registration
                                                      WatermarkDrawOverride.creator)         # function/method that returns new instance of class
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(WatermarkDrawOverride.NAME))


def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)

    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(WatermarkNode.DRAW_CLASSIFICATION, WatermarkNode.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(WatermarkDrawOverride.NAME))

    try:
        plugin_fn.deregisterNode(WatermarkNode.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(WatermarkNode.TYPE_NAME))

    try:
        plugin_fn.deregisterData(WatermarkData.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to deregister data type: {0}".format(WatermarkData.TYPE_NAME))

    try:
        plugin_fn.deregisterCommand(WatermarkCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(WatermarkCmd))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "watermark_node.py"

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    # cmds.evalDeferred('cmds.createNode("watermarknode")')

    image_path = "C:/Users/czurbrigg/Documents/maya/projects/default/sourceimages/watermark.png"
    cmds.evalDeferred('cmds.watermark("{0}")'.format(image_path))


