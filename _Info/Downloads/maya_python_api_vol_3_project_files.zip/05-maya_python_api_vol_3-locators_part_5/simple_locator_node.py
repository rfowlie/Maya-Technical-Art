import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class SimpleLocatorNode(omui.MPxLocatorNode):

    TYPE_NAME = "simplelocator"
    TYPE_ID = om.MTypeId(0x0007F7FE)
    DRAW_CLASSIFICATION = "drawdb/geometry/simplelocator"
    DRAW_REGISTRANT_ID = "SimpleLocatorNode"
    
    shape_index_obj = None


    def __init__(self):
        super(SimpleLocatorNode, self).__init__()

    @classmethod
    def creator(cls):
        return SimpleLocatorNode()

    @classmethod
    def initialize(cls):
        numeric_attr = om.MFnNumericAttribute()
        
        cls.shape_index_obj = numeric_attr.create("shapeIndex", "si", om.MFnNumericData.kInt, 0)
        numeric_attr.setMin(0)
        numeric_attr.setMax(2)
        
        cls.addAttribute(cls.shape_index_obj)
        
        
class SimpleLocatorUserData(om.MUserData):
    
    def __init__(self, deleteAfterUse=False):
        super(SimpleLocatorUserData, self).__init__(deleteAfterUse)
        
        self.shape_index = 0
        
        
class SimpleLocatorDrawOverride(omr.MPxDrawOverride):
    
    NAME = "SimpleLocatorDrawOverride"
    
    
    def __init__(self, obj):
        super(SimpleLocatorDrawOverride, self).__init__(obj, None, True)
        
    def supportedDrawAPIs(self):
        return omr.MRenderer.kAllDevices
        
    def hasUIDrawables(self):
        return True
        
    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):
        data = old_data
        if not data:
            data = SimpleLocatorUserData()
        
        locator_obj = obj_path.node()
        node_fn = om.MFnDependencyNode(locator_obj)
        
        data.shape_index = node_fn.findPlug("shapeIndex", False).asInt()
        
        return data
        
    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        draw_manager.beginDrawable()
        
        if data.shape_index == 0:
            draw_manager.circle(om.MPoint(0.0, 0.0, 0.0), om.MVector(0.0, 1.0, 0.0), 1, False)
        elif data.shape_index == 1:
            draw_manager.rect(om.MPoint(0.0, 0.0, 0.0), om.MVector(0.0, 0.0, 1.0), om.MVector(0.0, 1.0, 0.0), 1.0, 1.0, False)
        elif data.shape_index == 2:
            point_array = om.MPointArray([(-1.0, 0.0, -1.0), (0.0, 0.0, 1.0), (1.0, 0.0, -1.0), (-1.0, 0.0, -1.0)])
            draw_manager.lineStrip(point_array, False)
        
        draw_manager.endDrawable()
        
    @classmethod
    def creator(cls, obj):
        return SimpleLocatorDrawOverride(obj)


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)
    try:
        plugin_fn.registerNode(SimpleLocatorNode.TYPE_NAME,              # name of the node
                               SimpleLocatorNode.TYPE_ID,                # unique id that identifies node
                               SimpleLocatorNode.creator,                # function/method that returns new instance of class
                               SimpleLocatorNode.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode,                  # type of node to be registered
                               SimpleLocatorNode.DRAW_CLASSIFICATION)

    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(SimpleLocatorNode.TYPE_NAME))
        
    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(SimpleLocatorNode.DRAW_CLASSIFICATION,
													  SimpleLocatorNode.DRAW_REGISTRANT_ID,
                                                      SimpleLocatorDrawOverride.creator)
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(SimpleLocatorDrawOverride.NAME))

def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)
    
    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(SimpleLocatorNode.DRAW_CLASSIFICATION, SimpleLocatorNode.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(SimpleLocatorDrawOverride.NAME))

    try:
        plugin_fn.deregisterNode(SimpleLocatorNode.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(SimpleLocatorNode.TYPE_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "simple_locator_node.py"

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.createNode("simplelocator")')
