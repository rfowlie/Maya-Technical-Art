import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class DistanceBetweenCmd(om.MPxCommand):

    COMMAND_NAME = "czDistanceBetween"


    def __init__(self):
        super(DistanceBetweenCmd, self).__init__()

    def doIt(self, arg_list):
        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        selection_list = arg_db.getObjectList()
        if not selection_list.length() == 2:
            raise RuntimeError("Command requires two transform nodes")

        self.selected_objs = [selection_list.getDependNode(0), selection_list.getDependNode(1)]

        for selected_obj in self.selected_objs:
            if selected_obj.apiType() != om.MFn.kTransform:
                raise RuntimeError("One or more nodes is not a transform")

        self.redoIt()


    def undoIt(self):
        pass

    def redoIt(self):
        pass

    def isUndoable(self):
        return True

    @classmethod
    def creator(cls):
        return DistanceBetweenCmd()

    @classmethod
    def create_syntax(cls):
        syntax = om.MSyntax()

        syntax.setObjectType(om.MSyntax.kSelectionList)
        syntax.useSelectionAsDefault(True)

        return syntax


class DistanceBetweenLocator(omui.MPxLocatorNode):

    TYPE_NAME = "distanceBetweenLocator"
    TYPE_ID = om.MTypeId(0x0007F7FD)
    DRAW_CLASSIFICATION = "drawdb/geometry/distancebetweenlocator"
    DRAW_REGISTRANT_ID = "DistanceBetweenLocator"

    point1_obj = None
    point2_obj = None
    distance_obj = None

    min_distance_obj = None
    max_distance_obj = None
    color_ramp_obj = None

    DEFAULT_POSITIONS = [0.0, 1.0]
    DEFAULT_COLORS = [om.MColor([0.0, 0.0, 0.0]), om.MColor([1.0, 1.0, 1.0])]
    DEFAULT_INTERPS = [om.MRampAttribute.kLinear, om.MRampAttribute.kLinear]


    def __init__(self):
        super(DistanceBetweenLocator, self).__init__()

    def postConstructor(self):
        color_ramp_attr = om.MRampAttribute(self.thisMObject(), self.color_ramp_obj)
        color_ramp_attr.addEntries(DistanceBetweenLocator.DEFAULT_POSITIONS, DistanceBetweenLocator.DEFAULT_COLORS, DistanceBetweenLocator.DEFAULT_INTERPS)

    def compute(self, plug, data):
        point1 = om.MPoint(data.inputValue(self.point1_obj).asFloatVector())
        point2 = om.MPoint(data.inputValue(self.point2_obj).asFloatVector())

        distance = point1.distanceTo(point2)

        data.outputValue(self.distance_obj).setDouble(distance)

        data.setClean(plug)

    @classmethod
    def creator(cls):
        return DistanceBetweenLocator()

    @classmethod
    def initialize(cls):
        numeric_attr = om.MFnNumericAttribute()

        cls.point1_obj = numeric_attr.createPoint("point1", "p1")
        numeric_attr.readable = False
        numeric_attr.keyable = True

        cls.point2_obj = numeric_attr.createPoint("point2", "p2")
        numeric_attr.readable = False
        numeric_attr.keyable = True

        cls.distance_obj = numeric_attr.create("distance", "dist", om.MFnNumericData.kDouble, 0.0)
        numeric_attr.writable = False

        cls.min_distance_obj = numeric_attr.create("minDistance", "min", om.MFnNumericData.kDouble, 0.0)
        numeric_attr.readable = False
        numeric_attr.keyable = True
        numeric_attr.setMin(0.0)

        cls.max_distance_obj = numeric_attr.create("maxDistance", "max", om.MFnNumericData.kDouble, 10.0)
        numeric_attr.readable = False
        numeric_attr.keyable = True
        numeric_attr.setMin(0.0)

        cls.color_ramp_obj = om.MRampAttribute.createColorRamp("colorRamp", "col")

        cls.addAttribute(cls.point1_obj)
        cls.addAttribute(cls.point2_obj)
        cls.addAttribute(cls.distance_obj)

        cls.addAttribute(cls.min_distance_obj)
        cls.addAttribute(cls.max_distance_obj)
        cls.addAttribute(cls.color_ramp_obj)

        cls.attributeAffects(cls.point1_obj, cls.distance_obj)
        cls.attributeAffects(cls.point2_obj, cls.distance_obj)


class DistanceBetweenUserData(om.MUserData):

    def __init__(self, deleteAfterUse=False):
        super(DistanceBetweenUserData, self).__init__(deleteAfterUse)

        self.distance = 0
        self.point1 = om.MPoint()
        self.point2 = om.MPoint()

        self.color = om.MColor()


class DistanceBetweenDrawOverride(omr.MPxDrawOverride):

    NAME = "DistanceBetweenDrawOverride"


    def __init__(self, obj):
        super(DistanceBetweenDrawOverride, self).__init__(obj, None, True)

    def refineSelectionPath(self, select_info, hit_item, path, components, obj_mask):
        return False

    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):
        data = old_data
        if not data:
            data = DistanceBetweenUserData()

        node_fn = om.MFnDependencyNode(obj_path.node())

        data.point1 = om.MPoint(node_fn.findPlug("point1X", False).asDouble(),
								node_fn.findPlug("point1Y", False).asDouble(),
								node_fn.findPlug("point1Z", False).asDouble())

        data.point2 = om.MPoint(node_fn.findPlug("point2X", False).asDouble(),
								node_fn.findPlug("point2Y", False).asDouble(),
								node_fn.findPlug("point2Z", False).asDouble())

        data.distance = node_fn.findPlug("distance", False).asDouble()

        min_distance = node_fn.findPlug("minDistance", False).asDouble()
        max_distance = node_fn.findPlug("maxDistance", False).asDouble()

        if min_distance < max_distance:
            ramp_position = (data.distance - min_distance) / (max_distance - min_distance)
            ramp_position = min(max(0.0, ramp_position), 1.0)
        else:
            ramp_position = 0.0

        color_ramp_plug = node_fn.findPlug("colorRamp", False)
        color_ramp_attr = om.MRampAttribute(color_ramp_plug)

        data.color = color_ramp_attr.getValueAtPosition(ramp_position)

        return data

    def supportedDrawAPIs(self):
        return omr.MRenderer.kAllDevices

    def hasUIDrawables(self):
        return True

    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        draw_manager.beginDrawable()

        draw_manager.setFontSize(14)
        draw_manager.setFontWeight(100)
        draw_manager.setColor(data.color)

        pos = om.MPoint((om.MVector(data.point1) + om.MVector(data.point2)) / 2.0)
        text = "{0:.3f}".format(data.distance)

        draw_manager.text(pos, text, omr.MUIDrawManager.kCenter)
        draw_manager.line(data.point1, data.point2)

        draw_manager.endDrawable()

    @classmethod
    def creator(cls, obj):
        return DistanceBetweenDrawOverride(obj)


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)

    # Register commands
    try:
        plugin_fn.registerCommand(DistanceBetweenCmd.COMMAND_NAME, DistanceBetweenCmd.creator, DistanceBetweenCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(DistanceBetweenCmd.COMMAND_NAME))

    # Register nodes
    try:
        plugin_fn.registerNode(DistanceBetweenLocator.TYPE_NAME,              # name of the node
                               DistanceBetweenLocator.TYPE_ID,                # unique id that identifies node
                               DistanceBetweenLocator.creator,                # function/method that returns new instance of class
                               DistanceBetweenLocator.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode,                       # type of node to be registered
                               DistanceBetweenLocator.DRAW_CLASSIFICATION)    # draw-specific classification string (VP2.0)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(DistanceBetweenLocator.TYPE_NAME))

    # Register draw overrides
    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(DistanceBetweenLocator.DRAW_CLASSIFICATION,     # draw-specific classification
                                                      DistanceBetweenLocator.DRAW_REGISTRANT_ID,      # unique name to identify registration
                                                      DistanceBetweenDrawOverride.creator)            # function/method that returns new instance of class
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(DistanceBetweenLocator.TYPE_NAME))


def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)

    # Deregister draw overrides
    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(DistanceBetweenLocator.DRAW_CLASSIFICATION, DistanceBetweenLocator.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(DistanceBetweenDrawOverride.NAME))

    # Deregister nodes
    try:
        plugin_fn.deregisterNode(DistanceBetweenLocator.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(DistanceBetweenLocator.TYPE_NAME))

    # Deregister commands
    try:
        plugin_fn.deregisterCommand(DistanceBetweenCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(DistanceBetweenCmd.COMMAND_NAME))


def cz_distance_between_test():
    cmds.setAttr("persp.translate", 3.5, 5.5, 10.0)
    cmds.setAttr("persp.rotate", -27.0, 19.0, 0.0)

    cube1 = cmds.polyCube()[0]
    cube2 = cmds.polyCube()[0]

    cmds.setAttr("{0}.translateX".format(cube1), -2.5)
    cmds.setAttr("{0}.translateX".format(cube2), 2.5)

    cmds.czDistanceBetween(cube1, cube2)  # pylint: disable=E1101


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "distance_between_locator.py"

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cz_distance_between_test()')
