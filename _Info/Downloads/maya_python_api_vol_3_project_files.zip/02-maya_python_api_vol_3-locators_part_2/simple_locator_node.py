import maya.api.OpenMaya as om
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


class SimpleLocatorNode(omui.MPxLocatorNode):

    TYPE_NAME = "simplelocator"
    TYPE_ID = om.MTypeId(0x0007F7FE)


    def __init__(self):
        super(SimpleLocatorNode, self).__init__()

    @classmethod
    def creator(cls):
        return SimpleLocatorNode()

    @classmethod
    def initialize(cls):
        pass


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)
    try:
        plugin_fn.registerNode(SimpleLocatorNode.TYPE_NAME,              # name of the node
                               SimpleLocatorNode.TYPE_ID,                # unique id that identifies node
                               SimpleLocatorNode.creator,                # function/method that returns new instance of class
                               SimpleLocatorNode.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode)                  # type of node to be registered

    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(SimpleLocatorNode.TYPE_NAME))

def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)

    try:
        plugin_fn.deregisterNode(SimpleLocatorNode.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(SimpleLocatorNode.TYPE_NAME))


if __name__ == "__main__":

    cmds.file(new=True, force=True)

    plugin_name = "simple_locator_node.py"

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.createNode("simplelocator")')
