import maya.api.OpenMaya as om

from distance_between_locator import DistanceBetweenLocator


class DistanceBetweenCmd(om.MPxCommand):

    COMMAND_NAME = "czDistanceBetween"


    def __init__(self):
        super(DistanceBetweenCmd, self).__init__()

    def doIt(self, arg_list):
        try:
            arg_db = om.MArgDatabase(self.syntax(), arg_list)
        except:
            self.displayError("Error parsing arguments")
            raise

        selection_list = arg_db.getObjectList()
        if not selection_list.length() == 2:
            raise RuntimeError("Command requires two transform nodes")

        self.selected_objs = [selection_list.getDependNode(0), selection_list.getDependNode(1)]

        for selected_obj in self.selected_objs:
            if selected_obj.apiType() != om.MFn.kTransform:
                raise RuntimeError("One or more nodes is not a transform")

        self.dag_modifier = om.MDagModifier()

        self.transform_obj = self.dag_modifier.createNode("transform", om.MObject.kNullObj)

        transform_name = "{0}1".format(DistanceBetweenLocator.TYPE_NAME)
        self.dag_modifier.renameNode(self.transform_obj, transform_name)

        self.dest_obj = self.dag_modifier.createNode(DistanceBetweenLocator.TYPE_ID, self.transform_obj)

        shape_name = "{0}Shape1".format(DistanceBetweenLocator.TYPE_NAME)
        self.dag_modifier.renameNode(self.dest_obj, shape_name)

        dest_fn = om.MFnDependencyNode(self.dest_obj)

        for i in range(2):
            src_fn = om.MFnDependencyNode(self.selected_objs[i])

            for coord in ['X', 'Y', 'Z']:
                src_plug = src_fn.findPlug("translate{0}".format(coord), False)
                dest_plug = dest_fn.findPlug("point{0}{1}".format(i + 1, coord), False)

                self.dag_modifier.connect(src_plug, dest_plug)

        self.redoIt()

        # print("transform name: {0}".format(om.MFnDependencyNode(self.transform_obj).name()))


    def get_shape_name(self, transform_name):
        split_name = transform_name.split(DistanceBetweenLocator.TYPE_NAME)

        return "{0}Shape{1}".format(DistanceBetweenLocator.TYPE_NAME, split_name[1])

    def undoIt(self):
        self.dag_modifier.undoIt()

    def redoIt(self):
        self.dag_modifier.doIt()

        shape_fn = om.MFnDependencyNode(self.dest_obj)
        shape_fn.setName(self.get_shape_name(om.MFnDependencyNode(self.transform_obj).name()))

    def isUndoable(self):
        return True

    @classmethod
    def creator(cls):
        return DistanceBetweenCmd()

    @classmethod
    def create_syntax(cls):
        syntax = om.MSyntax()

        syntax.setObjectType(om.MSyntax.kSelectionList)
        syntax.useSelectionAsDefault(True)

        return syntax




