import maya.cmds as cmds


def reload_plugin(plugin_name):

    cmds.file(new=True, force=True)

    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred("import distance_between_tests;distance_between_tests.build_test_scene()")


def build_test_scene():

    cmds.setAttr("persp.translate", 3.5, 5.5, 10.0)
    cmds.setAttr("persp.rotate", -27.0, 19.0, 0.0)

    cube1 = cmds.polyCube()[0]
    cube2 = cmds.polyCube()[0]

    cmds.setAttr("{0}.translateX".format(cube1), -2.5)
    cmds.setAttr("{0}.translateX".format(cube2), 2.5)

    cmds.czDistanceBetween(cube1, cube2)  # pylint: disable=E1101


if __name__ == "__main__":

    reload_plugin("distance_between_plugin.py")

