import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr

from distance_between_cmd import DistanceBetweenCmd
from distance_between_locator import DistanceBetweenLocator, DistanceBetweenDrawOverride


def maya_useNewAPI():
    """
    The presence of this function tells Maya that the plugin produces, and
    expects to be passed, objects created using the Maya Python API 2.0.
    """
    pass


def initializePlugin(plugin):

    vendor = "Chris Zurbrigg"
    version = "1.0.0"
    api_version = "Any"

    plugin_fn = om.MFnPlugin(plugin, vendor, version, api_version)

    # Register commands
    try:
        plugin_fn.registerCommand(DistanceBetweenCmd.COMMAND_NAME, DistanceBetweenCmd.creator, DistanceBetweenCmd.create_syntax)
    except:
        om.MGlobal.displayError("Failed to register command: {0}".format(DistanceBetweenCmd.COMMAND_NAME))

    # Register nodes
    try:
        plugin_fn.registerNode(DistanceBetweenLocator.TYPE_NAME,              # name of the node
                               DistanceBetweenLocator.TYPE_ID,                # unique id that identifies node
                               DistanceBetweenLocator.creator,                # function/method that returns new instance of class
                               DistanceBetweenLocator.initialize,             # function/method that will initialize all attributes of node
                               om.MPxNode.kLocatorNode,                       # type of node to be registered
                               DistanceBetweenLocator.DRAW_CLASSIFICATION)    # draw-specific classification string (VP2.0)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(DistanceBetweenLocator.TYPE_NAME))

    # Register draw overrides
    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(DistanceBetweenLocator.DRAW_CLASSIFICATION,     # draw-specific classification
                                                      DistanceBetweenLocator.DRAW_REGISTRANT_ID,      # unique name to identify registration
                                                      DistanceBetweenDrawOverride.creator)            # function/method that returns new instance of class
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(DistanceBetweenLocator.TYPE_NAME))


def uninitializePlugin(plugin):

    plugin_fn = om.MFnPlugin(plugin)

    # Deregister draw overrides
    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(DistanceBetweenLocator.DRAW_CLASSIFICATION, DistanceBetweenLocator.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(DistanceBetweenDrawOverride.NAME))

    # Deregister nodes
    try:
        plugin_fn.deregisterNode(DistanceBetweenLocator.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(DistanceBetweenLocator.TYPE_NAME))

    # Deregister commands
    try:
        plugin_fn.deregisterCommand(DistanceBetweenCmd.COMMAND_NAME)
    except:
        om.MGlobal.displayError("Failed to deregister command: {0}".format(DistanceBetweenCmd.COMMAND_NAME))


