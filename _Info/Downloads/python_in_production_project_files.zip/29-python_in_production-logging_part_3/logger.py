import logging
import sys

class Logger(object):

    LOGGER_NAME = "Zurbrigg"

    LEVEL_DEFAULT = logging.DEBUG

    _logger_obj = None


    @classmethod
    def logger_obj(cls):

        if not cls._logger_obj:
            if cls.logger_exists():
                cls._logger_obj = logging.getLogger(cls.LOGGER_NAME)
            else:
                cls._logger_obj = logging.getLogger(cls.LOGGER_NAME)

                cls._logger_obj.setLevel(cls.LEVEL_DEFAULT)

                fmt = logging.Formatter("[%(name)s][%(levelname)s] %(message)s")

                stream_handler = logging.StreamHandler(sys.stderr)
                stream_handler.setFormatter(fmt)
                cls._logger_obj.addHandler(stream_handler)

        return cls._logger_obj

    @classmethod
    def logger_exists(cls):
        return cls.LOGGER_NAME in logging.Logger.manager.loggerDict.keys()
