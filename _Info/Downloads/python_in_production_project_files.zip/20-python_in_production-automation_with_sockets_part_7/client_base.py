import json
import socket
import time
import traceback


class ClientBase(object):
    """
    """
    PORT = 17344
    HEADER_SIZE = 10


    def __init__(self, timeout=2):
        self.timeout = timeout
        self.port = self.__class__.PORT

        # self.discard_count = 0

    def connect(self, port=-1):
        if port >= 0:
            self.port = port
        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.connect(("localhost", self.port))
            self.client_socket.setblocking(0)
        except:
            traceback.print_exc()
            return False

        return True

    def disconnect(self):
        try:
            self.client_socket.close()
        except:
            traceback.print_exc()
            return False

        return True

    def send(self, cmd):
        json_cmd = json.dumps(cmd)

        message = []
        message.append("{0:10d}".format(len(json_cmd.encode()))) # header
        message.append(json_cmd)

        try:
            msg_str = "".join(message)
            self.client_socket.sendall(msg_str.encode())
        except:
            traceback.print_exc()
            return None

        return self.recv()

    def recv(self):
        total_data = []
        data = ""
        reply_length = 0
        bytes_remaining = ClientBase.HEADER_SIZE

        start_time = time.time()
        while time.time() - start_time < self.timeout:

            try:
                data = self.client_socket.recv(bytes_remaining)
            except:
                time.sleep(0.01)
                continue

            if data:
                total_data.append(data)

                bytes_remaining -= len(data)
                if(bytes_remaining <= 0):

                    for i in range(len(total_data)):
                        total_data[i] = total_data[i].decode()

                    if reply_length == 0:
                        header = "".join(total_data)
                        reply_length = int(header)
                        bytes_remaining = reply_length
                        total_data = []
                    else:
                        # if self.discard_count > 0:
                        #     self.discard_count -= 1
                        #     return self.recv()

                        reply_json = "".join(total_data)
                        return json.loads(reply_json)

        # self.discard_count += 1

        raise RuntimeError("Timeout waiting for response")

    def is_valid_reply(self, reply):
        if not reply:
            print("[ERROR] Invalid Reply")
            return False

        if not reply["success"]:
            print("[ERROR] {0} failed: {1}".format(reply["cmd"], reply["msg"]))
            return False

        return True
            

    def ping(self):
        cmd =  {
            "cmd": "ping"
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return True
        else:
            return False


class ExampleClient(ClientBase):

    PORT = 17337

    def echo(self, text):
        cmd = {
            "cmd": "echo",
            "text": text
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def set_title(self, title):
        cmd = {
            "cmd": "set_title",
            "title": title
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def sleep(self):
        cmd = {
            "cmd": "sleep"
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

if __name__ == "__main__":

    client = ExampleClient()
    if client.connect():
        print("Connected successfully.")

        # print(client.ping())
        # print(client.echo("Hello World"))
        # print(client.set_title("New Server Title"))
        # print(client.sleep())
        try:
            client.sleep()
        except:
            print("Timeout waiting for sleep")

        for i in range(5):
            try:
                print(client.echo("Message {0}".format(i)))
            except:
                print("Timeout index: {0}".format(i))

        if client.disconnect():
            print("Disconnected successfully")

    else:
        print("Failed to connect")
