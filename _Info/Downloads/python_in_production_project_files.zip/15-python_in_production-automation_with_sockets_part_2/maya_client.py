import socket
import sys

BUFFER_SIZE = 4096

port = 20181  # e.g. 20180=Maya 2018 (MEL), 20181=Maya 2018 (Python)

if len(sys.argv) > 1:
    port = sys.argv[1]

maya_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
maya_socket.connect(("localhost", port))

maya_socket.sendall("cmds.file(new=True, force=True)".encode())
data = maya_socket.recv(BUFFER_SIZE)
print(data.decode())

maya_socket.sendall("cmds.polySphere()".encode())
data = maya_socket.recv(BUFFER_SIZE)
result = eval(data.decode().replace('\x00',''))
print(result)

# maya_socket.sendall("def test():\n\tprint('Hello World')\ntest()".encode())
# data = maya_socket.recv(BUFFER_SIZE)
# print(data.decode())

# maya_socket.sendall("test()".encode())
# data = maya_socket.recv(BUFFER_SIZE)
# print(data.decode())

maya_socket.close()
