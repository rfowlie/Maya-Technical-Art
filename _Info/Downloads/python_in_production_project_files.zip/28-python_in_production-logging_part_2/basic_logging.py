import logging
import sys

logger_obj = logging.getLogger("Zurbrigg")
logger_obj.setLevel(25)

fmt = logging.Formatter("[%(name)s][%(levelname)s] %(message)s")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(fmt)
logger_obj.addHandler(handler)

logger_obj.critical("critical message")
logger_obj.error("error message")
logger_obj.warning("warning message")
logger_obj.info("info message")
logger_obj.debug("debug message")
logger_obj.log(25, "log message")

try:
    a = []
    b = a[0]
except:
    logger_obj.exception("exception message")