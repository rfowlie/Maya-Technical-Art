from client_base import ClientBase


class MayaClientApi(ClientBase):

    PORT = 17559

    def open(self, file_path, deferred=False, force=True):
        cmd = {
            "cmd": "open",
            "file_path": file_path,
            "deferred": deferred,
            "force": force
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def load_reference_nodes(self, reference_nodes):
        cmd = {
            "cmd": "load_reference_nodes",
            "reference_nodes": reference_nodes
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None
            
    def unload_reference_nodes(self, reference_nodes):
        cmd = {
            "cmd": "unload_reference_nodes",
            "reference_nodes": reference_nodes
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

if __name__ == "__main__":

    file_path = "D:/Development/Patreon/Sandbox/example_scene.ma"
    cubeRN = "cubeRN"
    cylinderRN = "cylinderRN"
    sphereRN = "cylinderRN"

    maya_client = MayaClientApi(timeout=120)
    if maya_client.connect():
        print("Connected successfully.")

        result = maya_client.open(file_path, deferred=True)
        if result:
            print("File opened successfully: {0}".format(file_path))

            loaded_ref_count = maya_client.load_reference_nodes([cubeRN, cylinderRN])
            print("{0} reference nodes loaded.".format(loaded_ref_count))

        # result = maya_client.open(file_path, deferred=False)
        # if result:
        #     print("File opened successfully: {0}".format(file_path))

        #     unloaded_ref_count = maya_client.unload_reference_nodes([cubeRN, cylinderRN])
        #     print("{0} reference nodes unloaded.".format(unloaded_ref_count))

        if maya_client.disconnect():
            print("Disconnected successfully")

    else:
        print("Failed to connect")