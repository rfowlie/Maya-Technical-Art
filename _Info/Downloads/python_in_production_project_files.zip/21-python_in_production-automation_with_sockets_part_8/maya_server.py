import sys

from server_base import ServerBase

from PySide2 import QtWidgets
from shiboken2 import wrapInstance

import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    """
    Return the Maya main window widget as a Python object
    """
    main_window_ptr = omui.MQtUtil.mainWindow()
    if sys.version_info.major >= 3:
        return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)
    else:
        return wrapInstance(long(main_window_ptr), QtWidgets.QWidget)


class MayaServer(ServerBase):

    PORT = 17559

    def __init__(self, parent=maya_main_window()):
        super(MayaServer, self).__init__(parent)

    def process_cmd(self, cmd, data, reply):
        if cmd == "open":
            self.open(data, reply)
        elif cmd == "load_reference_nodes":
            self.load_reference_nodes(data, reply)
        elif cmd == "unload_reference_nodes":
            self.unload_reference_nodes(data, reply)
        else:
            super(MayaServer, self).process_cmd(cmd, data, reply)

    def open(self, data, reply):
        file_path = data["file_path"]
        force = data["force"]

        kwargs = {}
        if data["deferred"]:
            kwargs["loadReferenceDepth"] = "none"

        result = cmds.file(file_path, open=True, force=force, **kwargs)

        reply["result"] = result
        reply["success"] = True

    def load_reference_nodes(self, data, reply):
        reference_nodes = data["reference_nodes"]

        loaded_ref_count = 0
        for node in reference_nodes:
            cmds.file(loadReference=node)
            loaded_ref_count += 1

        reply["result"] = loaded_ref_count
        reply["success"] = True

    def unload_reference_nodes(self, data, reply):
        reference_nodes = data["reference_nodes"]

        unloaded_ref_count = 0
        for node in reference_nodes:
            cmds.file(unloadReference=node)
            unloaded_ref_count += 1

        reply["result"] = unloaded_ref_count
        reply["success"] = True



if __name__ == "__main__":

    try:
        maya_server.deleteLater()  # pylint: disable=E0601,E0602
    except:
        pass

    cmds.evalDeferred("maya_server = MayaServer()")




