import json
import sys
import time
import traceback

from PySide2 import QtCore
from PySide2 import QtNetwork
from PySide2 import QtWidgets


class ServerBase(QtCore.QObject):

    PORT = 17344
    HEADER_SIZE = 10


    def __init__(self, parent):
        super(ServerBase, self).__init__(parent)

        self.port = self.__class__.PORT
        self.initialize()

    def initialize(self):
        pass

    def listen(self):
        pass

    def establish_connection(self):
        pass

    def on_disconnected(self):
        pass

    def read(self):
        pass

    def write(self):
        pass


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)

    window = QtWidgets.QDialog()
    window.setWindowTitle("Server Base")
    window.setFixedSize(240, 150)

    QtWidgets.QPlainTextEdit(window)

    server = ServerBase(window)

    window.show()

    app.exec_()


