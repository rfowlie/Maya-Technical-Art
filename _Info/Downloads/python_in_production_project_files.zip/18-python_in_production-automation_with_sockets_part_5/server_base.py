import json
import sys
import time
import traceback

from PySide2 import QtCore
from PySide2 import QtNetwork
from PySide2 import QtWidgets


class ServerBase(QtCore.QObject):

    PORT = 17344
    HEADER_SIZE = 10


    def __init__(self, parent):
        super(ServerBase, self).__init__(parent)

        self.port = self.__class__.PORT
        self.initialize()

    def initialize(self):
        self.server = QtNetwork.QTcpServer(self)
        self.server.newConnection.connect(self.establish_connection)

        if self.listen():
            print("[LOG] Server listening on port: {0}".format(self.port))
        else:
            print("[ERROR] Server initialization failed")

    def listen(self):
        if not self.server.isListening():
            return self.server.listen(QtNetwork.QHostAddress.LocalHost, self.port)

        return False

    def establish_connection(self):
        self.socket = self.server.nextPendingConnection()
        if self.socket.state() == QtNetwork.QTcpSocket.ConnectedState:
            self.socket.disconnected.connect(self.on_disconnected)
            self.socket.readyRead.connect(self.read)

            print("[LOG] Connection Established")

    def on_disconnected(self):
        self.socket.disconnected.disconnect()
        self.socket.readyRead.disconnect()

        self.socket.deleteLater()

        print("[LOG] Connection Disconnected")

    def read(self):
        pass

    def write(self):
        pass


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)

    window = QtWidgets.QDialog()
    window.setWindowTitle("Server Base")
    window.setFixedSize(240, 150)

    QtWidgets.QPlainTextEdit(window)

    server = ServerBase(window)

    window.show()

    app.exec_()


