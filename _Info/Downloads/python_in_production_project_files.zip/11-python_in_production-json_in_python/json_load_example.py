import json

file_path = "D:/Development/Patreon/Sandbox/json/data.json"

with open(file_path, "r") as file_for_read:
    data = json.load(file_for_read)

print(data)
