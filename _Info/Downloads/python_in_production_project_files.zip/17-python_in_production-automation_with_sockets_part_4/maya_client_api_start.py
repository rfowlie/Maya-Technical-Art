import socket
import traceback


class MayaClient(object):
    """
    """
    PORT = 20181  # e.g. 20180=Maya 2018 (MEL), 20181=Maya 2018 (Python)

    BUFFER_SIZE = 4096


    def __init__(self):
        self.maya_socket = None

    def connect(self, port=-1):
        pass

    def disconnect(self):
        pass

    def send(self, cmd):
        pass

    def recv(self):
        pass


    # ------------------------------------------------------------------
    # COMMANDS
    # ------------------------------------------------------------------
    
    # Add comand methods here


if __name__ == "__main__":

    maya_client = MayaClient()
