import maya.cmds as cmds
import maya.mel as mel


class ZurbriggHelpers(object):

    @classmethod
    def add_addr(cls, node, long_name, attr_type, default_value, keyable=False):
        cmds.addAttr(node, longName=long_name, attributeType=attr_type, defaultValue=default_value, keyable=keyable)

    @classmethod
    def set_addr(cls, node, attr, value, value_type=None):
        if value_type:
            # expects a list that will be unpacked for the command
            cmds.setAttr("{0}.{1}".format(node, attr), *value, type=value_type)
        else:
            cmds.setAttr("{0}.{1}".format(node, attr), value)


class BallAutoRig(object):

    def __init__(self):
        self.primary_color = [0.0, 0.0, 1.0]
        self.secondary_color = [1.0, 1.0, 1.0]

    def set_colors(self, primary, secondary):
        self.primary_color = primary
        self.secondary_color = secondary

    def construct_rig(self, name="ball"):
        cmds.select(clear=True)

        root_grp = cmds.group(name=name, empty=True, world=True)
        anim_controls_grp = cmds.group(name="anim_controls", empty=True, parent=root_grp)
        geometry_grp = cmds.group(name="geometry_doNotTouch", empty=True, parent=root_grp)

        ball_geo = self.create_ball("ball_geo", parent=geometry_grp)

    def create_ball(self, name, parent=None):
        ball_geo = cmds.sphere(pivot=(0,0,0), axis=(0,1,0), radius=1, name=name)[0]
        if parent:
            ball_geo = cmds.parent(ball_geo, parent)[0]

        return ball_geo

if __name__ == "__main__":

    # cmds.file(newFile=True, force=True)

    # ball = BallAutoRig()
    # ball.construct_rig()

    # ZurbriggHelpers.add_addr("pCube1", "TestAttribute", "double", 0, keyable=True)

    ZurbriggHelpers.set_addr("pCube1", "tx", 5)
    ZurbriggHelpers.set_addr("lambert1", "color", [0, 1, 0], "double3")






