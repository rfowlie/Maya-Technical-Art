import maya.cmds as cmds

cmds.select(clear=True)

shoulder_jnt = cmds.joint(position=(0, 0, 4), name="shoulder_jnt")
elbow_jnt = cmds.joint(position=(-2, 0, 0), name="elbow_jnt")
wrist_jnt = cmds.joint(position=(0, 0, -4), name="wrist_jnt")

cmds.joint(shoulder_jnt, edit=True, orientJoint="xyz", zeroScaleOrient=True, secondaryAxisOrient="yup")
cmds.joint(elbow_jnt, edit=True, orientJoint="xyz", zeroScaleOrient=True, secondaryAxisOrient="yup")

cmds.ikHandle(startJoint=shoulder_jnt, endEffector=wrist_jnt)
