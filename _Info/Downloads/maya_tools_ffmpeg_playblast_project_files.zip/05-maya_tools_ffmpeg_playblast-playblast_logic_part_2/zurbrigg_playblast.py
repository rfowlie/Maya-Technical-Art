import os
import traceback

from PySide2 import QtCore

import maya.OpenMaya as om


class ZurbriggPlayblast(QtCore.QObject):

    VERSION = "0.0.1"

    DEFAULT_FFMPEG_PATH = "D:/Media/ffmpeg/ffmpeg-4.2.1/bin/ffmpeg.exe"

    output_logged = QtCore.Signal(str)


    def __init__(self, ffmpeg_path=None, log_to_maya=True):
        super(ZurbriggPlayblast, self).__init__()

        self.set_ffmpeg_path(ffmpeg_path)
        self.set_maya_logging_enabled(log_to_maya)

    def set_ffmpeg_path(self, ffmpeg_path):
        if ffmpeg_path:
            self._ffmpeg_path = ffmpeg_path
        else:
            self._ffmpeg_path = ZurbriggPlayblast.DEFAULT_FFMPEG_PATH

    def get_ffmpeg_path(self):
        return self._ffmpeg_path

    def set_maya_logging_enabled(self, enabled):
        self._log_to_maya = enabled

    def execute(self, output_dir, filename, padding=4, show_ornaments=True, show_in_viewer=True, overwrite=False):

        if self.validate_ffmpeg():
            self.log_output("TODO: execute playblast")

    def validate_ffmpeg(self):
        if not self._ffmpeg_path:
            self.log_error("ffmpeg executable path not set")
            return False
        elif not os.path.exists(self._ffmpeg_path):
            self.log_error("ffmpeg executable path does not exist: {0}".format(self._ffmpeg_path))
            return False
        elif os.path.isdir(self._ffmpeg_path):
            self.log_error("Invalid ffmpeg path: {0}".format(self._ffmpeg_path))
            return False

        return True

    def log_error(self, text):
        if self._log_to_maya:
            om.MGlobal.displayError("[ZurbriggPlayblast] {0}".format(text))

        self.output_logged.emit("[ERROR] {0}".format(text))

    def log_warning(self, text):
        if self._log_to_maya:
            om.MGlobal.displayWarning("[ZurbriggPlayblast] {0}".format(text))

        self.output_logged.emit("[WARNING] {0}".format(text))

    def log_output(self, text):
        if self._log_to_maya:
            om.MGlobal.displayInfo(text)

        self.output_logged.emit(text)


if __name__ == "__main__":

    playblast = ZurbriggPlayblast()
    playblast.execute("D:/Temp", "output")


