import os
import traceback

from PySide2 import QtCore

import maya.OpenMaya as om


class ZurbriggPlayblast(QtCore.QObject):

    VERSION = "0.0.1"

    output_logged = QtCore.Signal(str)


    def __init__(self, ffmpeg_path=None, log_to_maya=True):
        super(ZurbriggPlayblast, self).__init__()

        self.set_maya_logging_enabled(log_to_maya)

    def set_maya_logging_enabled(self, enabled):
        self._log_to_maya = enabled

    def log_error(self, text):
        if self._log_to_maya:
            om.MGlobal.displayError("[ZurbriggPlayblast] {0}".format(text))

        self.output_logged.emit("[ERROR] {0}".format(text))

    def log_warning(self, text):
        if self._log_to_maya:
            om.MGlobal.displayWarning("[ZurbriggPlayblast] {0}".format(text))

        self.output_logged.emit("[WARNING] {0}".format(text))

    def log_output(self, text):
        if self._log_to_maya:
            om.MGlobal.displayInfo(text)

        self.output_logged.emit(text)


if __name__ == "__main__":

    playblast = ZurbriggPlayblast()
    playblast.log_error("Error Message")
    playblast.log_warning("Warning Message")
    playblast.log_output("Output Message")

