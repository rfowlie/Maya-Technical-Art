import sys

from PySide2 import QtCore
from PySide2 import QtWidgets

class StandaloneWindow(QtWidgets.QWidget):

    CONFIG_PATH = "{0}/QSettingsExample/config.ini".format(QtCore.QStandardPaths.writableLocation(QtCore.QStandardPaths.DocumentsLocation))

    def __init__(self):
        super(StandaloneWindow, self).__init__(parent=None)

        self.setWindowTitle("QSettings Example")
        self.setMinimumSize(400, 300)

        self.create_widgets()
        self.create_layout()

        self.load_settings()

    def create_widgets(self):
        self.temp_dir_le = QtWidgets.QLineEdit()
        self.temp_dir_browse_btn = QtWidgets.QPushButton("Browse...")

        self.cache_size_sb = QtWidgets.QSpinBox()
        self.cache_size_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.cache_size_sb.setMinimum(256)
        self.cache_size_sb.setMaximum(8192)
        self.cache_size_sb.setValue(1024)
        self.cache_size_sb.setFixedWidth(40)

        self.resize_to_fit_cb = QtWidgets.QCheckBox("Resize to fit video")
        self.endless_mouse_cb = QtWidgets.QCheckBox("Endless mouse scrub")

    def create_layout(self):
        file_layout = QtWidgets.QHBoxLayout()
        file_layout.addWidget(self.temp_dir_le)
        file_layout.addWidget(self.temp_dir_browse_btn)

        file_grp = QtWidgets.QGroupBox("Temp Directory")
        file_grp.setLayout(file_layout)

        cache_size_layout = QtWidgets.QHBoxLayout()
        cache_size_layout.addWidget(self.cache_size_sb)
        cache_size_layout.addStretch()

        cache_layout = QtWidgets.QFormLayout()
        cache_layout.addRow("Size: ", cache_size_layout)

        cache_grp = QtWidgets.QGroupBox("Cache")
        cache_grp.setLayout(cache_layout)

        options_layout = QtWidgets.QVBoxLayout()
        options_layout.addWidget(self.resize_to_fit_cb)
        options_layout.addWidget(self.endless_mouse_cb)

        options_grp = QtWidgets.QGroupBox("Options")
        options_grp.setLayout(options_layout)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(file_grp)
        main_layout.addWidget(cache_grp)
        main_layout.addWidget(options_grp)
        main_layout.addStretch()

    def closeEvent(self, event):
        self.save_settings()

    def save_settings(self):
        print("TODO: Implement save_settings()")

    def load_settings(self):
        print("TODO: Implement load_settings()")


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = StandaloneWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()