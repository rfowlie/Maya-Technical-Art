import sys
from PySide2 import QtGui
from PySide2 import QtWidgets

import images_rc


class StandaloneWindow(QtWidgets.QWidget):

    def __init__(self):
        super(StandaloneWindow, self).__init__(parent=None)

        self.setWindowTitle("Resource File Test")

        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)

        self.add_button(main_layout, ":/images/stop.png")
        self.add_button(main_layout, ":/images/play.png")
        self.add_button(main_layout, ":/images/pause.png")
        self.add_button(main_layout, ":/images/seekend.png")
        self.add_button(main_layout, ":/images/nextkeyframe.png")


    def add_button(self, layout, image_path):
        pixmap = QtGui.QPixmap(image_path)
        button = QtWidgets.QPushButton(QtGui.QIcon(pixmap), "")
        button.setFixedSize(24, 24)

        layout.addWidget(button)

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = StandaloneWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
