import sys

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets


class ColorWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(ColorWidget, self).__init__(parent)

        self._color = QtGui.QColor(127, 127, 127)

    def get_color(self):
        return self._color

    def set_color(self, new_color):
        self._color = new_color
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.fillRect(self.geometry(), self._color)

    color = QtCore.Property(QtGui.QColor, get_color, set_color)


class AnimatedWindow(QtWidgets.QWidget):

    def __init__(self):
        super(AnimatedWindow, self).__init__(parent=None)

        self.setWindowTitle("Animated Properties")
        self.setMinimumSize(500, 400)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.bg_wdg = ColorWidget()

        self.color_1_btn = QtWidgets.QPushButton("Red")
        self.color_2_btn = QtWidgets.QPushButton("Green")
        self.color_3_btn = QtWidgets.QPushButton("Blue")

    def create_layout(self):
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.color_1_btn)
        btn_layout.addWidget(self.color_2_btn)
        btn_layout.addWidget(self.color_3_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addWidget(self.bg_wdg)
        main_layout.addLayout(btn_layout)

    def create_connections(self):
        self.color_1_btn.clicked.connect(self.update_color)
        self.color_2_btn.clicked.connect(self.update_color)
        self.color_3_btn.clicked.connect(self.update_color)

    def update_color(self):
        current_color = self.bg_wdg.get_color()

        if self.sender() == self.color_1_btn:
            new_color = QtGui.QColor(255, 0, 0)
        elif self.sender() == self.color_2_btn:
            new_color = QtGui.QColor(0, 255, 0)
        elif self.sender() == self.color_3_btn:
            new_color = QtGui.QColor(0, 0, 255)
        else:
            return

        # self.bg_wdg.set_color(new_color)

        self.color_anim = QtCore.QPropertyAnimation(self.bg_wdg, b"color")
        self.color_anim.setStartValue(current_color)
        self.color_anim.setEndValue(new_color)
        self.color_anim.setDuration(1000)
        self.color_anim.start()
        

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = AnimatedWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()