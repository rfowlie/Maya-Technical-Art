import sys
from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets


class ValueLadder(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(ValueLadder, self).__init__(parent)

        self.setMinimumSize(60, 140)


class LadderSpinBox(QtWidgets.QDoubleSpinBox):

    def __init__(self, parent=None):
        super(LadderSpinBox, self).__init__(parent)

        self.value_ladder = None

        self.setButtonSymbols(QtWidgets.QDoubleSpinBox.NoButtons)
        self.setMinimum(-9999.9999)
        self.setMaximum(9999.9999)
        self.setDecimals(4)


class StandaloneWindow(QtWidgets.QWidget):

    def __init__(self):
        super(StandaloneWindow, self).__init__(parent=None)

        self.setWindowTitle("Value Ladder")
        self.setMinimumWidth(250)

        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        self.translate_sb = LadderSpinBox()
        self.rotate_sb = LadderSpinBox()
        self.scale_sb = LadderSpinBox()

    def create_layout(self):
        main_layout = QtWidgets.QFormLayout(self)
        main_layout.addRow("Translate", self.translate_sb)
        main_layout.addRow("Rotate", self.rotate_sb)
        main_layout.addRow("Scale", self.scale_sb)


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = StandaloneWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()

