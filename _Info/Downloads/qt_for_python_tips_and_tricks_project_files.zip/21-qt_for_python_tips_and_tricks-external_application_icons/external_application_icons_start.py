import sys

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets


class ApplicationButtonWdg(QtWidgets.QWidget):

    BUTTON_SIZE = QtCore.QSize(48, 48)


    def __init__(self, name, application_path, parent=None):
        super(ApplicationButtonWdg, self).__init__(parent)

        self.application_path = application_path

        self.button = self.create_button()

        self.label = QtWidgets.QLabel("<b>{0}</b>".format(name))

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.setAlignment(QtCore.Qt.AlignCenter)
        button_layout.addWidget(self.button)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addLayout(button_layout)
        main_layout.addWidget(self.label)

    def create_button(self):
        button = QtWidgets.QToolButton()
        button.setFixedSize(ApplicationButtonWdg.BUTTON_SIZE)

        button.clicked.connect(self.open_application)

        return button

    def open_application(self):
        print("Open Application: {0}".format(self.application_path))


class ApplicationLauncher(QtWidgets.QWidget):

    def __init__(self):
        super(ApplicationLauncher, self).__init__(parent=None)

        self.setWindowTitle("Application Launcher")
        self.setMinimumSize(400, 200)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.maya_2022_btn = ApplicationButtonWdg("Maya 2022", "C:/Program Files/Autodesk/Maya2022/bin/maya.exe")
        self.maya_2020_btn = ApplicationButtonWdg("Maya 2020", "C:/Program Files/Autodesk/Maya2020/bin/maya.exe")
        self.maya_2019_btn = ApplicationButtonWdg("Maya 2019", "C:/Program Files/Autodesk/Maya2019/bin/maya.exe")

        self.photoshop_btn = ApplicationButtonWdg("Photoshop", "C:/Program Files/Adobe/Adobe Photoshop 2021/Photoshop.exe")

        self.visual_studio_btn = ApplicationButtonWdg("Visual Studio", "C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/Common7/IDE/devenv.exe")
        self.vs_code_btn = ApplicationButtonWdg("VS Code", "C:/Users/czurbrigg/AppData/Local/Programs/Microsoft VS Code/Code.exe")

    def create_layout(self):
        top_layout = QtWidgets.QHBoxLayout()
        top_layout.addWidget(self.maya_2022_btn)
        top_layout.addWidget(self.maya_2020_btn)
        top_layout.addWidget(self.maya_2019_btn)
        top_layout.addStretch()
        top_layout.addWidget(self.photoshop_btn)

        bottom_layout = QtWidgets.QHBoxLayout()
        bottom_layout.addWidget(self.visual_studio_btn)
        bottom_layout.addWidget(self.vs_code_btn)
        bottom_layout.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addLayout(top_layout)
        main_layout.addLayout(bottom_layout)
        main_layout.addStretch()

    def create_connections(self):
        pass


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ApplicationLauncher()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()

