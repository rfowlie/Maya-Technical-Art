import math
import sys

from functools import partial

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:
    from PySide2 import QtCore, QtGui, QtWidgets

IMAGE_DIR_PATH = "D:/RadialMenuExample/images"


class RadialMenu(QtWidgets.QDialog):

    WINDOW_WIDTH = 320
    WINDOW_HEIGHT = 200

    OUTER_CIRCLE_RADIUS = 50
    OUTER_CIRCLE_DIAMETER = 2 * OUTER_CIRCLE_RADIUS

    INNER_CIRCLE_RADIUS = 10
    INNER_CIRCLE_DIAMETER = 2 * INNER_CIRCLE_RADIUS

    ICON_WIDTH = 24
    TEXT_WIDTH = 80
    TEXT_HEIGHT = 24
    TEXT_RADIUS = 0.5 * TEXT_HEIGHT

    NUM_ZONES = 8
    ZONE_SPAN_ANGLE = 360 / NUM_ZONES

    def __init__(self, hotkey, parent=None):
        super(RadialMenu, self).__init__(parent)
        self.setFixedSize(self.WINDOW_WIDTH, self.WINDOW_HEIGHT)

        self.setWindowFlags(self.windowFlags() | QtCore.Qt.FramelessWindowHint | QtCore.Qt.Popup)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setMouseTracking(True)

        self.hotkey = hotkey

        self.tools = [None] * self.NUM_ZONES

        self.center_point = QtCore.QPoint(0.5 * self.width(), 0.5 * self.height())
        self.outer_circle_rect = QtCore.QRect(self.center_point.x() - self.OUTER_CIRCLE_RADIUS, self.center_point.y() - self.OUTER_CIRCLE_RADIUS, self.OUTER_CIRCLE_DIAMETER, self.OUTER_CIRCLE_DIAMETER)
        self.inner_circle_rect = QtCore.QRect(self.center_point.x() - self.INNER_CIRCLE_RADIUS, self.center_point.y() - self.INNER_CIRCLE_RADIUS, self.INNER_CIRCLE_DIAMETER, self.INNER_CIRCLE_DIAMETER)

        self.selected_section = -1
        self.active_zone = -1
        self.highlight_bounds = QtCore.QRect(self.center_point.x() - (0.5 * self.height()), 0, self.height(), self.height())
        self.highlight_start_angle = 0

        self.event_filter_obj = None

    def set_tool(self, index, label, icon_path, func):
        if index < 0 or index >= self.NUM_ZONES:
            return

        image = QtGui.QImage(icon_path)
        self.tools[index] = (label, image, func)

    def distance_from_center(self, x, y):
        return math.hypot(x - self.center_point.x(), y - self.center_point.y())

    def point_from_center(self, zone, distance):
        degrees = zone * self.ZONE_SPAN_ANGLE
        radians = math.radians(degrees)

        x1 = self.center_point.x() + (distance * math.cos(radians))
        y1 = self.center_point.y() + (distance * math.sin(radians))

        return x1, y1

    def icon_point(self, zone):
        x, y = self.point_from_center(zone, self.OUTER_CIRCLE_RADIUS)
        x -= 0.5 * self.ICON_WIDTH
        y -= 0.5 * self.ICON_WIDTH

        return x, y

    def label_point(self, zone):
        distance = self.OUTER_CIRCLE_RADIUS + self.TEXT_RADIUS
        x, y = self.point_from_center(zone, distance)

        if zone in [0, 1, 7]:
            x += 2
        elif zone in [2, 6]:
            x -= 0.5 * self.TEXT_WIDTH
        elif zone in [3, 4, 5]:
            x -= 2 + self.TEXT_WIDTH
 
        if zone in [0, 4]:
            y -= 0.5 * self.TEXT_HEIGHT
        elif zone in [1, 3]:
            y -= 0.3 * self.TEXT_HEIGHT
        elif zone in [5, 7]:
            y -= 0.7 * self.TEXT_HEIGHT
        elif zone == 2:
            y += 2
        elif zone == 6:
            y -= 2 + self.TEXT_HEIGHT

        return x, y

    def update_active_zone(self, pos):
        if self.distance_from_center(pos.x(), pos.y()) <= self.INNER_CIRCLE_RADIUS or not self.rect().contains(pos):
            self.clear_active_zone()
            return
        
        point = pos - self.center_point
        degrees = math.degrees(math.atan2(point.y(), point.x())) % 360

        start_angle_offset = -0.5 * self.ZONE_SPAN_ANGLE
        degrees = (degrees + start_angle_offset) % 360

        temp_section = math.floor(degrees / self.ZONE_SPAN_ANGLE)

        if self.selected_section != temp_section:
            self.selected_section = temp_section

            self.highlight_start_angle = (self.selected_section * self.ZONE_SPAN_ANGLE) - start_angle_offset
            self.active_zone = (self.selected_section + 1) % 8

            self.update()

    def clear_active_zone(self):
        self.active_zone = -1
        self.selected_section = -1

        self.update()

    def activate_selection(self):
        if self.active_zone >= 0 and self.tools[self.active_zone]:
            self.tools[self.active_zone][2]()

        self.set_event_filter_obj(None)

        self.hide()

    def set_event_filter_obj(self, event_filter_obj):
        if self.event_filter_obj:
            self.event_filter_obj.removeEventFilter(self)
            self.event_filter_obj = None

        if event_filter_obj:
            self.event_filter_obj = event_filter_obj
            self.event_filter_obj.installEventFilter(self)

    def eventFilter(self, obj, event):
        if obj == self.event_filter_obj:
            if event.type() == QtCore.QEvent.MouseMove:
                try:
                    global_pos = event.globalPosition().toPoint()  # Qt6
                except:
                    global_pos = self.event_filter_obj.mapToGlobal(event.pos())  # Qt5

                menu_pos = self.mapFromGlobal(global_pos)
                self.update_active_zone(menu_pos)

                return True
            
            elif event.type() == QtCore.QEvent.MouseButtonRelease:
                if event.button() == QtCore.Qt.LeftButton:
                    self.activate_selection()
                    return True

        return False

    def show_menu(self, event_filter_obj):
        pop_up_pos = QtGui.QCursor.pos() - self.center_point
        self.move(pop_up_pos)

        self.set_event_filter_obj(event_filter_obj)

        self.show()

    def showEvent(self, show_event):
        self.setFocus(QtCore.Qt.PopupFocusReason)

    def paintEvent(self, paint_event):
        painter = QtGui.QPainter(self)
        painter.setRenderHints(QtGui.QPainter.Antialiasing)

        # Clickable area
        painter.setPen(QtCore.Qt.transparent)
        painter.setBrush(QtGui.QColor(0, 0, 0, 1))
        painter.drawRect(self.rect())

        # Outer Circle
        radial_grad = QtGui.QRadialGradient(self.center_point, 50)
        radial_grad.setColorAt(.1, QtGui.QColor(0, 0, 0, 255))
        radial_grad.setColorAt(1, QtGui.QColor(0, 0, 0, 1))
        painter.setBrush(radial_grad)

        circle_pen = QtGui.QPen(QtCore.Qt.cyan, 2)
        painter.setPen(circle_pen)
        painter.drawEllipse(self.outer_circle_rect)

        # Zone Highlight
        if self.active_zone >= 0:
            radial_grad2 = QtGui.QRadialGradient(self.center_point, 80)
            radial_grad2.setColorAt(0, QtGui.QColor(255, 255, 255, 255))
            radial_grad2.setColorAt(0.9, QtGui.QColor(0, 0, 0, 1))
            painter.setBrush(radial_grad2)

            painter.setPen(QtCore.Qt.transparent)

            painter.drawPie(self.highlight_bounds, -self.highlight_start_angle * 16, -self.ZONE_SPAN_ANGLE * 16)

        # Inner Circle
        painter.setBrush(QtCore.Qt.black)
        painter.setPen(circle_pen)
        painter.drawEllipse(self.inner_circle_rect)

        # Icon and Text
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)

        for i in range(self.NUM_ZONES):
            if self.tools[i]:
                icon_x, icon_y = self.icon_point(i)
                painter.drawImage(icon_x, icon_y, self.tools[i][1])

                if i == self.active_zone:
                    painter.setBrush(QtGui.QColor(255, 255, 0, 127))
                else:
                    painter.setBrush(QtGui.QColor(0, 0, 0, 127))

                label_x, label_y = self.label_point(i)

                painter.setPen(QtCore.Qt.transparent)
                painter.drawRoundedRect(label_x, label_y, self.TEXT_WIDTH, self.TEXT_HEIGHT, self.TEXT_RADIUS, self.TEXT_RADIUS)

                painter.setPen(QtCore.Qt.white)
                painter.drawText(label_x, label_y, self.TEXT_WIDTH, self.TEXT_HEIGHT, QtCore.Qt.AlignCenter, self.tools[i][0])


class TestWindow(QtWidgets.QMainWindow):

    def __init__(self, parent=None):
        super(TestWindow, self).__init__(parent=None)

        self.setWindowTitle("Radial Menu Example")
        self.setFixedSize(960, 540)

        self.setStyleSheet("QWidget {{background-image: url({0}/maya_bg.png) }}".format(IMAGE_DIR_PATH))

        self.radial_menus = []
        self.active_menu = None

        self.create_radial_menus()
        self.clear_current_key_down()

    def create_radial_menus(self):
        radial_menu = RadialMenu(QtCore.Qt.Key_1, self)
        for i in range(0, RadialMenu.NUM_ZONES):
            radial_menu.set_tool(i, "Tool {0}".format(i), "{0}/tool_icon_{1}.png".format(IMAGE_DIR_PATH, i), partial(self.activate_tool, i))
        self.radial_menus.append(radial_menu)

        radial_menu = RadialMenu(QtCore.Qt.Key_2, self)
        for i in range(0, RadialMenu.NUM_ZONES, 2):
            radial_menu.set_tool(i, "Tool {0}".format(i), "{0}/tool_icon_{1}.png".format(IMAGE_DIR_PATH, i), partial(self.activate_tool, i))
        self.radial_menus.append(radial_menu)

        radial_menu = RadialMenu(QtCore.Qt.Key_3, self)
        for i in range(1, RadialMenu.NUM_ZONES, 2):
            radial_menu.set_tool(i, "Tool {0}".format(i), "{0}/tool_icon_{1}.png".format(IMAGE_DIR_PATH, i), partial(self.activate_tool, i))
        self.radial_menus.append(radial_menu)

    def clear_current_key_down(self):
        self.current_key_down = None

    def keyPressEvent(self, key_event):
        if not key_event.isAutoRepeat():
            self.current_key_down = key_event.key()

    def keyReleaseEvent(self, key_event):
        if not key_event.isAutoRepeat():
            self.clear_current_key_down()

    def mousePressEvent(self, mouse_event):
        if mouse_event.button() == QtCore.Qt.LeftButton:
            if self.current_key_down:
                for radial_menu in self.radial_menus:
                    if radial_menu.hotkey == self.current_key_down:
                        self.active_menu = radial_menu
                        self.active_menu.show_menu(self)
                        break

    def activate_tool(self, tool_index):
        print("Activate tool for index: {0}".format(tool_index))


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = TestWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
