import sys

from PySide2 import QtWidgets


class AdvancedOptionsWdg(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(AdvancedOptionsWdg, self).__init__(parent=parent)

        self.setFixedHeight(35)

        self.option_1_cb = QtWidgets.QCheckBox("Option 1")
        self.option_2_cb = QtWidgets.QCheckBox("Option 2")
        self.option_3_cb = QtWidgets.QCheckBox("Option 3")

        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.addWidget(self.option_1_cb)
        main_layout.addWidget(self.option_2_cb)
        main_layout.addWidget(self.option_3_cb)
        main_layout.addStretch()


class ExampleWindow(QtWidgets.QWidget):

    MAIN_LAYOUT_SPACING = 6

    def __init__(self):
        super(ExampleWindow, self).__init__(parent=None)

        self.setWindowTitle("Resizing Example")
        self.setMinimumSize(400, 300)

        self.plain_text_edit = QtWidgets.QPlainTextEdit()

        self.advanced_options_wdg = AdvancedOptionsWdg()
        self.advanced_options_wdg.setVisible(False)

        self.advanced_btn = QtWidgets.QPushButton("Advanced")
        self.advanced_btn.clicked.connect(self.toggle_advanced_vis)

        self.ok_btn = QtWidgets.QPushButton("OK")
        self.ok_btn.clicked.connect(self.close)

        self.cancel_btn = QtWidgets.QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.close)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addWidget(self.advanced_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.ok_btn)
        button_layout.addWidget(self.cancel_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setSpacing(ExampleWindow.MAIN_LAYOUT_SPACING)
        main_layout.addWidget(self.plain_text_edit)
        main_layout.addLayout(button_layout)
        main_layout.addWidget(self.advanced_options_wdg)

    def toggle_advanced_vis(self):
        advanced_options_height = self.advanced_options_wdg.height() + ExampleWindow.MAIN_LAYOUT_SPACING

        visible = self.advanced_options_wdg.isVisible()
        self.advanced_options_wdg.setVisible(not visible)

        if visible:
            self.resize(self.width(), self.height() - advanced_options_height)
        else:
            self.resize(self.width(), self.height() + advanced_options_height)


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ExampleWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()

