import math
import sys

from functools import partial

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets

IMAGE_DIR_PATH = "D:/RadialMenuExample/images"


class RadialMenu(QtWidgets.QWidget):

    WINDOW_WIDTH = 320
    WINDOW_HEIGHT = 200

    OUTER_CIRCLE_RADIUS = 50
    OUTER_CIRCLE_DIAMETER = 2 * OUTER_CIRCLE_RADIUS

    INNER_CIRCLE_RADIUS = 10
    INNER_CIRCLE_DIAMETER = 2 * INNER_CIRCLE_RADIUS

    ICON_WIDTH = 24
    TEXT_WIDTH = 80
    TEXT_HEIGHT = 24
    TEXT_RADIUS = 0.5 * TEXT_HEIGHT

    NUM_ZONES = 8

    def __init__(self, hotkey, parent=None):
        super(RadialMenu, self).__init__(parent)
        self.setFixedSize(self.WINDOW_WIDTH, self.WINDOW_HEIGHT)

        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)

        self.hotkey = hotkey

    def paintEvent(self, paint_event):
        painter = QtGui.QPainter(self)
        painter.setRenderHints(QtGui.QPainter.Antialiasing)

        painter.setPen(QtCore.Qt.green)
        painter.drawRect(self.rect())


class TestWindow(QtWidgets.QMainWindow):

    def __init__(self, parent=None):
        super(TestWindow, self).__init__(parent=None)

        self.setWindowTitle("Radial Menu Example")
        self.setFixedSize(960, 540)

        self.setStyleSheet("QWidget {{background-image: url({0}/maya_bg.png) }}".format(IMAGE_DIR_PATH))

        self.radial_menus = []

        radial_menu = RadialMenu(QtCore.Qt.Key_0)
        self.radial_menus.append(radial_menu)

    def keyPressEvent(self, key_event):
        key = key_event.key()

        if not key_event.isAutoRepeat():
            for radial_menu in self.radial_menus:
                if key == radial_menu.hotkey:
                    radial_menu.show()

    def closeEvent(self, close_event):
        for radial_menu in self.radial_menus:
            radial_menu.deleteLater()


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = TestWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
