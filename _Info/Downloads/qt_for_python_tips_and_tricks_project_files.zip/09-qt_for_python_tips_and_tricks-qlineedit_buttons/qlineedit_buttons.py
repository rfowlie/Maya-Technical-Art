import sys
from PySide2 import QtGui
from PySide2 import QtWidgets

class StandaloneWindow(QtWidgets.QWidget):

    def __init__(self):
        super(StandaloneWindow, self).__init__(parent=None)

        self.setWindowTitle("QLineEdit Example")
        self.setMinimumWidth(400)

        self.lineedit = QtWidgets.QLineEdit()

        self.le_btn_action = self.lineedit.addAction(QtGui.QIcon("D:/Sandbox/clear.png"), QtWidgets.QLineEdit.TrailingPosition)
        self.le_btn_action.setToolTip("Clear")
        self.le_btn_action.triggered.connect(self.clear_line_edit)

        main_layout = QtWidgets.QFormLayout(self)
        main_layout.addRow("Filename:", self.lineedit)

    def clear_line_edit(self):
        self.lineedit.setText("")


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = StandaloneWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
