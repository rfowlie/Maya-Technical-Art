import sys

from PySide2 import QtWidgets


class ExampleWindow(QtWidgets.QWidget):

    def __init__(self):
        super(ExampleWindow, self).__init__(parent=None)

        self.setWindowTitle("Undo/Redo Example")
        self.setMinimumSize(400, 300)

        self.create_widgets()
        self.create_layout()

    def add_item(self):
        item_name, ok = QtWidgets.QInputDialog.getText(self, "Item Name", "Item name:")
        if ok and item_name:
            self.list_widget.addItem(item_name)

        self.list_widget.setFocus()

    def delete_item(self):
        self.list_widget.takeItem(self.list_widget.currentRow())

        self.list_widget.setFocus()

    def undo(self):
        print("TODO: undo()")

    def redo(self):
        print("TODO: redo()")

    def create_widgets(self):
        self.list_widget = QtWidgets.QListWidget()
        self.list_widget.addItems(["Item 01", "Item 02", "Item 03"])

        self.add_item_btn = QtWidgets.QPushButton("Add Item")
        self.add_item_btn.clicked.connect(self.add_item)

        self.delete_item_btn = QtWidgets.QPushButton("Delete")
        self.delete_item_btn.clicked.connect(self.delete_item)
        
        self.undo_btn = QtWidgets.QPushButton("Undo")
        self.undo_btn.clicked.connect(self.undo)
        
        self.redo_btn = QtWidgets.QPushButton("Redo")
        self.redo_btn.clicked.connect(self.redo)

    def create_layout(self):
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addWidget(self.add_item_btn)
        button_layout.addWidget(self.delete_item_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.undo_btn)
        button_layout.addWidget(self.redo_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(self.list_widget)
        main_layout.addLayout(button_layout)


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ExampleWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()

