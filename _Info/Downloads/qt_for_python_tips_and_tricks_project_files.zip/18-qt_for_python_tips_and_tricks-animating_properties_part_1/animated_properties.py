import sys

from PySide2 import QtCore
from PySide2 import QtWidgets


class AnimatedWindow(QtWidgets.QWidget):

    def __init__(self):
        super(AnimatedWindow, self).__init__(parent=None)

        self.setWindowTitle("Animated Properties")
        self.setMinimumSize(500, 400)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.bg_wdg = QtWidgets.QWidget(self)
        self.bg_wdg.setStyleSheet("background-color:white;")

        self.ball_wdg = QtWidgets.QWidget(self.bg_wdg)
        self.ball_wdg.setStyleSheet("background-color:red;")
        self.ball_wdg.setFixedSize(20, 20)

        self.up_btn = QtWidgets.QPushButton("↑")
        self.up_btn.setFixedSize(24, 24)
        self.down_btn = QtWidgets.QPushButton("↓")
        self.down_btn.setFixedSize(24, 24)
        self.left_btn = QtWidgets.QPushButton("←")
        self.left_btn.setFixedSize(24, 24)
        self.right_btn = QtWidgets.QPushButton("→")
        self.right_btn.setFixedSize(24, 24)

        self.stop_ball_btn = QtWidgets.QPushButton("Stop")

    def create_layout(self):
        top_layout = QtWidgets.QHBoxLayout()
        top_layout.addStretch()
        top_layout.addWidget(self.up_btn)
        top_layout.addStretch()

        left_layout = QtWidgets.QVBoxLayout()
        left_layout.addStretch()
        left_layout.addWidget(self.left_btn)
        left_layout.addStretch()

        right_layout = QtWidgets.QVBoxLayout()
        right_layout.addStretch()
        right_layout.addWidget(self.right_btn)
        right_layout.addStretch()

        mid_layout = QtWidgets.QHBoxLayout()
        mid_layout.addLayout(left_layout)
        mid_layout.addWidget(self.bg_wdg)
        mid_layout.addLayout(right_layout)

        bottom_layout = QtWidgets.QHBoxLayout()
        bottom_layout.addStretch()
        bottom_layout.addWidget(self.down_btn)
        bottom_layout.addStretch()

        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addWidget(self.stop_ball_btn)
        btn_layout.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.setSpacing(0)
        main_layout.addLayout(top_layout)
        main_layout.addLayout(mid_layout)
        main_layout.addLayout(bottom_layout)
        main_layout.addSpacing(4)
        main_layout.addLayout(btn_layout)

    def create_connections(self):
        self.up_btn.clicked.connect(self.move_ball)
        self.down_btn.clicked.connect(self.move_ball)
        self.left_btn.clicked.connect(self.move_ball)
        self.right_btn.clicked.connect(self.move_ball)

        self.stop_ball_btn.clicked.connect(self.stop_ball)

    def move_ball(self):
        start_pos = self.ball_wdg.pos()
        end_pos = QtCore.QPoint(start_pos)
        
        if self.sender() == self.up_btn:
            end_pos.setY(0)
        elif self.sender() == self.down_btn:
            end_pos.setY(self.bg_wdg.height() - self.ball_wdg.height())
        elif self.sender() == self.left_btn:
            end_pos.setX(0)
        elif self.sender() == self.right_btn:
            end_pos.setX(self.bg_wdg.width() - self.ball_wdg.width())
        else:
            return

        self.ball_anim = QtCore.QPropertyAnimation(self.ball_wdg, b"pos")
        self.ball_anim.setEasingCurve(QtCore.QEasingCurve(QtCore.QEasingCurve.InOutQuad))
        self.ball_anim.setStartValue(start_pos)
        self.ball_anim.setEndValue(end_pos)
        self.ball_anim.setDuration(2000)
        self.ball_anim.start()

    def stop_ball(self):
        self.ball_anim.stop()
        

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = AnimatedWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
