from PySide2 import QtCore

QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.DocumentsLocation)
QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.DesktopLocation)
QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.HomeLocation)
QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.TempLocation)
QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.FontsLocation)
QtCore.QStandardPaths.standardLocations(QtCore.QStandardPaths.ApplicationsLocation)

QtCore.QStandardPaths.findExecutable("maya.exe")

QtCore.QStandardPaths.locate(QtCore.QStandardPaths.DocumentsLocation, "maya/2023", QtCore.QStandardPaths.LocateDirectory)
