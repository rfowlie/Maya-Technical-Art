import sys

from PySide2 import QtCore
from PySide2 import QtWidgets
from shiboken2 import wrapInstance


class TreeViewWindow(QtWidgets.QWidget):

    WINDOW_TITLE = "File View"

    ROOT_FOLDER_PATH = "C:/Users/czurbrigg/Documents/maya/scripts"


    def __init__(self, parent=None):
        super(TreeViewWindow, self).__init__(parent)

        self.setWindowTitle(self.WINDOW_TITLE)
        self.setMinimumSize(500, 400)

        self.create_widgets()
        self.create_layout()

        self.tree_view.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree_view.customContextMenuRequested.connect(self.show_context_menu)

    def create_widgets(self):
        root_path = TreeViewWindow.ROOT_FOLDER_PATH

        self.model = QtWidgets.QFileSystemModel()
        self.model.setRootPath(root_path)

        self.tree_view = QtWidgets.QTreeView()
        self.tree_view.setModel(self.model)
        self.tree_view.setRootIndex(self.model.index(root_path))
        self.tree_view.hideColumn(1)
        self.tree_view.setColumnWidth(0, 240)

        self.model.setNameFilters(["*.py"])
        self.model.setNameFilterDisables(False)

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.addWidget(self.tree_view)

    def show_context_menu(self, pos):
        context_menu = QtWidgets.QMenu(self)

        context_menu.addAction("Common Action 01")
        context_menu.addAction("Common Action 02")
        context_menu.addAction("Common Action 03")
        context_menu.addSeparator()

        context_menu.exec_(self.tree_view.viewport().mapToGlobal(pos))


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = TreeViewWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()