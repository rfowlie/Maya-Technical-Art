import sys

from PySide2 import QtCore
from PySide2 import QtWidgets
from shiboken2 import wrapInstance


class TreeViewWindow(QtWidgets.QWidget):

    WINDOW_TITLE = "File View"

    ROOT_FOLDER_PATH = "C:/Users/czurbrigg/Documents/maya/scripts"


    def __init__(self, parent=None):
        super(TreeViewWindow, self).__init__(parent)

        self.setWindowTitle(self.WINDOW_TITLE)
        self.setMinimumSize(500, 400)

        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        self.always_on_top_action = QtWidgets.QAction("Always On Top")
        self.always_on_top_action.setCheckable(True)
        self.always_on_top_action.setChecked(False)
        self.always_on_top_action.toggled.connect(self.set_always_on_top_enabled)

        self.menu_bar = QtWidgets.QMenuBar()
        edit_menu = self.menu_bar.addMenu("Edit")
        edit_menu.addAction(self.always_on_top_action)

        root_path = TreeViewWindow.ROOT_FOLDER_PATH

        self.model = QtWidgets.QFileSystemModel()
        self.model.setRootPath(root_path)

        self.tree_view = QtWidgets.QTreeView()
        self.tree_view.setModel(self.model)
        self.tree_view.setRootIndex(self.model.index(root_path))
        self.tree_view.hideColumn(1)
        self.tree_view.setColumnWidth(0, 240)

        self.model.setNameFilters(["*.py"])
        self.model.setNameFilterDisables(False)

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.addWidget(self.menu_bar)
        main_layout.addWidget(self.tree_view)

    def set_always_on_top_enabled(self, enabled):
        print("TODO: set_always_on_top_enabled: {0}".format(enabled))


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = TreeViewWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()