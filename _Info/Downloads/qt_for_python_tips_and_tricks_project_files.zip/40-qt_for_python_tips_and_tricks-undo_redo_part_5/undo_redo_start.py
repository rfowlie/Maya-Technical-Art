import sys

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets


class AddItemCmd(QtWidgets.QUndoCommand):
    
    def __init__(self, list_widget, item_text):
        super(AddItemCmd, self).__init__()

        self.setText("AddItem")

        self.list_widget = list_widget
        self.item_text = item_text

    def undo(self):
        self.list_widget.takeItem(self.list_widget.count() - 1)

    def redo(self):
        self.list_widget.addItem(self.item_text)


class DeleteItemCmd(QtWidgets.QUndoCommand):
    
    def __init__(self, list_widget, row):
        super(DeleteItemCmd, self).__init__()

        self.setText("DeleteItem")

        self.list_widget = list_widget
        self.row = row
        self.item = None

    def undo(self):
        if self.item:
            self.list_widget.insertItem(self.row, self.item)

    def redo(self):
        self.item = self.list_widget.takeItem(self.row)


class ExampleWindow(QtWidgets.QWidget):

    def __init__(self):
        super(ExampleWindow, self).__init__(parent=None)

        self.setWindowTitle("Undo/Redo Example")
        self.setMinimumSize(400, 300)

        self.undo_stack = QtWidgets.QUndoStack()

        self.create_actions()
        self.create_widgets()
        self.create_menus()
        self.create_layout()
        self.create_connections()

    def add_item(self):
        item_name, ok = QtWidgets.QInputDialog.getText(self, "Item Name", "Item name:")
        if ok and item_name:
            # Push cmd on stack and call its redo() method
            self.undo_stack.push(AddItemCmd(self.list_widget, item_name))

        self.list_widget.setFocus()

    def add_three(self):
        self.undo_stack.push(AddItemCmd(self.list_widget, "Add Three 01"))
        self.undo_stack.push(AddItemCmd(self.list_widget, "Add Three 02"))
        self.undo_stack.push(AddItemCmd(self.list_widget, "Add Three 03"))

        self.list_widget.setFocus()

    def delete_item(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            self.undo_stack.push(DeleteItemCmd(self.list_widget, row))

        self.list_widget.setFocus()

    def delete_all(self):
        for i in range(0, self.list_widget.count()):
            self.undo_stack.push(DeleteItemCmd(self.list_widget, 0))

        self.list_widget.setFocus()

    def undo(self):
        if self.undo_stack.canUndo():
            self.undo_stack.undo()
        else:
            print("There are no more commands to undo")

    def redo(self):
        if self.undo_stack.canRedo():
            self.undo_stack.redo()
        else:
            print("There are no more commands to redo")

    def show_undo_view(self):
        print("TODO: show_undo_view()")

    def clear_stack(self):
        print("TODO: clear_stack")

    def create_actions(self):
        self.undo_view_action = QtWidgets.QAction("Undo View...")

    def create_widgets(self):
        self.menu_bar = QtWidgets.QMenuBar()

        self.list_widget = QtWidgets.QListWidget()
        self.list_widget.addItems(["Item 01", "Item 02", "Item 03"])

        self.add_item_btn = QtWidgets.QPushButton("Add Item")
        self.add_three_btn = QtWidgets.QPushButton("Add Three")

        self.delete_item_btn = QtWidgets.QPushButton("Delete")
        self.delete_all_btn = QtWidgets.QPushButton("Delete All")

        self.undo_btn = QtWidgets.QPushButton("Undo")
        self.redo_btn = QtWidgets.QPushButton("Redo")

    def create_menus(self):
        edit_menu = QtWidgets.QMenu("Edit")
        self.menu_bar.addMenu(edit_menu)
        edit_menu.addAction(self.undo_view_action)

    def create_layout(self):
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addWidget(self.add_item_btn)
        button_layout.addWidget(self.add_three_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.undo_btn)
        button_layout.addWidget(self.redo_btn)

        button_layout_2 = QtWidgets.QHBoxLayout()
        button_layout_2.addWidget(self.delete_item_btn)
        button_layout_2.addWidget(self.delete_all_btn)
        button_layout_2.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setMenuBar(self.menu_bar)
        main_layout.addWidget(self.list_widget)
        main_layout.addLayout(button_layout)
        main_layout.addLayout(button_layout_2)

    def create_connections(self):
        self.add_item_btn.clicked.connect(self.add_item)
        self.add_three_btn.clicked.connect(self.add_three)
        self.delete_item_btn.clicked.connect(self.delete_item)
        self.delete_all_btn.clicked.connect(self.delete_all)
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn.clicked.connect(self.redo)

        self.undo_view_action.triggered.connect(self.show_undo_view)

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ExampleWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()

