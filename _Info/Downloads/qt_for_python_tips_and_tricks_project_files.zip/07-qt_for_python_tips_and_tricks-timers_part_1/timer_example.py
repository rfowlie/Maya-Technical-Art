import sys
from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets


class CustomTimeWidget(QtWidgets.QWidget):

    def __init__(self):
        super(CustomTimeWidget, self).__init__(parent=None)

        self.setFixedHeight(50)

        self.milliseconds = 0

    def set_time(self, milliseconds):
        if self.milliseconds != milliseconds:
            self.milliseconds = milliseconds

            self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)

        pen = painter.pen()
        pen.setColor(QtCore.Qt.black)
        painter.setPen(pen)

        font = QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)
        font.setPointSize(30)
        font.setWeight(QtGui.QFont.Bold)
        painter.setFont(font)

        milliseconds = self.milliseconds % 1000
        seconds = int(self.milliseconds / 1000 % 60)
        minutes = int(self.milliseconds / 60000 % 60)
        hours = int(self.milliseconds / 3600000)
        
        text = "{0}:{1}:{2}.{3}".format(str(hours).zfill(2), str(minutes).zfill(2), str(seconds).zfill(2), str(milliseconds).zfill(3))
        painter.drawText(0, 0, self.width(), self.height(), 0, text)


class StandaloneWindow(QtWidgets.QWidget):

    def __init__(self):
        super(StandaloneWindow, self).__init__(parent=None)

        self.setWindowTitle("QTimer Example")
        self.setMinimumSize(300, 100)

        self.total_elapsed_time = 0
        self.prev_elapsed_time = 0

        self.create_widgets()
        self.create_layout()
        self.create_timers()
        self.create_connections()
        

    def create_widgets(self):
        self.custom_time_wdg = CustomTimeWidget()

        self.toggle_timer_btn = QtWidgets.QPushButton("Start")
        self.interval_btn = QtWidgets.QPushButton("2 Sec Interval")
        self.reset_btn = QtWidgets.QPushButton("Reset")

    def create_layout(self):
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addWidget(self.toggle_timer_btn)
        button_layout.addWidget(self.interval_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.reset_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.addWidget(self.custom_time_wdg)
        main_layout.addStretch()
        main_layout.addLayout(button_layout)

    def create_timers(self):
        self.update_timer = QtCore.QTimer()
        self.update_timer.setInterval(25)

        self.elapsed_timer = QtCore.QElapsedTimer()

    def create_connections(self):
        self.update_timer.timeout.connect(self.update_elapsed_time)

        self.toggle_timer_btn.clicked.connect(self.toggle_timer_state)
        self.interval_btn.clicked.connect(self.delayed_stop)
        self.reset_btn.clicked.connect(self.reset_timer)

    def update_elapsed_time(self):
        self.custom_time_wdg.set_time(self.total_elapsed_time)

    def toggle_timer_state(self):
        print("TODO: toggle_timer_state()")

    def reset_timer(self):
        print("TODO: reset_timer()")

    def delayed_stop(self):
        print("TODO: delayed_stop()")


if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = StandaloneWindow()
    window.show()

    # Enter Qt main loop (start event handling)
    app.exec_()
