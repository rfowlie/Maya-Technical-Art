try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class CustomDialog(QtWidgets.QDialog):
    """
    A custom dialog for getting a user's name
    """
    
    def __init__(self, parent):
        super().__init__(parent)
        
        self.setWindowTitle("Enter Name")
        
        self.create_widgets()
        self.create_layout()
        self.create_connections()
        
    def create_widgets(self):
        self.lineedit = QtWidgets.QLineEdit()
        self.ok_btn = QtWidgets.QPushButton("OK")
        
    def create_layout(self):
        wdg_layout = QtWidgets.QHBoxLayout()
        wdg_layout.addWidget(QtWidgets.QLabel("Name: "))
        wdg_layout.addWidget(self.lineedit)

        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.ok_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addLayout(wdg_layout)
        main_layout.addLayout(btn_layout)
        
    def create_connections(self):
        pass
        
    def get_text(self):
        return self.lineedit.text()
        
        
class MainDialog(QtWidgets.QDialog):
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Modal Dialogs")
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
        self.initial_directory = cmds.internalVar(userPrefDir=True)
        self.initial_color = QtGui.QColor(255, 0, 0)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.warning_btn = QtWidgets.QPushButton("Warning Msg")
        self.folder_select_btn = QtWidgets.QPushButton("Select Folder")
        self.color_select_btn = QtWidgets.QPushButton("Select Color")
        self.custom_btn = QtWidgets.QPushButton("Custom (Modal)")

    def create_layout(self):
        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.addWidget(self.warning_btn)
        main_layout.addWidget(self.folder_select_btn)
        main_layout.addWidget(self.color_select_btn)
        main_layout.addWidget(self.custom_btn)

    def create_connections(self):
        self.warning_btn.clicked.connect(self.show_warning_dialog)
        self.folder_select_btn.clicked.connect(self.show_folder_select)
        self.color_select_btn.clicked.connect(self.show_color_select)
        self.custom_btn.clicked.connect(self.show_custom_dialog)

    def show_warning_dialog(self):
        """
        Display Qt's warning message dialog
        """
        QtWidgets.QMessageBox.warning(self, "Object Not Found", "Camera 'shotcam' not found.")


    def show_folder_select(self):
        """
        Display Qt's folder select dialog
        """
        new_directory = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Folder", self.initial_directory)
        if new_directory:
            self.initial_directory = new_directory
            
        print("Selected Folder: {0}".format(new_directory))


    def show_color_select(self):
        """
        Display Qt's color select dialog
        """
        self.initial_color = QtWidgets.QColorDialog.getColor(self.initial_color, self)
        
        print("Red:{0}  Green:{1}  Blue:{2}".format(self.initial_color.red(), self.initial_color.green(), self.initial_color.blue()))

    def show_custom_dialog(self):
        """
        Display a user created dialog
        """
        pass
        
        
if __name__ == "__main__":
    try:
        main_dialog.close() # pylint: disable=E0601
        main_dialog.deleteLater()
    except:
        pass
    
    main_dialog = MainDialog()
    main_dialog.show()
    
    
    
    
    
    
    
    
    
    
    