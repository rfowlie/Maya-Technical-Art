import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Scroll Area Example")
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        self.button_list = []
        for i in range(20):
            self.button_list.append(QtWidgets.QPushButton(f"Button {i + 1}"))
            self.button_list[i].setFixedWidth(300)

    def create_layout(self):
        button_list_widget = QtWidgets.QWidget()
        
        button_layout = QtWidgets.QVBoxLayout(button_list_widget)
        for i in range(20):
            button_layout.addWidget(self.button_list[i])
        # button_layout.addStretch()
        
        button_scroll_area = QtWidgets.QScrollArea()
        button_scroll_area.setWidget(button_list_widget)
        # button_scroll_area.setWidgetResizable(True)
        # button_scroll_area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(button_scroll_area)


if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
