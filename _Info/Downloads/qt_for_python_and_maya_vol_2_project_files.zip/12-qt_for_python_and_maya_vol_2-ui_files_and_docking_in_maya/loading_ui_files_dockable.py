try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui

from maya.app.general.mayaMixin import MayaQWidgetDockableMixin

def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class DesignerExample(MayaQWidgetDockableMixin, QtWidgets.QWidget):
    
    OBJECT_NAME = "DesignerExample"
    
    UI_FILE_PATH = "E:/temp/list_widget.ui"
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)
        
        self.setObjectName(self.OBJECT_NAME)
        self.setWindowTitle("Designer Example")
        
        self.init_ui_widget()

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.ui_widget)
        
        self.ui_widget.okButton.clicked.connect(self.do_accept)
        self.ui_widget.cancelButton.clicked.connect(self.do_close)
        
    def init_ui_widget(self):
        f = QtCore.QFile(self.UI_FILE_PATH)
        f.open(QtCore.QFile.ReadOnly)
        
        loader = QtUiTools.QUiLoader()
        self.ui_widget = loader.load(f)
        
        self.ui_widget.okButton.setMinimumWidth(75)
        self.ui_widget.cancelButton.setMinimumWidth(75)
        self.ui_widget.clearButton.setMinimumWidth(75)
        
    def do_accept(self):
        print("TODO: do_accept()")
        
    def do_close(self):
        print("TODO: do_close()")
            
        
if __name__ == "__main__":
    workspace_control_name = "{0}WorkspaceControl".format(DesignerExample.OBJECT_NAME)
    
    if cmds.workspaceControl(workspace_control_name, exists=True):
        cmds.workspaceControl(workspace_control_name, e=True, close=True)
        cmds.deleteUI(workspace_control_name)

    designer_example = DesignerExample()
    designer_example.show(dockable=True)
    
    
    
    
    
    
    
    
    
    
    