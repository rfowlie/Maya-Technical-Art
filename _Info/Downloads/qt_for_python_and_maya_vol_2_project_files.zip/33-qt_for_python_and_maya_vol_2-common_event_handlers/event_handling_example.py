import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Event Handling")
        self.setMinimumSize(300, 200)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
    def closeEvent(self, close_event):
        print("closeEvent() called")
        
        reply = QtWidgets.QMessageBox.question(self, "Close", "Are your sure you want to close?")
        if reply == QtWidgets.QMessageBox.No:
            close_event.ignore()
            
    def showEvent(self, show_event):
        print("showEvent() called")
        
    def hideEvent(self, hide_event):
        print("hideEvent() called")
        
    def resizeEvent(self, resize_event):
        size = resize_event.size()
        print(f"resizeEvent(): {size}")
        
    def enterEvent(self, enter_event):
        # pos = enter_event.globalPos()  # Qt5
        pos = enter_event.globalPosition()  # Qt6
        print(f"enterEvent(): {pos}")
        
    def leaveEvent(self, event):
        print("leaveEvent() called")
    

if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
    
    
