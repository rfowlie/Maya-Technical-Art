import sys
import time

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Progress Bar Example")
        self.setMinimumSize(220, 120)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
        self.test_in_progress = False
            
        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.progress_bar_label = QtWidgets.QLabel("Operation Progress")
        self.progress_bar = QtWidgets.QProgressBar()

        self.do_it_btn = QtWidgets.QPushButton("Do It!")
        self.cancel_btn = QtWidgets.QPushButton("Cancel")
        
        self.update_visibility()

    def create_layout(self):
        progress_layout = QtWidgets.QVBoxLayout()
        progress_layout.addWidget(self.progress_bar_label)
        progress_layout.addWidget(self.progress_bar)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.do_it_btn)
        button_layout.addWidget(self.cancel_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.addLayout(progress_layout)
        main_layout.addStretch()
        main_layout.addLayout(button_layout)
        
    def create_connections(self):
        self.do_it_btn.clicked.connect(self.do_progress_test)
        self.cancel_btn.clicked.connect(self.cancel_progress_test)

    def update_visibility(self):
        self.progress_bar_label.setVisible(self.test_in_progress)
        self.progress_bar.setVisible(self.test_in_progress)
        self.cancel_btn.setVisible(self.test_in_progress)
        
        self.do_it_btn.setHidden(self.test_in_progress)

    def do_progress_test(self):
        if self.test_in_progress:
            return
            
        number_of_operations = 10
        
        self.progress_bar.setRange(0, number_of_operations)
        self.progress_bar.setValue(0)
        self.progress_bar_label.setText("Operation Progress")
        
        self.test_in_progress = True
        self.update_visibility()
        
        for i in range(1, number_of_operations + 1):
            if not self.test_in_progress:
                break
                
            self.progress_bar_label.setText("Processing operation: {0} (of {1})".format(i, number_of_operations))
            self.progress_bar.setValue(i)
            time.sleep(0.5)
            
            QtCore.QCoreApplication.processEvents()
            
        self.test_in_progress = False
        self.update_visibility()
            
        
    def cancel_progress_test(self):
        self.test_in_progress = False



if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
