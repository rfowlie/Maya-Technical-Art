import sys
import time

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Progress Bar Example")
        self.setMinimumSize(220, 120)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.progress_bar_btn = QtWidgets.QPushButton("Do It!")

    def create_layout(self):
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.progress_bar_btn)
        button_layout.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addStretch()
        main_layout.addLayout(button_layout)
        main_layout.addStretch()
        
    def create_connections(self):
        self.progress_bar_btn.clicked.connect(self.do_progress_test)

    def do_progress_test(self):
        print("TODO: do_progress_test()")


if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
