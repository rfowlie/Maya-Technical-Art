import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Event Filtering")
        self.setMinimumSize(400, 200)
        
        self.create_widgets()
        self.create_layout()
        
        self.main_window = maya_main_window()
        self.main_window.installEventFilter(self)
        
        self.filtered_line_edit.installEventFilter(self)
        
    def create_widgets(self):
        self.filtered_line_edit = QtWidgets.QLineEdit()
        self.unfiltered_line_edit = QtWidgets.QLineEdit()
        
    def create_layout(self):
        main_layout = QtWidgets.QFormLayout(self)

        main_layout.addRow("Filtered LE:", self.filtered_line_edit)
        main_layout.addRow("Unfiltered LE:", self.unfiltered_line_edit)
        

    def eventFilter(self, obj, event):
        if obj == self.main_window:
            if self.isVisible():
                if event.type() == QtCore.QEvent.Close:
                    result = QtWidgets.QMessageBox.question(self, "Confirm Close", "Are you sure you want to close?")
                    if result == QtWidgets.QMessageBox.No:
                        event.ignore()
                        return True
                        
        elif obj == self.filtered_line_edit:
            if event.type() == QtCore.QEvent.KeyPress:
                if event.key() == QtCore.Qt.Key_A:
                    print("Invalid key press: 'A'")
                    return True
                    
            elif event.type() == QtCore.QEvent.FocusIn:
                print("Filtered Line Edit gained focus")
            elif event.type() == QtCore.QEvent.FocusOut:
                print("Filtered Line Edit lost focus")
                
        return False
        
        
if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
    
    
    
    
    
    
    