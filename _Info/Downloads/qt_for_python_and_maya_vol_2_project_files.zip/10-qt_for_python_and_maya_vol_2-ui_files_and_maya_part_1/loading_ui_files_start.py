try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class DesignerExample(QtWidgets.QDialog):
    
    UI_FILE_PATH = "E:/temp/list_widget.ui"
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)
        
        self.setWindowTitle("Designer Example")
            
        
if __name__ == "__main__":
    win = DesignerExample()
    win.show()
    
    
    
    
    
    
    
    
    
    
    