import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class TreeViewExample(QtWidgets.QDialog):

    WINDOW_TITLE = "Tree View Example"

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Tree View Example")

        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self.setMinimumSize(500, 400)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        root_path = "{0}scripts".format(cmds.internalVar(userAppDir=True))

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)

    def create_connections(self):
        pass

    def on_double_clicked(self, index):
        pass


if __name__ == "__main__":

    try:
        tree_view_example.close() # pylint: disable=E0601
        tree_view_example.deleteLater()
    except:
        pass

    tree_view_example = TreeViewExample()
    tree_view_example.show()
    
    
    
    
    
    
    
    
    
