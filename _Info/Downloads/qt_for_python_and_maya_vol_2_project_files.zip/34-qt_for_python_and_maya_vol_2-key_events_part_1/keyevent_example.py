import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class CustomPlainTextEdit(QtWidgets.QPlainTextEdit):

    def __init__(self, parent=None):
        super(CustomPlainTextEdit, self).__init__(parent)
        
    def keyPressEvent(self, key_event):
        print("Key Pressed: {0}".format(key_event.text()))
        
        ctrl = key_event.modifiers() == QtCore.Qt.ControlModifier
        ctrl_alt = key_event.modifiers() == (QtCore.Qt.ControlModifier | QtCore.Qt.AltModifier)
        
        key = key_event.key()
        
        if key == QtCore.Qt.Key_Return or key == QtCore.Qt.Key_Enter:
            if ctrl:
                print("Execute Code")
                return
            elif ctrl_alt:
                print("Execute Line")
                return
        
        super().keyPressEvent(key_event)
        
    def keyReleaseEvent(self, key_event):
        print("Key Released: {0}".format(key_event.text()))
        
        super().keyReleaseEvent(key_event)


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Key Events")
        self.setMinimumSize(400, 200)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        plain_text = CustomPlainTextEdit()
        
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.addWidget(plain_text)
        

if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
