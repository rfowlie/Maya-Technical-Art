try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class PreferencesDialog(QtWidgets.QDialog):
    
    UI_FILE_PATH = "E:/temp/preferences.ui"
    
    def __init__(self, parent):
        super().__init__(parent)
        
        self.setWindowTitle("Preferences")
        
        self.init_ui_widget()
        self.create_layout()
        self.create_connections()
        
    def init_ui_widget(self):
        pass
        
    def create_layout(self):
        pass
        
    def create_connections(self):
        pass
        
        
class MainDialog(QtWidgets.QDialog):
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Preferences Example")
        self.setMinimumSize(500, 300)

        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
        self.setMinimumSize(300, 200)

        self.create_actions()
        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_actions(self):
        self.preferences_action = QAction("Preferences...", self)

    def create_widgets(self):
        self.menu_bar = QtWidgets.QMenuBar()
        edit_menu = self.menu_bar.addMenu("Edit")
        edit_menu.addAction(self.preferences_action)

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.setSpacing(2)
        main_layout.setMenuBar(self.menu_bar)

    def create_connections(self):
        self.preferences_action.triggered.connect(self.show_preferences)

    def show_preferences(self):
        print("TODO: show_preferences()")
        
        
if __name__ == "__main__":
    try:
        main_dialog.close() # pylint: disable=E0601
        main_dialog.deleteLater()
    except:
        pass
    
    main_dialog = MainDialog()
    main_dialog.show()
    
    
    
    
    
    
    
    
    
    
    