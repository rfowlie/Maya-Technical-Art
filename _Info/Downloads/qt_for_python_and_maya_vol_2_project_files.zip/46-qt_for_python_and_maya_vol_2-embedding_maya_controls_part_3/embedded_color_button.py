import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ColorButton(QtWidgets.QWidget):
    
    color_changed = QtCore.Signal(QtGui.QColor)
    
    
    def __init__(self, color, parent=None):
        super().__init__(parent)
        
        self.setObjectName("CustomColorButton")

        self.create_control()

        self.set_size(50, 14)
        self.set_color(color)
        

    def create_control(self):
        """ 1) Create the colorSliderGrp using Maya commands """
        window = cmds.window()
        color_slider_name = cmds.colorSliderGrp()

        """ 2) Find the colorSliderGrp widget """
        self._color_slider_obj = omui.MQtUtil.findControl(color_slider_name)
        if self._color_slider_obj:
            self._color_slider_widget = wrapInstance(int(self._color_slider_obj), QtWidgets.QWidget)
        
            """ 3) Reparent the colorSliderGrp widget to this widget """
            main_layout = QtWidgets.QVBoxLayout(self)
            main_layout.setObjectName("main_layout")
            main_layout.setContentsMargins(0, 0, 0, 0)
            main_layout.addWidget(self._color_slider_widget)

            """ 4) Identify/store the colorSliderGrp's child widgets (and hide if necessary) """
            children = self._color_slider_widget.children()
            for child in children:
                print(child)
            print("---")
            
            self._slider_widget = self._color_slider_widget.findChild(QtWidgets.QWidget, "slider")
            if self._slider_widget:
                self._slider_widget.hide()
        
        """ 5) Delete the window used to create the maya control (colorSliderGrp)  """
        cmds.deleteUI(window, window=True)
        
        

    def set_size(self, width, height):
        pass

    def set_color(self, color):
        pass

    def get_color(self):
        pass

    def on_color_changed(self, *args):
        self.color_changed.emit(self.get_color())


class ExampleDialog(QtWidgets.QDialog):

    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Color Button Example")
        self.setMinimumWidth(400)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.foreground_color_btn = ColorButton(QtCore.Qt.white)
        self.background_color_btn = ColorButton(QtCore.Qt.black)

        self.print_fg_color_btn = QtWidgets.QPushButton("Get FG")
        self.print_bg_color_btn = QtWidgets.QPushButton("Get BG")
        
        self.close_btn = QtWidgets.QPushButton("Close")

    def create_layout(self):
        color_layout = QtWidgets.QFormLayout()
        color_layout.addRow("Foreground:", self.foreground_color_btn)
        color_layout.addRow("Background:", self.background_color_btn)

        color_grp = QtWidgets.QGroupBox("Color Options")
        color_grp.setLayout(color_layout)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.setSpacing(2)
        button_layout.addWidget(self.print_fg_color_btn)
        button_layout.addWidget(self.print_bg_color_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.close_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addWidget(color_grp)
        main_layout.addStretch()
        main_layout.addLayout(button_layout)
        
    def create_connections(self):
        self.foreground_color_btn.color_changed.connect(self.on_foreground_color_changed)
        self.background_color_btn.color_changed.connect(self.on_background_color_changed)
        
        self.close_btn.clicked.connect(self.close)
        
    def on_foreground_color_changed(self, new_color):
        print("New foreground color: ({0}, {1}, {2})".format(new_color.red(), new_color.green(), new_color.blue()))

    def on_background_color_changed(self, new_color):
        print("New background color: ({0}, {1}, {2})".format(new_color.red(), new_color.green(), new_color.blue()))


if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
