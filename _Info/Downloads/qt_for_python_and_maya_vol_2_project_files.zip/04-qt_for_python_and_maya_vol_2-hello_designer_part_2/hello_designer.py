try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class DesignerExample(QtWidgets.QDialog):
    
    UI_FILE_PATH = "E:/temp/hello_designer.ui"
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)
        
        self.setWindowTitle("Designer Example")
        self.setFixedSize(250, 60)
        
        self.ui_dialog = None
        
        self.show_dlg_btn = QtWidgets.QPushButton("Show Dialog")

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.show_dlg_btn)
        
        self.show_dlg_btn.clicked.connect(self.show_ui_dialog)
        
    def show_ui_dialog(self):
        if not self.ui_dialog:
            f = QtCore.QFile(self.UI_FILE_PATH)
            f.open(QtCore.QFile.ReadOnly)
            
            loader = QtUiTools.QUiLoader()
            self.ui_dialog = loader.load(f, parentWidget=self)
            
        self.ui_dialog.show()
            
        
if __name__ == "__main__":
    win = DesignerExample()
    win.show()
    
    
    
    
    
    
    
    
    
    
    