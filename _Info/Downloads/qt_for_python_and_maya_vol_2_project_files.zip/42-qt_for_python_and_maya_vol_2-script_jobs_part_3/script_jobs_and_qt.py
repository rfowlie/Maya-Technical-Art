try:
    # Qt5
    from PySide2 import QtCore
    from PySide2 import QtWidgets
    from shiboken2 import wrapInstance
except:
    # Qt6
    from PySide6 import QtCore
    from PySide6 import QtWidgets
    from shiboken6 import wrapInstance
    
import sys
from functools import partial

import maya.OpenMayaUI as omui
import maya.cmds as cmds
    
    
def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)
    

class ToolDialog(QtWidgets.QDialog):
    
    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)
        
        self.setWindowTitle("Script Job Example")
        self.setMinimumSize(300, 140)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
        self.script_jobs = []
            
        self.create_widgets()
        self.create_layout()
        self.create_connections()
            
    def create_widgets(self):
        self.list_widget = QtWidgets.QListWidget()
        self.list_widget.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

        self.refresh_btn = QtWidgets.QPushButton("Refresh")
        
    def create_layout(self):
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.refresh_btn)
        
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(self.list_widget)
        main_layout.addLayout(btn_layout)
        
    def create_connections(self):
        self.list_widget.itemSelectionChanged.connect(self.select_items_in_scene)
        
        self.refresh_btn.clicked.connect(self.refresh_list)
        
    def select_items_in_scene(self):
        selection = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.isSelected():
                selection.append(item.text())
                
        cmds.select(selection)
        
    def refresh_list(self):
        objects_in_scene = cmds.ls(type="transform")
        
        self.list_widget.clear()
        
        for obj in objects_in_scene:
            if obj not in ["top", "side", "front", "persp"]:
                self.list_widget.addItem(obj)
        
        self.update_selection()
        
    def update_selection(self):
        selection = cmds.ls(sl=True)
        
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item.setSelected(item.text() in selection)
        
    def showEvent(self, show_event):
        self.refresh_list()
        
        self.script_jobs.append(cmds.scriptJob(event=["SelectionChanged", partial(self.update_selection)]))
        self.script_jobs.append(cmds.scriptJob(event=["DagObjectCreated", partial(self.refresh_list)]))
        
    def hideEvent(self, hide_event):
        for job_number in self.script_jobs:
            if cmds.scriptJob(exists=job_number):
                cmds.scriptJob(kill=job_number)
                
        self.script_jobs.clear()
        
        
if __name__ == "__main__":
    try:
        win.close()        # pylint: disable=E0601
        win.deleteLater()
    except:
        pass
        
    win = ToolDialog()
    win.show()
    
    
    
    
    
    
    
    