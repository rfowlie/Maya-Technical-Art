import path_helpers


print(path_helpers.get_module_file_path())

print(path_helpers.get_module_dir_path())

print(path_helpers.get_module_file_name())


