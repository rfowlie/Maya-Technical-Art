import sys

try:
    from PySide2 import QtCore  # Qt5
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from PySide2 import QtUiTools
    from shiboken2 import wrapInstance
    
    from PySide2.QtWidgets import QAction
except:
    from PySide6 import QtCore  # Qt6
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from PySide6 import QtUiTools
    from shiboken6 import wrapInstance
    
    from PySide6.QtGui import QAction
    
import maya.cmds as cmds
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class ExampleDialog(QtWidgets.QDialog):

    BALL_COLORS = [QtCore.Qt.blue, QtCore.Qt.red, QtCore.Qt.green]


    def __init__(self, parent=maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Key Events")
        self.setMinimumSize(400, 400)
        
        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
            
        self.ball_pos = QtCore.QPointF(0.5 * self.width(), 0.5 * self.height())
        self.ball_radius = 20
        self.ball_color_index = 0
        
        self.update_ball_position()

    def is_ball_under_mouse(self, x, y):
        bounding_rect = QtCore.QRectF(self.ball_pos.x() - self.ball_radius, self.ball_pos.y() - self.ball_radius, 2 * self.ball_radius, 2 * self.ball_radius)
        return bounding_rect.contains(x, y)

    def move_ball(self, x, y):
        self.ball_pos += QtCore.QPointF(x, y)
        
        self.update_ball_position()
        
    def set_ball_position(self, x, y):
        self.ball_pos = QtCore.QPointF(x, y)
        
        self.update_ball_position()
        
    def update_ball_position(self):
        if self.ball_pos.x() < self.ball_radius:
            self.ball_pos.setX(self.ball_radius)
        elif self.ball_pos.x() > (self.width() - self.ball_radius):
            self.ball_pos.setX(self.width() - self.ball_radius)
            
        if self.ball_pos.y() < self.ball_radius:
            self.ball_pos.setY(self.ball_radius)
        elif self.ball_pos.y() > (self.height() - self.ball_radius):
            self.ball_pos.setY(self.height() - self.ball_radius)
            
        self.update()
        
    def change_ball_color(self):
        self.ball_color_index += 1
        if self.ball_color_index >= len(self.BALL_COLORS):
            self.ball_color_index = 0
            
        self.update()

    def keyPressEvent(self, key_event):
        key = key_event.key()
        
        if key == QtCore.Qt.Key.Key_Right:
            self.move_ball(10, 0)
        elif key == QtCore.Qt.Key.Key_Left:
            self.move_ball(-10, 0)
            
        elif key == QtCore.Qt.Key.Key_Down:
            self.move_ball(0, 10)
        elif key == QtCore.Qt.Key.Key_Up:
            self.move_ball(0, -10)
    
    def mousePressEvent(self, mouse_event):
        # pos = mouse_event.pos()  # Qt5
        pos = mouse_event.position()  # Qt6
            
    def mouseReleaseEvent(self, mouse_event):
        pass
            
    def mouseMoveEvent(self, mouse_event):
        # pos = mouse_event.pos()  # Qt5
        pos = mouse_event.position()  # Qt6
        
    def resizeEvent(self, resize_event):
        self.update_ball_position()
        
    def paintEvent(self, paint_event):
        painter = QtGui.QPainter(self)
        
        painter.fillRect(self.rect(), QtCore.Qt.lightGray)
        
        painter.setPen(QtGui.QPen(self.BALL_COLORS[self.ball_color_index]))
        painter.setBrush(self.BALL_COLORS[self.ball_color_index])
        painter.drawEllipse(self.ball_pos, self.ball_radius, self.ball_radius)


if __name__ == "__main__":

    try:
        example_dialog.close() # pylint: disable=E0601
        example_dialog.deleteLater()
    except:
        pass

    example_dialog = ExampleDialog()
    example_dialog.show()
    
    
    
    
    
    
    
