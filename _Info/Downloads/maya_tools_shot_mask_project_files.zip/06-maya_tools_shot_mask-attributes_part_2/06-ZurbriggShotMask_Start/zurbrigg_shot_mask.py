import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    pass


class ZurbriggShotMaskLocator(omui.MPxLocatorNode):

    NAME = "ZurbriggShotMask"
    TYPE_ID = om.MTypeId(0x0007F7FE)

    DRAW_DB_CLASSIFICATION = "drawdb/geometry/zurbriggshotmask"
    DRAW_REGISTRANT_ID = "ZurbriggShotMaskLocator"

    TEXT_ATTRS = [("topLeftText", "tlt"), ("topCenterText", "tct"), ("topRightText", "trt"),
                  ("bottomLeftText", "blt"), ("bottomCenterText", "bct"), ("bottomRightText", "brt")]


    def __init__(self):
        super(ZurbriggShotMaskLocator, self).__init__()

    def excludeAsLocator(self):
        return False

    @classmethod
    def creator(cls):
        return ZurbriggShotMaskLocator()

    @classmethod
    def initialize(cls):
        typed_attr = om.MFnTypedAttribute()
        string_data_fn = om.MFnStringData()

        obj = string_data_fn.create("")
        camera_name = typed_attr.create("camera", "cam", om.MFnData.kString, obj)
        cls.update_attr_properties(typed_attr)
        cls.addAttribute(camera_name)

        for i in range(0, len(cls.TEXT_ATTRS)):
            obj = string_data_fn.create("Position {0}".format(str(i + 1).zfill(2)))
            position = typed_attr.create(cls.TEXT_ATTRS[i][0], cls.TEXT_ATTRS[i][1], om.MFnData.kString, obj)
            cls.update_attr_properties(typed_attr)
            cls.addAttribute(position)

    @classmethod
    def update_attr_properties(cls, attr):
        attr.writable = True
        attr.storable = True
        if attr.type() == om.MFn.kNumericAttribute:
            attr.keyable = True



class ZurbriggShotMaskData(om.MUserData):

    def __init__(self):
        super(ZurbriggShotMaskData, self).__init__(False)

        self.parsed_fields = []

    def __str__(self):
        output = ""
        output += "Text Fields: {0}\n".format(self.parsed_fields)

        return output



class ZurbriggShotMaskDrawOverride(omr.MPxDrawOverride):

    NAME = "zshotmask_draw_override"


    def __init__(self, obj):
        super(ZurbriggShotMaskDrawOverride, self).__init__(obj, None)

    def supportedDrawAPIs(self):
        return (omr.MRenderer.kAllDevices)

    def hasUIDrawables(self):
        return True

    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):

        data = old_data
        if not isinstance(data, ZurbriggShotMaskData):
            data = ZurbriggShotMaskData()

        dag_fn = om.MFnDagNode(obj_path)

        camera_name = dag_fn.findPlug("camera", False).asString()
        if camera_name and self.camera_exists(camera_name) and not self.is_camera_match(camera_path, camera_name):
            return None

        data.parsed_fields = []
        for i in range(0, len(ZurbriggShotMaskLocator.TEXT_ATTRS)):
            orig_text = dag_fn.findPlug(ZurbriggShotMaskLocator.TEXT_ATTRS[i][0], False).asString()
            parsed_text = self.parse_text(orig_text, camera_path, data)
            data.parsed_fields.append(parsed_text)

        # print(data)

        return data

    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        if not (data and isinstance(data, ZurbriggShotMaskData)):
            return

        draw_manager.beginDrawable()

        draw_manager.setFontSize(20)
        draw_manager.setFontWeight(100)
        draw_manager.text2d(om.MPoint(100, 100), "TODO: Draw Shot Mask")

        draw_manager.endDrawable()

    def camera_exists(self, name):
        dg_iter = om.MItDependencyNodes(om.MFn.kCamera)
        while not dg_iter.isDone():
            camera_path = om.MDagPath.getAPathTo(dg_iter.thisNode())
            if self.is_camera_match(camera_path, name):
                return True

            dg_iter.next()

        return False

    def is_camera_match(self, camera_path, name):
        if self.camera_transform_name(camera_path) == name or self.camera_shape_name(camera_path) == name:
            return True

        return False

    def camera_transform_name(self, camera_path):
        camera_transform = camera_path.transform()
        if camera_transform:
            return om.MFnTransform(camera_transform).name()

        return ""

    def camera_shape_name(self, camera_path):
        camera_shape = camera_path.node()
        if camera_shape:
            return om.MFnCamera(camera_shape).name()

        return ""

    def parse_text(self, orig_text, camera_path, data):

        text = orig_text

        return {"text": text}

    @staticmethod
    def creator(obj):
        """
        """
        return ZurbriggShotMaskDrawOverride(obj)



def initializePlugin(obj):
    """
    """
    plugin_fn = om.MFnPlugin(obj, "Chris Zurbrigg", "1.0.0", "Any")

    try:
        plugin_fn.registerNode(ZurbriggShotMaskLocator.NAME,
                               ZurbriggShotMaskLocator.TYPE_ID,
                               ZurbriggShotMaskLocator.creator,
                               ZurbriggShotMaskLocator.initialize,
                               om.MPxNode.kLocatorNode,
                               ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(ZurbriggShotMaskLocator.NAME))

    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION,
                                                      ZurbriggShotMaskLocator.DRAW_REGISTRANT_ID,
                                                      ZurbriggShotMaskDrawOverride.creator)
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(ZurbriggShotMaskDrawOverride.NAME))


def uninitializePlugin(obj):
    """
    """
    plugin_fn = om.MFnPlugin(obj)

    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION, ZurbriggShotMaskLocator.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(ZurbriggShotMaskDrawOverride.NAME))

    try:
        plugin_fn.deregisterNode(ZurbriggShotMaskLocator.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(ZurbriggShotMaskLocator.NAME))


if __name__ == "__main__":

    cmds.file(f=True, new=True)

    plugin_name = "zurbrigg_shot_mask.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.createNode("ZurbriggShotMask")')
