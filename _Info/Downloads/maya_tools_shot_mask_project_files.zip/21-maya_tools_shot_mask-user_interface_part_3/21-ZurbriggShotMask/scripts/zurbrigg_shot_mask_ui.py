import sys

from functools import partial

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets
from shiboken2 import wrapInstance

import maya.cmds as cmds
import maya.OpenMaya as om
import maya.OpenMayaUI as omui


def maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    if sys.version_info.major >= 3:
        return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)
    else:
        return wrapInstance(long(main_window_ptr), QtWidgets.QWidget)


class ZurbriggHeaderWidget(QtWidgets.QWidget):

    def __init__(self, text, parent=None):
        super(ZurbriggHeaderWidget, self).__init__(parent)

        self.setAutoFillBackground(True)
        self.set_background_color(None)

        self.text_label = QtWidgets.QLabel()
        self.text_label.setTextFormat(QtCore.Qt.RichText)
        self.text_label.setAlignment(QtCore.Qt.AlignLeft)

        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.main_layout.setContentsMargins(4, 4, 4, 4)
        self.main_layout.addWidget(self.text_label)

        self.set_text(text)

    def set_text(self, text):
        self.text_label.setText("<b>{0}</b>".format(text))

    def set_background_color(self, color):
        if not color:
            color = QtWidgets.QPushButton().palette().color(QtGui.QPalette.Button)

        palette = self.palette()
        palette.setColor(QtGui.QPalette.Window, color)
        self.setPalette(palette)


class ZurbriggColorButton(QtWidgets.QWidget):

    color_changed = QtCore.Signal()


    def __init__(self, color=(1.0, 1.0, 1.0), parent=None):
        super(ZurbriggColorButton, self).__init__(parent)

        self.setObjectName("ZurbriggColorButton")

        self.create_control()

        self.set_size(50, 16)
        self.set_color(color)

    def create_control(self):
        window = cmds.window()
        color_slider_name = cmds.colorSliderGrp()

        self._color_slider_obj = omui.MQtUtil.findControl(color_slider_name)
        if self._color_slider_obj:
            if sys.version_info.major >= 3:
                self._color_slider_widget = wrapInstance(int(self._color_slider_obj), QtWidgets.QWidget)
            else:
                self._color_slider_widget = wrapInstance(long(self._color_slider_obj), QtWidgets.QWidget)

            main_layout = QtWidgets.QVBoxLayout(self)
            main_layout.setObjectName("main_layout")
            main_layout.setContentsMargins(0, 0, 0, 0)
            main_layout.addWidget(self._color_slider_widget)

            self._slider_widget = self._color_slider_widget.findChild(QtWidgets.QWidget, "slider")
            if self._slider_widget:
                self._slider_widget.hide()

            self._color_widget = self._color_slider_widget.findChild(QtWidgets.QWidget, "port")

            cmds.colorSliderGrp(self.get_full_name(), e=True, changeCommand=partial(self.on_color_changed))


        cmds.deleteUI(window, window=True)

    def get_full_name(self):
        if sys.version_info.major >= 3:
            return omui.MQtUtil.fullName(int(self._color_slider_obj))
        else:
            return omui.MQtUtil.fullName(long(self._color_slider_obj))

    def set_size(self, width, height):
        self._color_slider_widget.setFixedWidth(width)
        self._color_widget.setFixedHeight(height)

    def set_color(self, color):
        cmds.colorSliderGrp(self.get_full_name(), e=True, rgbValue=(color[0], color[1], color[2]))
        self.on_color_changed()

    def get_color(self):
        return cmds.colorSliderGrp(self.get_full_name(), q=True, rgbValue=True)

    def on_color_changed(self, *args):
        self.color_changed.emit()  # pylint: disable=E1101


class ZurbriggCameraSelectDialog(QtWidgets.QDialog):

    def __init__(self, parent):
        super(ZurbriggCameraSelectDialog, self).__init__(parent)

        self.setWindowTitle("Camera Select")
        self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
        self.setModal(True)

        self.camera_list_label = QtWidgets.QLabel()
        self.camera_list_label.setVisible(False)

        self.camera_list_wdg = QtWidgets.QListWidget()
        self.camera_list_wdg.doubleClicked.connect(self.accept)

        self.select_btn = QtWidgets.QPushButton("Select")
        self.select_btn.clicked.connect(self.accept)

        self.cancel_btn = QtWidgets.QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.close)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.select_btn)
        button_layout.addWidget(self.cancel_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(2, 4, 2, 2)
        main_layout.setSpacing(4)
        main_layout.addWidget(self.camera_list_label)
        main_layout.addWidget(self.camera_list_wdg)
        main_layout.addLayout(button_layout)

    def set_camera_list_text(self, text):
        self.camera_list_label.setText(text)
        self.camera_list_label.setVisible(True)

    def refresh_list(self, selected):
        self.camera_list_wdg.clear()

        cameras = cmds.listCameras()
        cameras.insert(0, "<All Cameras>")

        self.camera_list_wdg.addItems(cameras)

        if selected:
            for text in selected:
                items = self.camera_list_wdg.findItems(text, QtCore.Qt.MatchCaseSensitive)
                if len(items) > 0:
                    self.camera_list_wdg.setCurrentItem(items[0], QtCore.QItemSelectionModel.Select)

    def get_selected(self):
        selected = []

        items = self.camera_list_wdg.selectedItems()
        for item in items:
            selected.append(item.text())

        return selected


class ZurbriggShotMaskUi(QtWidgets.QDialog):

    WINDOW_TITLE = "Zurbrigg Shot Mask"

    PLUG_IN_NAME = "zurbrigg_shot_mask"
    NODE_TYPE = "ZurbriggShotMask"

    TRANSFORM_NAME = "zurbriggShotMask"
    SHAPE_NAME = "zurbriggShotMaskShape"

    TEXT_LABELS = ["Top-Left", "Top-Center", "Top-Right", "Bottom-Left", "Bottom-Center", "Bottom-Right"]
    TEXT_ATTRIBUTES = ["topLeftText", "topCenterText", "topRightText", "bottomLeftText", "bottomCenterText", "bottomRightText"]

    OPT_VAR_CAMERA = "ZSM_Camera"
    OPT_VAR_TEXT = "ZSM_Text"
    OPT_VAR_FONT = "ZSM_Font"
    OPT_VAR_FONT_COLOR = "ZSM_FontColor"
    OPT_VAR_FONT_SCALE = "ZSM_FontScale"
    OPT_VAR_BORDER_VISIBLE = "ZSM_BorderVisible"
    OPT_VAR_BORDER_COLOR = "ZSM_BorderColor"
    OPT_VAR_BORDER_SCALE = "ZSM_BorderScale"
    OPT_VAR_COUNTER_PADDING = "ZSM_CounterPadding"


    def __init__(self, parent=maya_main_window()):
        super(ZurbriggShotMaskUi, self).__init__(parent)

        self.setWindowTitle(self.WINDOW_TITLE)
        if cmds.about(ntOS=True):
            self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
        elif cmds.about(macOS=True):
            self.setWindowFlags(QtCore.Qt.Tool)

        self.setMinimumWidth(320)

        self._camera_select_dialog = None

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        button_width = 60
        button_height = 18
        spin_box_width = 50

        self.camera_le = QtWidgets.QLineEdit()
        self.camera_select_btn = QtWidgets.QPushButton("Select...")
        self.camera_select_btn.setFixedSize(button_width, button_height)

        self.text_line_edits = []
        for i in range(len(ZurbriggShotMaskUi.TEXT_LABELS)):  # pylint: disable=W0612
            self.text_line_edits.append(QtWidgets.QLineEdit())

        self.font_le = QtWidgets.QLineEdit()
        self.font_le.setEnabled(False)

        self.font_select_btn = QtWidgets.QPushButton("Select...")
        self.font_select_btn.setFixedSize(button_width, button_height)

        self.font_color_btn = ZurbriggColorButton()

        self.font_alpha_dsb = QtWidgets.QDoubleSpinBox()
        self.font_alpha_dsb.setMinimumWidth(spin_box_width)
        self.font_alpha_dsb.setSingleStep(0.05)
        self.font_alpha_dsb.setMinimum(0.0)
        self.font_alpha_dsb.setMaximum(1.0)
        self.font_alpha_dsb.setValue(1.0)
        self.font_alpha_dsb.setDecimals(3)
        self.font_alpha_dsb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)

        self.font_scale_dsb = QtWidgets.QDoubleSpinBox()
        self.font_scale_dsb.setMinimumWidth(spin_box_width)
        self.font_scale_dsb.setSingleStep(0.05)
        self.font_scale_dsb.setMinimum(0.1)
        self.font_scale_dsb.setMaximum(2.0)
        self.font_scale_dsb.setValue(1.0)
        self.font_scale_dsb.setDecimals(3)
        self.font_scale_dsb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)

        self.top_border_cb = QtWidgets.QCheckBox("Top")
        self.top_border_cb.setChecked(True)
        self.bottom_border_cb = QtWidgets.QCheckBox("Bottom")
        self.bottom_border_cb.setChecked(True)

        self.border_color_btn = ZurbriggColorButton()

        self.border_transparency_dsb = QtWidgets.QDoubleSpinBox()
        self.border_transparency_dsb.setMinimumWidth(spin_box_width)
        self.border_transparency_dsb.setSingleStep(0.05)
        self.border_transparency_dsb.setMinimum(0.0)
        self.border_transparency_dsb.setMaximum(1.0)
        self.border_transparency_dsb.setValue(1.0)
        self.border_transparency_dsb.setDecimals(3)
        self.border_transparency_dsb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)

        self.border_scale_dsb = QtWidgets.QDoubleSpinBox()
        self.border_scale_dsb.setMinimumWidth(spin_box_width)
        self.border_scale_dsb.setSingleStep(0.05)
        self.border_scale_dsb.setMinimum(0.5)
        self.border_scale_dsb.setMaximum(2.0)
        self.border_scale_dsb.setValue(1.0)
        self.border_scale_dsb.setDecimals(3)
        self.border_scale_dsb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)

        self.counter_padding_sb = QtWidgets.QSpinBox()
        self.counter_padding_sb.setMinimumWidth(spin_box_width)
        self.counter_padding_sb.setSingleStep(1)
        self.counter_padding_sb.setMinimum(1)
        self.counter_padding_sb.setMaximum(6)
        self.counter_padding_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)

        self.create_btn = QtWidgets.QPushButton("Create")
        self.delete_btn = QtWidgets.QPushButton("Delete")

        self.refresh_ui()

    def create_layout(self):
        camera_layout = QtWidgets.QHBoxLayout()
        camera_layout.setSpacing(4)
        camera_layout.addWidget(self.camera_le)
        camera_layout.addWidget(self.camera_select_btn)

        camera_form_layout = QtWidgets.QFormLayout()
        camera_form_layout.setSpacing(2)
        camera_form_layout.addRow("Camera ", camera_layout)
        camera_form_layout.addRow(self.spacing_widget(), None)

        text_form_layout = QtWidgets.QFormLayout()
        text_form_layout.setSpacing(2)
        for i in range(len(self.text_line_edits)):
            text_form_layout.addRow(ZurbriggShotMaskUi.TEXT_LABELS[i], self.text_line_edits[i])
        text_form_layout.addRow(self.spacing_widget(), None)

        font_layout = QtWidgets.QHBoxLayout()
        font_layout.setSpacing(2)
        font_layout.addWidget(self.font_le)
        font_layout.addWidget(self.font_select_btn)

        text_color_layout = QtWidgets.QHBoxLayout()
        text_color_layout.addWidget(self.font_color_btn)
        text_color_layout.addSpacing(4)
        text_color_layout.addWidget(QtWidgets.QLabel("Alpha"))
        text_color_layout.addWidget(self.font_alpha_dsb)
        text_color_layout.addSpacing(4)
        text_color_layout.addWidget(QtWidgets.QLabel("Scale"))
        text_color_layout.addWidget(self.font_scale_dsb)
        text_color_layout.addStretch()

        font_form_layout = QtWidgets.QFormLayout()
        font_form_layout.setSpacing(4)
        font_form_layout.addRow("Font", font_layout)
        font_form_layout.addRow("Color", text_color_layout)
        font_form_layout.addRow(self.spacing_widget(), None)

        border_visibility_layout = QtWidgets.QHBoxLayout()
        border_visibility_layout.addWidget(self.top_border_cb)
        border_visibility_layout.addWidget(self.bottom_border_cb)
        border_visibility_layout.addStretch()

        border_color_layout = QtWidgets.QHBoxLayout()
        border_color_layout.addWidget(self.border_color_btn)
        border_color_layout.addSpacing(4)
        border_color_layout.addWidget(QtWidgets.QLabel("Alpha"))
        border_color_layout.addWidget(self.border_transparency_dsb)
        border_color_layout.addSpacing(4)
        border_color_layout.addWidget(QtWidgets.QLabel("Scale"))
        border_color_layout.addWidget(self.border_scale_dsb)
        border_color_layout.addStretch()

        borders_form_layout = QtWidgets.QFormLayout()
        borders_form_layout.setSpacing(2)
        borders_form_layout.addRow("", border_visibility_layout)
        borders_form_layout.addRow("Color", border_color_layout)
        borders_form_layout.addRow(self.spacing_widget(), None)

        counter_padding_layout = QtWidgets.QHBoxLayout()
        counter_padding_layout.addWidget(self.counter_padding_sb)
        counter_padding_layout.addStretch()

        counter_form_layout = QtWidgets.QFormLayout()
        counter_form_layout.setSpacing(4)
        counter_form_layout.addRow("Padding", counter_padding_layout)
        counter_form_layout.addRow(self.spacing_widget(), None)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(4)
        button_layout.addStretch()
        button_layout.addWidget(self.create_btn)
        button_layout.addWidget(self.delete_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addSpacing(6)
        main_layout.addLayout(camera_form_layout)
        main_layout.addWidget(ZurbriggHeaderWidget("Text"))
        main_layout.addLayout(text_form_layout)
        main_layout.addWidget(ZurbriggHeaderWidget("Font"))
        main_layout.addLayout(font_form_layout)
        main_layout.addWidget(ZurbriggHeaderWidget("Border"))
        main_layout.addLayout(borders_form_layout)
        main_layout.addWidget(ZurbriggHeaderWidget("Counter"))
        main_layout.addLayout(counter_form_layout)
        main_layout.addLayout(button_layout)

    def spacing_widget(self):
        widget = QtWidgets.QWidget()
        widget.setFixedWidth(86)
        widget.setFixedHeight(0)
        return widget

    def create_connections(self):
        self.camera_le.editingFinished.connect(self.update_mask)
        self.camera_select_btn.clicked.connect(self.show_camera_select_dialog)

        for text_le in self.text_line_edits:
            text_le.editingFinished.connect(self.update_mask)

        self.font_select_btn.clicked.connect(self.show_font_select_dialog)
        self.font_color_btn.color_changed.connect(self.update_mask)  # pylint: disable=E1101
        self.font_alpha_dsb.valueChanged.connect(self.update_mask)
        self.font_scale_dsb.valueChanged.connect(self.update_mask)

        self.top_border_cb.toggled.connect(self.update_mask)
        self.bottom_border_cb.toggled.connect(self.update_mask)
        self.border_color_btn.color_changed.connect(self.update_mask)  # pylint: disable=E1101
        self.border_transparency_dsb.valueChanged.connect(self.update_mask)
        self.border_scale_dsb.valueChanged.connect(self.update_mask)

        self.counter_padding_sb.valueChanged.connect(self.update_mask)

        self.create_btn.clicked.connect(self.create_mask)
        self.delete_btn.clicked.connect(self.delete_mask)

    def load_plugin(self):
        if not self.is_plugin_loaded():
            try:
                cmds.loadPlugin(ZurbriggShotMaskUi.PLUG_IN_NAME)
            except:
                om.MGlobal.displayError("Failed to load Zurbrigg Shot Mask plug-in: {0}".format(ZurbriggShotMaskUi.PLUG_IN_NAME))
                return False

        return True

    def is_plugin_loaded(self):
        return cmds.pluginInfo(ZurbriggShotMaskUi.PLUG_IN_NAME, q=True, loaded=True)

    def get_mask(self):
        if self.is_plugin_loaded():
            nodes = cmds.ls(type=ZurbriggShotMaskUi.NODE_TYPE)
            if len(nodes) > 0:
                return nodes[0]

        return None

    def create_mask(self):
        if not self.load_plugin():
            return

        if not self.get_mask():
            selection = cmds.ls(sl=True)

            transform_node = cmds.createNode("transform", name=ZurbriggShotMaskUi.TRANSFORM_NAME)
            cmds.createNode(ZurbriggShotMaskUi.NODE_TYPE, name=ZurbriggShotMaskUi.SHAPE_NAME, parent=transform_node)

            cmds.select(selection, r=True)

        self.update_mask()

    def delete_mask(self):
        mask = self.get_mask()
        if mask:
            transform = cmds.listRelatives(mask, fullPath=True, parent=True)
            if transform:
                cmds.delete(transform)
            else:
                cmds.delete(mask)

    def update_mask(self):
        cmds.optionVar(sv=[ZurbriggShotMaskUi.OPT_VAR_CAMERA, self.camera_le.text()])

        cmds.optionVar(sv=[ZurbriggShotMaskUi.OPT_VAR_TEXT, self.text_line_edits[0].text()])
        for i in range(1, len(self.text_line_edits)):
            cmds.optionVar(sva=[ZurbriggShotMaskUi.OPT_VAR_TEXT, self.text_line_edits[i].text()])

        cmds.optionVar(sv=[ZurbriggShotMaskUi.OPT_VAR_FONT, self.font_le.text()])

        font_color = self.font_color_btn.get_color()
        font_alpha = self.font_alpha_dsb.value()
        cmds.optionVar(fv=[ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR, font_color[0]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR, font_color[1]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR, font_color[2]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR, font_alpha])

        cmds.optionVar(fv=[ZurbriggShotMaskUi.OPT_VAR_FONT_SCALE, self.font_scale_dsb.value()])

        cmds.optionVar(iv=[ZurbriggShotMaskUi.OPT_VAR_BORDER_VISIBLE, self.top_border_cb.isChecked()])
        cmds.optionVar(iva=[ZurbriggShotMaskUi.OPT_VAR_BORDER_VISIBLE, self.bottom_border_cb.isChecked()])

        border_color = self.border_color_btn.get_color()
        border_alpha = self.border_transparency_dsb.value()
        cmds.optionVar(fv=[ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR, border_color[0]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR, border_color[1]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR, border_color[2]])
        cmds.optionVar(fva=[ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR, border_alpha])

        cmds.optionVar(fv=[ZurbriggShotMaskUi.OPT_VAR_BORDER_SCALE, self.border_scale_dsb.value()])

        cmds.optionVar(iv=[ZurbriggShotMaskUi.OPT_VAR_COUNTER_PADDING, self.counter_padding_sb.value()])

        self.refresh_mask()

    def refresh_mask(self):
        mask = self.get_mask()
        if not mask:
            return

        cmds.setAttr("{0}.camera".format(mask), self.get_camera_name(), type="string")

        text_list = self.get_text_list()
        for i in range(len(ZurbriggShotMaskUi.TEXT_ATTRIBUTES)):
            cmds.setAttr("{0}.{1}".format(mask, ZurbriggShotMaskUi.TEXT_ATTRIBUTES[i]), text_list[i], type="string")

        cmds.setAttr("{0}.fontName".format(mask), self.get_font(), type="string")

        font_color = self.get_font_color()
        cmds.setAttr("{0}.fontColor".format(mask), font_color[0], font_color[1], font_color[2], type="double3")
        cmds.setAttr("{0}.fontAlpha".format(mask), font_color[3])
        cmds.setAttr("{0}.fontScale".format(mask), self.get_font_scale())

        border_vis = self.get_border_visibility()
        cmds.setAttr("{0}.topBorder".format(mask), border_vis[0])
        cmds.setAttr("{0}.bottomBorder".format(mask), border_vis[1])

        border_color = self.get_border_color()
        cmds.setAttr("{0}.borderColor".format(mask), border_color[0], border_color[1], border_color[2], type="double3")
        cmds.setAttr("{0}.borderAlpha".format(mask), border_color[3])
        cmds.setAttr("{0}.borderScale".format(mask), self.get_border_scale())

        cmds.setAttr("{0}.counterPadding".format(mask), self.get_counter_padding())

    def refresh_ui(self):
        self.camera_le.setText(self.get_camera_name())

        text_list = self.get_text_list()
        for i in range(len(self.text_line_edits)):
            self.text_line_edits[i].setText(text_list[i])

        self.font_le.setText(self.get_font())

        font_color = self.get_font_color()
        self.font_color_btn.set_color(font_color)
        self.font_alpha_dsb.setValue(font_color[3])
        self.font_scale_dsb.setValue(self.get_font_scale())

        border_visibility = self.get_border_visibility()
        self.top_border_cb.setChecked(border_visibility[0])
        self.bottom_border_cb.setChecked(border_visibility[1])

        border_color = self.get_border_color()
        self.border_color_btn.set_color(border_color)
        self.border_transparency_dsb.setValue(border_color[3])
        self.border_scale_dsb.setValue(self.get_border_scale())

        self.counter_padding_sb.setValue(self.get_counter_padding())

    def get_camera_name(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_CAMERA):
            return cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_CAMERA)

        return "<All Cameras>"

    def get_text_list(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_TEXT):
            return cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_TEXT)

        return ["", "{scene}", "", "{camera}", "", "{counter}"]

    def get_font(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_FONT):
            font = cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_FONT)
            if font:
                return font

        return "Times New Roman"

    def get_font_color(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR):
            return cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_FONT_COLOR)

        return [1.0, 1.0, 1.0, 1.0]

    def get_font_scale(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_FONT_SCALE):
            font_scale = cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_FONT_SCALE)
            if font_scale:
                return font_scale

        return 1.0

    def get_border_visibility(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_BORDER_VISIBLE):
            border_visibility = cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_BORDER_VISIBLE)
            try:
                if len(border_visibility) == 2:
                    return border_visibility
            except:
                pass

        return [1, 1]

    def get_border_color(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR):
            return cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_BORDER_COLOR)

        return [0.0, 0.0, 0.0, 1.0]

    def get_border_scale(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_BORDER_SCALE):
            border_scale = cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_BORDER_SCALE)
            if border_scale:
                return border_scale

        return 1.0

    def get_counter_padding(self):
        if cmds.optionVar(exists=ZurbriggShotMaskUi.OPT_VAR_COUNTER_PADDING):
            counter_padding = cmds.optionVar(q=ZurbriggShotMaskUi.OPT_VAR_COUNTER_PADDING)
            if counter_padding >= 1 and counter_padding <= 6:
                return counter_padding

        return 4


    def show_camera_select_dialog(self):
        if not self._camera_select_dialog:
            self._camera_select_dialog = ZurbriggCameraSelectDialog(self)
            self._camera_select_dialog.setWindowTitle("Shot Mask Camera")
            self._camera_select_dialog.set_camera_list_text("Select shot mask camera:")
            self._camera_select_dialog.accepted.connect(self.on_camera_select_accepted)

        self._camera_select_dialog.refresh_list(self.camera_le.text())

        self._camera_select_dialog.show()

    def on_camera_select_accepted(self):
        selected = self._camera_select_dialog.get_selected()
        if selected:
            self.camera_le.setText(selected[0])

            self.update_mask()

    def show_font_select_dialog(self):
        current_font = QtGui.QFont(self.font_le.text())

        font = QtWidgets.QFontDialog.getFont(current_font, self)

        # Order of the tuple returned by getFont changed in newer versions of Qt
        if type(font[0]) == bool:
            ok = font[0]
            family = font[1].family()
        else:
            family = font[0].family()
            ok = font[1]

        if ok:
            self.font_le.setText(family)

            self.update_mask()


if __name__ == "__main__":

    try:
        shot_mask_ui.close() # pylint: disable=E0601
        shot_mask_ui.deleteLater()
    except:
        pass

    shot_mask_ui = ZurbriggShotMaskUi()
    shot_mask_ui.show()
