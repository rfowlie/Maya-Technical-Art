import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr
import maya.api.OpenMayaUI as omui

import maya.cmds as cmds


def maya_useNewAPI():
    pass


class ZurbriggShotMaskLocator(omui.MPxLocatorNode):

    NAME = "ZurbriggShotMask"
    TYPE_ID = om.MTypeId(0x0007F7FE)

    DRAW_DB_CLASSIFICATION = "drawdb/geometry/zurbriggshotmask"
    DRAW_REGISTRANT_ID = "ZurbriggShotMaskLocator"


    def __init__(self):
        super(ZurbriggShotMaskLocator, self).__init__()

    def excludeAsLocator(self):
        return False

    @classmethod
    def creator(cls):
        return ZurbriggShotMaskLocator()

    @classmethod
    def initialize(cls):
        pass



class ZurbriggShotMaskData(om.MUserData):

    def __init__(self):
        super(ZurbriggShotMaskData, self).__init__(False)



class ZurbriggShotMaskDrawOverride(omr.MPxDrawOverride):

    NAME = "zshotmask_draw_override"


    def __init__(self, obj):
        super(ZurbriggShotMaskDrawOverride, self).__init__(obj, None)

    def supportedDrawAPIs(self):
        return (omr.MRenderer.kAllDevices)

    def hasUIDrawables(self):
        return True

    def prepareForDraw(self, obj_path, camera_path, frame_context, old_data):

        data = old_data
        if not isinstance(data, ZurbriggShotMaskData):
            data = ZurbriggShotMaskData()

        return data

    def addUIDrawables(self, obj_path, draw_manager, frame_context, data):
        if not (data and isinstance(data, ZurbriggShotMaskData)):
            return

        draw_manager.beginDrawable()

        draw_manager.setFontSize(20)
        draw_manager.setFontWeight(100)
        draw_manager.text2d(om.MPoint(100, 100), "TODO: Draw Shot Mask")

        draw_manager.endDrawable()

    @staticmethod
    def creator(obj):
        """
        """
        return ZurbriggShotMaskDrawOverride(obj)



def initializePlugin(obj):
    """
    """
    plugin_fn = om.MFnPlugin(obj, "Chris Zurbrigg", "1.0.0", "Any")

    try:
        plugin_fn.registerNode(ZurbriggShotMaskLocator.NAME,
                               ZurbriggShotMaskLocator.TYPE_ID,
                               ZurbriggShotMaskLocator.creator,
                               ZurbriggShotMaskLocator.initialize,
                               om.MPxNode.kLocatorNode,
                               ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION)
    except:
        om.MGlobal.displayError("Failed to register node: {0}".format(ZurbriggShotMaskLocator.NAME))

    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION,
                                                      ZurbriggShotMaskLocator.DRAW_REGISTRANT_ID,
                                                      ZurbriggShotMaskDrawOverride.creator)
    except:
        om.MGlobal.displayError("Failed to register draw override: {0}".format(ZurbriggShotMaskDrawOverride.NAME))


def uninitializePlugin(obj):
    """
    """
    plugin_fn = om.MFnPlugin(obj)

    try:
        omr.MDrawRegistry.deregisterDrawOverrideCreator(ZurbriggShotMaskLocator.DRAW_DB_CLASSIFICATION, ZurbriggShotMaskLocator.DRAW_REGISTRANT_ID)
    except:
        om.MGlobal.displayError("Failed to deregister draw override: {0}".format(ZurbriggShotMaskDrawOverride.NAME))

    try:
        plugin_fn.deregisterNode(ZurbriggShotMaskLocator.TYPE_ID)
    except:
        om.MGlobal.displayError("Failed to unregister node: {0}".format(ZurbriggShotMaskLocator.NAME))


if __name__ == "__main__":

    cmds.file(f=True, new=True)

    plugin_name = "zurbrigg_shot_mask.py"
    cmds.evalDeferred('if cmds.pluginInfo("{0}", q=True, loaded=True): cmds.unloadPlugin("{0}")'.format(plugin_name))
    cmds.evalDeferred('if not cmds.pluginInfo("{0}", q=True, loaded=True): cmds.loadPlugin("{0}")'.format(plugin_name))

    cmds.evalDeferred('cmds.createNode("ZurbriggShotMask")')
