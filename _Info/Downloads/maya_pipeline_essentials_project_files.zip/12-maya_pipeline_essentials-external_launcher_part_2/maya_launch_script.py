import os
import subprocess

MAYA_PATH = "C:/Program Files/Autodesk/Maya2023/bin/maya.exe"

env = os.environ.copy()
env["MAYA_APP_DIR"] = "C:/Users/czurbrigg/Documents/maya_dev"
env["PYTHONPATH"] = "D:/PythonDev"

maya_args = [MAYA_PATH]
subprocess.Popen(maya_args, env=env)
