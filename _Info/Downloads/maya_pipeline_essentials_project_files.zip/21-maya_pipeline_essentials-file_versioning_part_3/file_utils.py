import os

import maya.cmds as cmds
import maya.api.OpenMaya as om


def versioned_saved(file_type="mayaAscii"):
    scene_path = cmds.file(q=True, sceneName=True)
    if not scene_path:
        om.MGlobal.displayError("Unsaved file")
        return

    if file_type == "mayaAscii":
        extension = "ma"
    elif file_type == "mayaBinary":
        extension = "mb"
    else:
        om.MGlobal.displayError("Unsupport file type")
        return

    versioned_path = next_version_path(scene_path, extension)

    cmds.file(rename=versioned_path)
    saved_file_path = cmds.file(save=True, type=file_type)

    om.MGlobal.displayInfo("Versioned save: {0}".format(saved_file_path))

def next_version_path(scene_path, extension):
    dir_path = os.path.dirname(scene_path)
    file_name = os.path.basename(scene_path)
    base_file_name = file_name.split(".")[0]

    current_versions = get_current_versions(dir_path, base_file_name)
    if current_versions:
        next_version = current_versions[-1] + 1
    else:
        next_version = 1

    next_version_str = "{0}".format(next_version).zfill(4)

    return "{0}/{1}.{2}.{3}".format(dir_path, base_file_name, next_version_str, extension)

def get_current_versions(dir_path, base_file_name):
    current_versions = []

    file_names = os.listdir(dir_path)
    for file_name in file_names:
        if file_name.startswith("{0}.".format(base_file_name)):
            split_file_name = file_name.split(".")
            if len(split_file_name) == 3:
                version_number_str = split_file_name[1]
                try:
                    version_number_int = int(version_number_str)
                except:
                    continue

                current_versions.append(version_number_int)

    current_versions.sort()

    return current_versions


if __name__ == "__main__":
    versioned_saved(file_type="mayaBinary")


