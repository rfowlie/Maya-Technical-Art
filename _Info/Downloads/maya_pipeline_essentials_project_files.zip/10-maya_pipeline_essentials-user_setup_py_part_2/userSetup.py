import inspect
import os
import sys

import maya.cmds as cmds

user_setup_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
print("Reading userSetup.py from {0}".format(user_setup_path))

os.environ["MAYA_PLUG_IN_PATH"] = "D:/TestPlugins" + os.pathsep + os.environ["MAYA_PLUG_IN_PATH"]
os.environ["MAYA_SCRIPT_PATH"] = "D:/TestScripts" + os.pathsep + os.environ["MAYA_SCRIPT_PATH"]

sys.path.insert(0, "D:/TestScripts")

cmds.commandPort(name=":20230", sourceType="mel")
cmds.commandPort(name=":20231", sourceType="python")
