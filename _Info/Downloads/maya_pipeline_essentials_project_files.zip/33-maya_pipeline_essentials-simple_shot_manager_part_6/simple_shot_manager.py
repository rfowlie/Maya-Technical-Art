import sys

from PySide2 import QtCore
from PySide2 import QtWidgets
from shiboken2 import wrapInstance

import maya.cmds as cmds
import maya.OpenMayaUI as omui

import shot_utils


class ShotManagerUi(QtWidgets.QDialog):

    WINDOW_TITLE = "Shot Manager"

    @classmethod
    def maya_main_window(cls):
        main_window_ptr = omui.MQtUtil.mainWindow()
        if sys.version_info.major >= 3:
            return wrapInstance(int(main_window_ptr), QtWidgets.QWidget) # pylint: disable=E0602
        else:
            return wrapInstance(long(main_window_ptr), QtWidgets.QWidget) # pylint: disable=E0602

    def __init__(self):
        super(ShotManagerUi, self).__init__(self.maya_main_window())

        self.setWindowTitle(self.WINDOW_TITLE)
        self.setMinimumSize(400, 200)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.check_out_wdg = CheckOutWidget()
        self.check_in_wdg = CheckInWidget()

        self.tab_wdg = QtWidgets.QTabWidget()
        self.tab_wdg.addTab(self.check_out_wdg, "Check Out")
        self.tab_wdg.addTab(self.check_in_wdg, "Check In")

        self.repo_root_label = QtWidgets.QLabel("Repo Path: {0}".format(shot_utils.REPO_PATH))
        self.repo_root_label.setDisabled(True)

    def create_layout(self):
        repo_layout = QtWidgets.QHBoxLayout()
        repo_layout.setContentsMargins(0, 0, 6, 6)
        repo_layout.addStretch()
        repo_layout.addWidget(self.repo_root_label)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self.tab_wdg)
        main_layout.addLayout(repo_layout)

    def create_connections(self):
        self.tab_wdg.currentChanged.connect(self.on_tab_changed)

    def on_tab_changed(self, index):
        if index == 0:
            self.check_out_wdg.refresh_shot_list()



class CheckInWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(CheckInWidget, self).__init__(parent)

        self.shot_name_le = QtWidgets.QLineEdit()
        self.resolved_path_label = QtWidgets.QLabel()
        self.resolved_path_label.setDisabled(True)
        shot_path_layout = QtWidgets.QVBoxLayout()
        shot_path_layout.setSpacing(0)
        shot_path_layout.addWidget(self.shot_name_le)
        shot_path_layout.addWidget(self.resolved_path_label)

        self.maya_ascii_rb = QtWidgets.QRadioButton("mayaAscii")
        self.maya_ascii_rb.setChecked(True)
        self.maya_binary_rb = QtWidgets.QRadioButton("mayaBinary")
        file_type_layout = QtWidgets.QHBoxLayout()
        file_type_layout.addWidget(self.maya_ascii_rb)
        file_type_layout.addWidget(self.maya_binary_rb)
        file_type_layout.addStretch()

        options_layout = QtWidgets.QFormLayout()
        options_layout.addRow("Shot Name: ", shot_path_layout)
        options_layout.addRow("", file_type_layout)

        self.check_in_btn = QtWidgets.QPushButton("Check In")
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.check_in_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addLayout(options_layout)
        main_layout.addStretch()
        main_layout.addLayout(btn_layout)

        self.shot_name_le.textChanged.connect(self.update_resolved_path)
        self.maya_ascii_rb.clicked.connect(self.update_resolved_path)
        self.maya_binary_rb.clicked.connect(self.update_resolved_path)

        self.check_in_btn.clicked.connect(self.save_shot)

        self.update_resolved_path()

    def update_resolved_path(self):
        resolved_path = shot_utils.get_resolved_file_path(self.shot_name_le.text(), shot_utils.get_extension_from_type(self.get_file_type()))
        if not resolved_path:
            resolved_path = "<shot name not set>"

        self.resolved_path_label.setText(resolved_path)

    def save_shot(self):
        shot_name = self.shot_name_le.text()
        if not shot_name:
            return

        shot_utils.save_shot(shot_name, self.get_file_type())

    def get_file_type(self):
        if self.maya_ascii_rb.isChecked():
            file_type = "mayaAscii"
        else:
            file_type = "mayaBinary"

        return file_type

class CheckOutWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(CheckOutWidget, self).__init__(parent)

        self.shot_select_cmb = QtWidgets.QComboBox()
        shot_select_layout = QtWidgets.QHBoxLayout()
        shot_select_layout.addStretch()
        shot_select_layout.addWidget(QtWidgets.QLabel("Shot: "))
        shot_select_layout.addWidget(self.shot_select_cmb)

        self.force_overwrite_cb = QtWidgets.QCheckBox("Force Overwrite")
        overwrite_layout = QtWidgets.QHBoxLayout()
        overwrite_layout.addStretch()
        overwrite_layout.addWidget(self.force_overwrite_cb)

        self.ref_wdgs = []
        self.ref_layout = QtWidgets.QVBoxLayout()
        ref_grp_box = QtWidgets.QGroupBox("References")
        ref_grp_box.setLayout(self.ref_layout)

        self.check_out_btn = QtWidgets.QPushButton("Check Out")
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.check_out_btn)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setSpacing(2)
        main_layout.addLayout(shot_select_layout)
        main_layout.addWidget(ref_grp_box)
        main_layout.addLayout(overwrite_layout)
        main_layout.addStretch()
        main_layout.addLayout(btn_layout)

        self.shot_select_cmb.currentTextChanged.connect(self.update_selected_shot_meta)
        self.check_out_btn.clicked.connect(self.load_shot)

        self.refresh_shot_list()

    def refresh_shot_list(self):
        current_text = self.shot_select_cmb.currentText()

        self.shot_select_cmb.blockSignals(True)
        self.shot_select_cmb.clear()

        shot_list = shot_utils.get_shot_list()
        for shot in shot_list:
            self.shot_select_cmb.addItem(shot[0], shot[1])

        self.shot_select_cmb.setCurrentText(current_text)
        self.shot_select_cmb.blockSignals(False)

        self.update_selected_shot_meta()

    def update_selected_shot_meta(self):
        file_path = self.shot_select_cmb.currentData()
        if not file_path:
            return

        shot_meta = shot_utils.read_json(file_path)

        ref_data = shot_meta["references"]
        ref_count = len(ref_data)
        ref_wdg_count = len(self.ref_wdgs)

        extra_ref_wdgs_required = ref_count - ref_wdg_count
        if extra_ref_wdgs_required > 0:
            for i in range(extra_ref_wdgs_required):
                self.ref_wdgs.append(ReferenceWidget())
                self.ref_layout.addWidget(self.ref_wdgs[-1])

        for i in range(ref_count):
            self.ref_wdgs[i].set_ref_data(ref_data[i]["ref_node"], ref_data[i]["loaded"])
            self.ref_wdgs[i].setVisible(True)
        for i in range(ref_count, ref_wdg_count):
            self.ref_wdgs[i].setVisible(False)

    def load_shot(self):
        file_path = self.shot_select_cmb.currentData()
        force_overwrite = self.force_overwrite_cb.isChecked()

        loaded_ref_nodes = []
        for ref_wdg in self.ref_wdgs:
            if ref_wdg.is_loaded():
                loaded_ref_nodes.append(ref_wdg.ref_node_name())

        shot_utils.load_shot(file_path, loaded_ref_nodes, force_overwrite)


class ReferenceWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super(ReferenceWidget, self).__init__(parent)

        self.loaded_cb = QtWidgets.QCheckBox()
        self.ref_node_label = QtWidgets.QLabel()

        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self.loaded_cb)
        main_layout.addWidget(self.ref_node_label)
        main_layout.addStretch()

    def set_ref_data(self, ref_node_name, loaded):
        self.ref_node_label.setText(ref_node_name)
        self.loaded_cb.setChecked(loaded)

    def ref_node_name(self):
        return self.ref_node_label.text()

    def is_loaded(self):
        return self.isVisible() and self.loaded_cb.isChecked()


if __name__ == "__main__":

    try:
        shot_manager_ui.close() # pylint: disable=E0601
        shot_manager_ui.deleteLater()
    except:
        pass

    shot_manager_ui = ShotManagerUi()
    shot_manager_ui.show()


