import maya.cmds as cmds

file_path = "D:/MayaScenes/test_scene.ma"

# Query the scene name
cmds.file(q=True, sceneName=True)

# Rename the scene
cmds.file(rename=file_path)

# Save the scene
cmds.file(save=True, type="mayaAscii")

# Open a scene (if it exists)
if cmds.file(file_path, q=True, exists=True):
    cmds.file(file_path, open=True, force=True)
else:
    print("File does not exist")


