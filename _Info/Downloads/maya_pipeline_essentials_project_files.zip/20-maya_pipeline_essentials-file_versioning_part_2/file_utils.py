import os

import maya.cmds as cmds
import maya.api.OpenMaya as om


def next_version_path(scene_path, extension):
    dir_path = os.path.dirname(scene_path)
    file_name = os.path.basename(scene_path)
    base_file_name = file_name.split(".")[0]

    current_versions = get_current_versions(dir_path, base_file_name)
    print(current_versions)

def get_current_versions(dir_path, base_file_name):
    current_versions = []

    file_names = os.listdir(dir_path)
    for file_name in file_names:
        if file_name.startswith("{0}.".format(base_file_name)):
            split_file_name = file_name.split(".")
            if len(split_file_name) == 3:
                version_number_str = split_file_name[1]
                try:
                    version_number_int = int(version_number_str)
                except:
                    continue

                current_versions.append(version_number_int)

    current_versions.sort()

    return current_versions


if __name__ == "__main__":
    file_path = "D:/MayaScenes/test_scene.ma"
    next_version_path(file_path, "ma")


