import json
import os

import maya.cmds as cmds
import maya.api.OpenMaya as om





if __name__ == "__main__":
    pass

