import json
import os

import maya.cmds as cmds
import maya.api.OpenMaya as om


REPO_PATH = os.environ["MAYA_REPO"]
META_EXT = "meta"

def read_json(file_path):
    with open(file_path, "r") as file_for_read:
        data = json.load(file_for_read)

    return data

def write_json(file_path, data):
    with open(file_path, "w") as file_for_write:
        json.dump(data, file_for_write, indent=4, sort_keys=False)

def get_extension_from_type(file_type):
    if file_type == "mayaAscii":
        return "ma"

    return "mb"

def get_resolved_shot_dir_path():
    return "{0}/shots".format(REPO_PATH)

def get_resolved_file_path(file_name, extension):
    if file_name:
        return "{0}/{1}.{2}".format(get_resolved_shot_dir_path(), file_name, extension)

    return ""

def get_unresolved_file_path(file_name, extension):
    if file_name:
        return "shots/{0}.{1}".format(file_name, extension)

    return ""


if __name__ == "__main__":
    file_path = get_resolved_file_path("test", "ma")

    json_data = {
        "test_data": "my_data"
    }

    write_json(file_path, json_data)

    read_json(file_path)


