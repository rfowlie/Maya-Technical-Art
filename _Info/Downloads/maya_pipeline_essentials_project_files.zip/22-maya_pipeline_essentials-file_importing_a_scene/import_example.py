import maya.cmds as cmds

cube_scene = "D:/MayaScenes/cube.ma"
sphere_scene = "D:/MayaScenes/sphere.ma"
cylinder_scene = "D:MayaScenes/cylinder.ma"

# Open the cube scene
cmds.file(cube_scene, open=True, force=True)

# Import (no namespace)
cmds.file(sphere_scene, i=True)

# Import with a namespace
cmds.file(cylinder_scene, i=True, namespace="cylinder")
