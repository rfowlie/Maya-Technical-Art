import os

import maya.cmds as cmds

env_var_name = "REPO_PATH"
root_path = os.environ[env_var_name]

file_nodes = cmds.ls(type="file")

for file_node in file_nodes:
    attr = "{0}.fileTextureName".format(file_node)

    file_path = cmds.getAttr(attr)
    print("Original File Path: {0}".format(file_path))

    file_path = file_path.replace("\\", "/")

    if file_path.startswith(root_path):
        file_path = file_path.replace(root_path, "${0}".format(env_var_name), 1)
        print("Updated File Path: {0}".format(file_path))

        cmds.setAttr(attr, file_path, type="string")
