import json
import os

import maya.cmds as cmds
import maya.api.OpenMaya as om


REPO_PATH = os.environ["MAYA_REPO"]
META_EXT = "meta"

def read_json(file_path):
    with open(file_path, "r") as file_for_read:
        data = json.load(file_for_read)

    return data

def write_json(file_path, data):
    with open(file_path, "w") as file_for_write:
        json.dump(data, file_for_write, indent=4, sort_keys=False)

def get_extension_from_type(file_type):
    if file_type == "mayaAscii":
        return "ma"

    return "mb"

def get_resolved_shot_dir_path():
    return "{0}/shots".format(REPO_PATH)

def get_resolved_file_path(file_name, extension):
    if file_name:
        return "{0}/{1}.{2}".format(get_resolved_shot_dir_path(), file_name, extension)

    return ""

def get_unresolved_file_path(file_name, extension):
    if file_name:
        return "shots/{0}.{1}".format(file_name, extension)

    return ""

def save_shot(file_name, file_type="mayaAscii"):
    shot_dir_path = get_resolved_shot_dir_path()
    if not os.path.exists(shot_dir_path):
        om.MGlobal.displayError("Shots directory does not exist: {0}".format(shot_dir_path))
        return

    if file_type != "mayaAscii":
        file_type = "mayaBinary"

    extension = get_extension_from_type(file_type)

    shot_data = {
        "shot_name": file_name,
        "unresolved_path": get_unresolved_file_path(file_name, extension)
    }

    ref_nodes = cmds.ls(references=True)
    references = []
    for ref_node in ref_nodes:
        ref_data = {
            "ref_node": ref_node,
            "loaded": cmds.referenceQuery(ref_node, isLoaded=True)
        }

        references.append(ref_data)

    shot_data["references"] = references

    shot_path = get_resolved_file_path(file_name, extension)
    cmds.file(rename=shot_path)
    cmds.file(save=True, type=file_type)

    meta_file_path = get_resolved_file_path(file_name, META_EXT)
    write_json(meta_file_path, shot_data)

    om.MGlobal.displayInfo("Shot Saved: {0}".format(shot_path))

def load_shot(file_path, loaded_ref_nodes=[], force_overwrite=False):
    if cmds.file(q=True, modified=True) and not force_overwrite:
        om.MGlobal.displayError("Current scene contains unsaved changes")
        return

    data = read_json(file_path)
    shot_path = "{0}/{1}".format(REPO_PATH, data["unresolved_path"])

    print("Loading shot: {0}".format(data["shot_name"]))
    cmds.file(shot_path, open=True, force=force_overwrite, loadReferenceDepth="none")

    for ref_node in loaded_ref_nodes:
        print("Loading reference: {0}".format(ref_node))
        cmds.file(loadReference=ref_node)

def get_shot_list():
    ext = ".{0}".format(META_EXT)
    ext_length = len(ext)

    shot_list = []
    shot_dir_path = get_resolved_shot_dir_path()

    if os.path.exists(shot_dir_path):
        for f in os.listdir(shot_dir_path):
            if f.endswith(ext):
                shot_name = f[:-ext_length]
                shot_path = "{0}/{1}".format(shot_dir_path, f)
                shot_list.append([shot_name, shot_path])
    else:
        om.MGlobal.displayError("Shots directory does not exist: {0}".format(shot_dir_path))

    return shot_list


if __name__ == "__main__":
    for shot in get_shot_list():
        print(shot)










