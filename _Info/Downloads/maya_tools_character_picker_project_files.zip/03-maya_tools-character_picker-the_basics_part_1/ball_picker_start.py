try:
    # Qt5
    from PySide2 import QtCore
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from shiboken2 import wrapInstance
except:
    # Qt6
    from PySide6 import QtCore
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from shiboken6 import wrapInstance
    
import sys
import maya.OpenMayaUI as omui
import maya.cmds as cmds


class PickerHelpers:
    
    @classmethod
    def maya_main_window(cls):
        main_window_ptr = omui.MQtUtil.mainWindow()
        return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)


class PickerUI(QtWidgets.QWidget):
    
    BG_IMAGE_PATH = "E:/CharacterPicker/bg_image.png"
    
    def __init__(self, parent=PickerHelpers.maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Ball Picker")
        self.setWindowFlags(QtCore.Qt.Window)

        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)
        


if __name__ == "__main__":

    try:
        picker_ui_dialog.close() # pylint: disable=E0601
        picker_ui_dialog.deleteLater()
    except:
        pass

    picker_ui_dialog = PickerUI()
    picker_ui_dialog.show()