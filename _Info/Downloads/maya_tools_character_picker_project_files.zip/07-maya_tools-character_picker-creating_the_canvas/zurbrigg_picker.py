try:
    # Qt5
    from PySide2 import QtCore
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from shiboken2 import wrapInstance

    from PySide2.QtWidgets import QAction

except:
    # Qt6
    from PySide6 import QtCore
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from shiboken6 import wrapInstance

    from PySide6.QtGui import QAction


import sys
import json
from functools import partial

import maya.OpenMaya as om  # pylint: disable=E0611,E0001
import maya.OpenMayaUI as omui
import maya.cmds as cmds


class PickerEditorHeaderWidget(QtWidgets.QWidget):

    def __init__(self, text, parent=None):
        super().__init__(parent)

        self.setAutoFillBackground(True)
        self.set_background_color(None)

        self.text_label = QtWidgets.QLabel()
        self.text_label.setTextFormat(QtCore.Qt.RichText)
        self.text_label.setAlignment(QtCore.Qt.AlignLeft)

        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.main_layout.setContentsMargins(4, 4, 4, 4)
        self.main_layout.addWidget(self.text_label)

        self.set_text(text)

    def set_text(self, text):
        self.text_label.setText("<b>{0}</b>".format(text))

    def set_background_color(self, color):
        if not color:
            color = QtWidgets.QPushButton().palette().color(QtGui.QPalette.Button)

        palette = self.palette()
        palette.setColor(QtGui.QPalette.Window, color)
        self.setPalette(palette)
        

class PickerEditorColorButton(QtWidgets.QLabel):

    color_changed = QtCore.Signal()

    def __init__(self, color=QtCore.Qt.white, parent=None):
        super().__init__(parent)

        self._color = QtGui.QColor() # Invalid color

        self.set_size(50, 14)
        self.set_color(color)

    def set_size(self, width, height):
        self.setFixedSize(width, height)

    def set_color(self, color):
        color = QtGui.QColor(color)

        if self._color != color:
            self._color = color

            pixmap = QtGui.QPixmap(self.size())
            pixmap.fill(self._color)
            self.setPixmap(pixmap)

            self.color_changed.emit()

    def get_color(self):
        return self._color

    def select_color(self):
        color = QtWidgets.QColorDialog.getColor(self.get_color(), self, options=QtWidgets.QColorDialog.DontUseNativeDialog)
        if color.isValid():
            self.set_color(color)

    def mouseReleaseEvent(self, mouse_event):
        if mouse_event.button() == QtCore.Qt.LeftButton:
            self.select_color()
        

class PickerEditorWindow(QtWidgets.QDialog):

    IMAGE_FILE_FILTERS = "PNG (*.png);;All Files (*.*)"


    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Editor")
        self.setMinimumSize(350, 400)

        self._geometry = None
        self._selected_image_filter = None

        self.create_widgets()
        self.create_layout()
        self.create_connections()
        
        self.set_button_wdg_visible(True)
        self.set_selection_wdg_visible(True)

    def create_widgets(self):
        self.name_le = QtWidgets.QLineEdit()
        self.title_le = QtWidgets.QLineEdit()
        self.bg_image_le = QtWidgets.QLineEdit()
        self.select_bg_image_btn = QtWidgets.QPushButton("...")
        self.select_bg_image_btn.setFixedSize(20, 20)
        
        self.canvas_width_sb = QtWidgets.QSpinBox()
        self.canvas_width_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.canvas_width_sb.setMinimum(0)
        self.canvas_width_sb.setMaximum(1024)
        self.canvas_width_sb.setValue(256)
        
        self.canvas_height_sb = QtWidgets.QSpinBox()
        self.canvas_height_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.canvas_height_sb.setMinimum(0)
        self.canvas_height_sb.setMaximum(1024)
        self.canvas_height_sb.setValue(256)
        
        self.canvas_color_btn = PickerEditorColorButton()
        
        self.size_from_image_btn = QtWidgets.QPushButton("From Image")
        self.size_from_image_btn.setFixedSize(80, 22)

        self.x_sb = QtWidgets.QSpinBox()
        self.x_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.x_sb.setMinimum(0)
        self.x_sb.setMaximum(1024)
        self.x_sb.setValue(0)
        
        self.y_sb = QtWidgets.QSpinBox()
        self.y_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.y_sb.setMinimum(0)
        self.y_sb.setMaximum(1024)
        self.y_sb.setValue(0)
        
        self.width_sb = QtWidgets.QSpinBox()
        self.width_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.width_sb.setMinimum(4)
        self.width_sb.setMaximum(100)
        self.width_sb.setValue(20)
        
        self.height_sb = QtWidgets.QSpinBox()
        self.height_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.height_sb.setMinimum(4)
        self.height_sb.setMaximum(100)
        self.height_sb.setValue(20)

        self.text_color_btn = PickerEditorColorButton()
        self.bg_color_btn = PickerEditorColorButton()

        self.btn_text_le = QtWidgets.QLineEdit()

        self.selection_list_wdg = QtWidgets.QListWidget()
        self.selection_list_wdg.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        
        self.add_to_selection_btn = QtWidgets.QPushButton("+")
        self.add_to_selection_btn.setFixedSize(20, 20)
        self.remove_from_selection_btn = QtWidgets.QPushButton("-")
        self.remove_from_selection_btn.setFixedSize(20, 20)
        
        self.script_text_edit = QtWidgets.QPlainTextEdit()
        self.execute_script_btn = QtWidgets.QPushButton("Execute")
        
        self.selection_rb = QtWidgets.QRadioButton("Selection")
        self.selection_rb.setChecked(True)
        self.script_rb = QtWidgets.QRadioButton("Script")
        
        self.button_wdg = QtWidgets.QWidget()
        self.selection_wdg = QtWidgets.QWidget()
        self.script_wdg = QtWidgets.QWidget()
        self.stretch_wdg = QtWidgets.QWidget()

    def create_layout(self):
        bg_image_layout = QtWidgets.QHBoxLayout()
        bg_image_layout.setSpacing(6)
        bg_image_layout.addWidget(self.bg_image_le)
        bg_image_layout.addWidget(self.select_bg_image_btn)
        
        canvas_size_layout = QtWidgets.QHBoxLayout()
        canvas_size_layout.setSpacing(4)
        canvas_size_layout.addWidget(self.canvas_width_sb)
        canvas_size_layout.addWidget(QtWidgets.QLabel("x"))
        canvas_size_layout.addWidget(self.canvas_height_sb)
        canvas_size_layout.addSpacing(4)
        canvas_size_layout.addWidget(self.size_from_image_btn)
        canvas_size_layout.addStretch()
        canvas_size_layout.addWidget(self.canvas_color_btn)
        
        tab_properties_layout = QtWidgets.QFormLayout()
        tab_properties_layout.setContentsMargins(6, 6, 6, 6)
        tab_properties_layout.setSpacing(6)
        tab_properties_layout.addRow("Rig Name", self.name_le)
        tab_properties_layout.addRow("Title", self.title_le)
        tab_properties_layout.addRow("Image", bg_image_layout)
        tab_properties_layout.addRow("Canvas Size", canvas_size_layout)
        
        background_layout = QtWidgets.QHBoxLayout()
        background_layout.addWidget(self.x_sb)
        background_layout.addWidget(QtWidgets.QLabel("y"))
        background_layout.addWidget(self.y_sb)
        background_layout.addWidget(QtWidgets.QLabel("w"))
        background_layout.addWidget(self.width_sb)
        background_layout.addWidget(QtWidgets.QLabel("h"))
        background_layout.addWidget(self.height_sb)
        background_layout.addStretch()
        background_layout.addWidget(self.bg_color_btn)

        text_layout = QtWidgets.QHBoxLayout()
        text_layout.addWidget(self.btn_text_le)
        text_layout.addWidget(self.text_color_btn)
        
        edit_selection_layout = QtWidgets.QVBoxLayout()
        edit_selection_layout.addWidget(self.add_to_selection_btn)
        edit_selection_layout.addWidget(self.remove_from_selection_btn)
        edit_selection_layout.addStretch()
        
        selection_body_layout = QtWidgets.QHBoxLayout()
        selection_body_layout.setSpacing(6)
        selection_body_layout.addWidget(self.selection_list_wdg)
        selection_body_layout.addLayout(edit_selection_layout)
        
        selection_layout = QtWidgets.QVBoxLayout()
        selection_layout.setContentsMargins(10, 6, 6, 6)
        selection_layout.addWidget(PickerEditorHeaderWidget("Objects to Select"))
        selection_layout.addLayout(selection_body_layout)
        self.selection_wdg.setLayout(selection_layout)
        
        execute_script_layout = QtWidgets.QHBoxLayout()
        execute_script_layout.addStretch()
        execute_script_layout.addWidget(self.execute_script_btn)
        
        script_layout = QtWidgets.QVBoxLayout()
        script_layout.setContentsMargins(10, 6, 6, 6)
        script_layout.addWidget(PickerEditorHeaderWidget("Python Script"))
        script_layout.addWidget(self.script_text_edit)
        script_layout.addLayout(execute_script_layout)
        self.script_wdg.setLayout(script_layout)
        
        rb_layout = QtWidgets.QHBoxLayout()
        rb_layout.addWidget(self.selection_rb)
        rb_layout.addWidget(self.script_rb)
        rb_layout.addStretch()

        button_properties_layout = QtWidgets.QFormLayout()
        button_properties_layout.setContentsMargins(6, 6, 6, 6)
        button_properties_layout.setSpacing(6)
        button_properties_layout.addRow("x", background_layout)
        button_properties_layout.addRow("Text", text_layout)
        button_properties_layout.addRow("Type", rb_layout)
        
        button_layout = QtWidgets.QVBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addWidget(PickerEditorHeaderWidget("Button"))
        button_layout.addLayout(button_properties_layout)
        button_layout.addWidget(self.selection_wdg)
        button_layout.addWidget(self.script_wdg)
        self.button_wdg.setLayout(button_layout)
        
        stretch_layout = QtWidgets.QVBoxLayout()
        stretch_layout.addStretch()
        self.stretch_wdg.setLayout(stretch_layout)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(PickerEditorHeaderWidget("Canvas"))
        main_layout.addLayout(tab_properties_layout)
        main_layout.addWidget(self.button_wdg)
        main_layout.addWidget(self.stretch_wdg)

    def create_connections(self):
        self.name_le.editingFinished.connect(self.on_name_changed)
        self.title_le.editingFinished.connect(self.on_title_changed)
        self.bg_image_le.editingFinished.connect(self.on_bg_image_path_changed)
        self.select_bg_image_btn.clicked.connect(self.select_bg_image_path)
        
        self.canvas_width_sb.valueChanged.connect(self.on_canvas_size_changed)
        self.canvas_height_sb.valueChanged.connect(self.on_canvas_size_changed)
        self.size_from_image_btn.clicked.connect(self.set_canvas_size_from_bg_image)
        self.canvas_color_btn.color_changed.connect(self.update_canvas_color)
        
        self.x_sb.valueChanged.connect(self.update_button_properties)
        self.y_sb.valueChanged.connect(self.update_button_properties)
        self.width_sb.valueChanged.connect(self.update_button_properties)
        self.height_sb.valueChanged.connect(self.update_button_properties)
        
        self.btn_text_le.textChanged.connect(self.update_button_properties)
        
        self.text_color_btn.color_changed.connect(self.update_button_properties)
        self.bg_color_btn.color_changed.connect(self.update_button_properties)
        
        self.add_to_selection_btn.clicked.connect(self.add_current_to_selection)
        self.remove_from_selection_btn.clicked.connect(self.remove_selected_items_from_selection)
        
        self.script_text_edit.textChanged.connect(self.update_button_script)
        self.execute_script_btn.clicked.connect(self.test_button_script)
        
        self.selection_rb.toggled.connect(self.update_button_properties)
        self.selection_rb.toggled.connect(self.set_selection_wdg_visible)
        
        
    def set_button_wdg_visible(self, visible):
        self.button_wdg.setVisible(visible)
        self.stretch_wdg.setVisible(not visible)
        
    def set_selection_wdg_visible(self, visible):
        self.selection_wdg.setVisible(visible)
        
        self.script_wdg.setVisible(not visible)
        self.execute_script_btn.setVisible(not visible)

    def set_name(self, name):
        if name != self.name_le.text():
            self.name_le.setText(name)
            
    def on_name_changed(self):
        print("TODO: on_name_changed()")

    def set_title(self, name):
        if name != self.title_le.text():
            self.title_le.setText(name)

    def on_title_changed(self):
        print("TODO: on_title_changed()")

    def on_bg_image_path_changed(self):
        print("TODO: on_bg_image_path_changed()")
        
    def on_canvas_size_changed(self):
        print("TODO: on_canvas_size_changed()")
            
    def set_canvas_size_from_bg_image(self):
        print("TODO: set_canvas_size_from_bg_image()")
            
    def update_canvas_color(self):
        print("TODO: update_canvas_color()")

    def select_bg_image_path(self):
        current_path = self.bg_image_le.text()

        new_path, self._selected_image_filter = QtWidgets.QFileDialog.getOpenFileName(self, "Select Background Image", current_path, PickerEditorWindow.IMAGE_FILE_FILTERS, self._selected_image_filter)
        if new_path:
            print("TODO: select_bg_image_path()")
        
    def update_button_properties(self):
        print("TODO: update_button_properties()")
        
    def add_current_to_selection(self):
        print("TODO: add_current_to_selection()")
        
    def remove_selected_items_from_selection(self):
        print("TODO: remove_selected_items_from_selection()")
                
    def update_button_script(self):
        print("TODO: update_button_script()")
            
    def test_button_script(self):
        print("TODO: test_button_script()")

    def showEvent(self, e):
        if self._geometry:
            self.restoreGeometry(self._geometry)
        else:
            parent_pos = self.parentWidget().pos()
            parent_rect = self.parentWidget().rect()
            self.move(parent_pos.x() + parent_rect.width() + 10, parent_pos.y())

    def closeEvent(self, e):
        self._geometry = self.saveGeometry()
        
    def keyPressEvent(self, e):
        pass
            
            
class PickerHelpers:

    @classmethod
    def maya_main_window(cls):
        main_window_ptr = omui.MQtUtil.mainWindow()
        return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

    @classmethod
    def is_qt_5(cls):
        return QtCore.__version_info__[0] == 5  # pylint: disable=E1101
        
    @classmethod
    def mouse_pos_from_event(cls, e):
        if cls.is_qt_5():
            return e.pos()
        else:
            return e.position().toPoint()


class PickerCanvas(QtWidgets.QWidget):

    DEFAULT_CANVAS_SIZE = QtCore.QSize(512, 512)
    DEFAULT_CANVAS_COLOR = QtGui.QColor(QtCore.Qt.darkGray)
    
    EDIT_BUTTON_COLOR = QtGui.QColor(0, 255, 0)
    
    BOX_SELECT_COLOR = QtGui.QColor(255, 0, 0)
    BOX_SELECT_EDIT_COLOR = QtGui.QColor(0, 255, 0)

    title_changed = QtCore.Signal(str)


    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._file_path = None
        self._rig_name = "Unnamed"
        self._namespace = ""
        self._title = "Untitled"
        self._bg_image_path = ""
        self._bg_pixmap = None
        
        self._canvas_size = PickerCanvas.DEFAULT_CANVAS_SIZE
        self._canvas_color = PickerCanvas.DEFAULT_CANVAS_COLOR
        
        self._buttons = []
        
        self.set_canvas_size(self._canvas_size.width(), self._canvas_size.height())
        
    def set_rig_name(self, rig_name):
        self._rig_name = rig_name
        
    def rig_name(self):
        return self._rig_name
        
    def set_title(self, title):
        self._title = title
        self.title_changed.emit(self._title)
        
    def set_canvas_size(self, width, height):
        self._canvas_size = QtCore.QSize(width, height)
        
        self.setFixedSize(self._canvas_size)
        self.update()
        
    def canvas_size(self):
        return self._canvas_size
        
    def set_canvas_color(self, color):
        self._canvas_color = QtGui.QColor(color)
        self.update()
        
    def canvas_color(self):
        return self._canvas_color
        
    def paintEvent(self, e):
        painter = QtGui.QPainter(self)
        painter.fillRect(self.rect(), self._canvas_color)


class PickerTab(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        
        self._canvas = PickerCanvas(self)
        
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

    def keyPressEvent(self, e):
        pass

    def mousePressEvent(self, e):
        pass    

    def mouseReleaseEvent(self, e):
        pass

    def mouseMoveEvent(self, e):
        pass

    def wheelEvent(self, e):
        pass

    def show_context_menu(self, pos):
        print("TODO: show_context_menu")


class PickerUI(QtWidgets.QWidget):

    FILE_FILTERS = "JSON (*.json);;All Files (*.*)"
    
    
    def __init__(self, parent=PickerHelpers.maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Zurbrigg Picker")
        self.setMinimumSize(256, 256)

        self.setWindowFlags(QtCore.Qt.Window)

        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self._selected_filter = None

        self.create_widgets()
        self.create_menus()
        self.create_layout()
        self.create_connections()
        
        self.update_namespace_cmb_state()

        self.editor_window = PickerEditorWindow(self)

    def create_widgets(self):
        self.tab_widget = QtWidgets.QTabWidget()
        self.tab_widget.setMovable(True)
        self.tab_widget.tabBar().setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        
        self.namespace_cmb = QtWidgets.QComboBox(self)
        self.namespace_cmb.setStyleSheet("background-color: #3f3f3f")
        self.namespace_cmb.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToContents)
        self.namespace_cmb.addItem("<none>")

    def create_menus(self):
        self.menu_bar = QtWidgets.QMenuBar()
        self.file_menu = self.menu_bar.addMenu("File")

        self.new_tab_action = self.file_menu.addAction("New")
        self.new_tab_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.New))
        self.file_menu.addSeparator()

        self.open_tab_action = self.file_menu.addAction("Open")
        self.open_tab_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.Open))

        self.save_action_action = self.file_menu.addAction("Save")
        self.save_action_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.Save))
        
        self.save_as_action_action = self.file_menu.addAction("Save As...")
        self.save_as_action_action.setShortcut(QtGui.QKeySequence("Ctrl+Shift+S"))
        self.file_menu.addSeparator()
        
        self.close_tab_action = self.file_menu.addAction("Close Tab")
        self.close_tab_action.setShortcut(QtGui.QKeySequence("Ctrl+Shift+C"))

        self.edit_menu = self.menu_bar.addMenu("Edit")
        
        self.toggle_editor_action = self.edit_menu.addAction("Edit Mode")
        self.toggle_editor_action.setShortcut(QtGui.QKeySequence("Ctrl+E"))
        self.toggle_editor_action.setCheckable(True)
        self.edit_menu.addSeparator()
        
        self.resize_to_canvas_action = self.edit_menu.addAction("Resize to Canvas")
        self.resize_to_canvas_action.setShortcut(QtGui.QKeySequence("Ctrl+R"))
        
        self.reset_pan_and_zoom_action = self.edit_menu.addAction("Reset Pan/Zoom")
        self.reset_pan_and_zoom_action.setShortcut(QtGui.QKeySequence("Ctrl+\\"))

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setMenuBar(self.menu_bar)
        main_layout.addWidget(self.tab_widget)

    def create_connections(self):
        self.new_tab_action.triggered.connect(self.new_tab)
        self.open_tab_action.triggered.connect(self.open_tab)
        self.save_action_action.triggered.connect(self.save_tab)
        self.save_as_action_action.triggered.connect(self.save_tab_as)
        self.close_tab_action.triggered.connect(self.close_tab)

        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        
        self.namespace_cmb.currentTextChanged.connect(self.on_namespace_changed)

        self.toggle_editor_action.toggled.connect(self.set_editor_visible)
        self.resize_to_canvas_action.triggered.connect(self.resize_to_canvas)
        self.reset_pan_and_zoom_action.triggered.connect(self.reset_pan_and_zoom)

        self.edit_menu.aboutToShow.connect(self.update_edit_menu)

    def current_index(self):
        return self.tab_widget.currentIndex()

    def current_tab(self):
        index = self.current_index()
        if index >= 0:
            picker_tab = self.tab_widget.widget(index)
            return picker_tab

    def new_tab(self):
        picker_tab = PickerTab()
        index = self.tab_widget.addTab(picker_tab, "Untitled")
        
        return index

    def open_tab(self, file_path):
        if file_path:
            file_paths = [file_path]
        else:
            file_paths, self._selected_filter = QtWidgets.QFileDialog.getOpenFileNames(self, "Select a File", "", PickerUI.FILE_FILTERS, self._selected_filter)
        
        print("TODO: open_tab()")

    def save_tab(self, file_path=None):
        print("TODO: save_tab()")
            
    def save_tab_as(self):
        file_path, self._selected_filter = QtWidgets.QFileDialog.getSaveFileName(self, "Save File As", "", self.FILE_FILTERS, self._selected_filter)
        if file_path:
            self.save_tab(file_path)
            
    def close_tab(self, index=-1):
        if index < 0:
            index = self.current_index()
            
        self.tab_widget.removeTab(index)

    def update_edit_menu(self):
        if self.editor_window:
            self.toggle_editor_action.setChecked(self.editor_window.isVisible())
        else:
            self.toggle_editor_action.setChecked(False)

    def set_editor_visible(self, visible):
        if visible:
            self.editor_window.show()
        else:
            self.editor_window.close()
            
    def resize_to_canvas(self):
        print("TODO: resize_to_canvas()")
                
    def reset_pan_and_zoom(self):
        print("TODO: reset_pan_and_zoom()")

    def on_tab_changed(self, index):
        print("on_tab_changed()")
            
    def on_namespace_changed(self, namespace):
        print("on_namespace_changed()")
        
    def update_namespace_cmb_state(self):
        x = self.width() - self.namespace_cmb.width() - 10
        y = self.menu_bar.height() + self.tab_widget.tabBar().height() + 10
        self.namespace_cmb.move(x, y)
        self.namespace_cmb.raise_()
        
        self.namespace_cmb.setVisible(self.current_index() >= 0)

    def showEvent(self, e):
        self.update_namespace_cmb_state()

    def closeEvent(self, e):
        if self.editor_window and self.editor_window.isVisible():
            self.editor_window.close()
            
    def resizeEvent(self, e):
        self.update_namespace_cmb_state()

    def keyPressEvent(self, e):
        pass


if __name__ == "__main__":

    try:
        picker_ui_dialog.close() # pylint: disable=E0601
        picker_ui_dialog.deleteLater()
    except:
        pass

    picker_ui_dialog = PickerUI()
    picker_ui_dialog.show()
    
    
    
    
    
    
    
    
    
    
    
    
    
