try:
    # Qt5
    from PySide2 import QtCore
    from PySide2 import QtGui
    from PySide2 import QtWidgets
    from shiboken2 import wrapInstance

    from PySide2.QtWidgets import QAction

except:
    # Qt6
    from PySide6 import QtCore
    from PySide6 import QtGui
    from PySide6 import QtWidgets
    from shiboken6 import wrapInstance

    from PySide6.QtGui import QAction


import sys
import json
from functools import partial

import maya.OpenMaya as om  # pylint: disable=E0611,E0001
import maya.OpenMayaUI as omui
import maya.cmds as cmds


class PickerEditorHeaderWidget(QtWidgets.QWidget):

    def __init__(self, text, parent=None):
        super().__init__(parent)

        self.setAutoFillBackground(True)
        self.set_background_color(None)

        self.text_label = QtWidgets.QLabel()
        self.text_label.setTextFormat(QtCore.Qt.RichText)
        self.text_label.setAlignment(QtCore.Qt.AlignLeft)

        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.main_layout.setContentsMargins(4, 4, 4, 4)
        self.main_layout.addWidget(self.text_label)

        self.set_text(text)

    def set_text(self, text):
        self.text_label.setText("<b>{0}</b>".format(text))

    def set_background_color(self, color):
        if not color:
            color = QtWidgets.QPushButton().palette().color(QtGui.QPalette.Button)

        palette = self.palette()
        palette.setColor(QtGui.QPalette.Window, color)
        self.setPalette(palette)
        

class PickerEditorColorButton(QtWidgets.QLabel):

    color_changed = QtCore.Signal()

    def __init__(self, color=QtCore.Qt.white, parent=None):
        super().__init__(parent)

        self._color = QtGui.QColor() # Invalid color

        self.set_size(50, 14)
        self.set_color(color)

    def set_size(self, width, height):
        self.setFixedSize(width, height)

    def set_color(self, color):
        color = QtGui.QColor(color)

        if self._color != color:
            self._color = color

            pixmap = QtGui.QPixmap(self.size())
            pixmap.fill(self._color)
            self.setPixmap(pixmap)

            self.color_changed.emit()

    def get_color(self):
        return self._color

    def select_color(self):
        color = QtWidgets.QColorDialog.getColor(self.get_color(), self, options=QtWidgets.QColorDialog.DontUseNativeDialog)
        if color.isValid():
            self.set_color(color)

    def mouseReleaseEvent(self, mouse_event):
        if mouse_event.button() == QtCore.Qt.LeftButton:
            self.select_color()
        

class PickerEditorWindow(QtWidgets.QDialog):

    IMAGE_FILE_FILTERS = "PNG (*.png);;All Files (*.*)"
    
    edit_mode_enabled = False


    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Editor")
        self.setMinimumSize(350, 400)

        self._geometry = None
        self._selected_image_filter = None
        
        self._canvas = None
        self._button = None
        
        self._pause_property_updates = False

        self.create_widgets()
        self.create_layout()
        self.create_connections()
        
        self.set_button_wdg_visible(True)
        self.set_selection_wdg_visible(True)

    def create_widgets(self):
        self.name_le = QtWidgets.QLineEdit()
        self.title_le = QtWidgets.QLineEdit()
        self.bg_image_le = QtWidgets.QLineEdit()
        self.select_bg_image_btn = QtWidgets.QPushButton("...")
        self.select_bg_image_btn.setFixedSize(20, 20)
        
        self.canvas_width_sb = QtWidgets.QSpinBox()
        self.canvas_width_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.canvas_width_sb.setMinimum(0)
        self.canvas_width_sb.setMaximum(1024)
        self.canvas_width_sb.setValue(256)
        
        self.canvas_height_sb = QtWidgets.QSpinBox()
        self.canvas_height_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.canvas_height_sb.setMinimum(0)
        self.canvas_height_sb.setMaximum(1024)
        self.canvas_height_sb.setValue(256)
        
        self.canvas_color_btn = PickerEditorColorButton()
        
        self.size_from_image_btn = QtWidgets.QPushButton("From Image")
        self.size_from_image_btn.setFixedSize(80, 22)

        self.x_sb = QtWidgets.QSpinBox()
        self.x_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.x_sb.setMinimum(0)
        self.x_sb.setMaximum(1024)
        self.x_sb.setValue(0)
        
        self.y_sb = QtWidgets.QSpinBox()
        self.y_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.y_sb.setMinimum(0)
        self.y_sb.setMaximum(1024)
        self.y_sb.setValue(0)
        
        self.width_sb = QtWidgets.QSpinBox()
        self.width_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.width_sb.setMinimum(4)
        self.width_sb.setMaximum(100)
        self.width_sb.setValue(20)
        
        self.height_sb = QtWidgets.QSpinBox()
        self.height_sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons)
        self.height_sb.setMinimum(4)
        self.height_sb.setMaximum(100)
        self.height_sb.setValue(20)

        self.text_color_btn = PickerEditorColorButton()
        self.bg_color_btn = PickerEditorColorButton()

        self.btn_text_le = QtWidgets.QLineEdit()

        self.selection_list_wdg = QtWidgets.QListWidget()
        self.selection_list_wdg.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        
        self.add_to_selection_btn = QtWidgets.QPushButton("+")
        self.add_to_selection_btn.setFixedSize(20, 20)
        self.remove_from_selection_btn = QtWidgets.QPushButton("-")
        self.remove_from_selection_btn.setFixedSize(20, 20)
        
        self.script_text_edit = QtWidgets.QPlainTextEdit()
        self.execute_script_btn = QtWidgets.QPushButton("Execute")
        
        self.selection_rb = QtWidgets.QRadioButton("Selection")
        self.selection_rb.setChecked(True)
        self.script_rb = QtWidgets.QRadioButton("Script")
        
        self.button_wdg = QtWidgets.QWidget()
        self.selection_wdg = QtWidgets.QWidget()
        self.script_wdg = QtWidgets.QWidget()
        self.stretch_wdg = QtWidgets.QWidget()

    def create_layout(self):
        bg_image_layout = QtWidgets.QHBoxLayout()
        bg_image_layout.setSpacing(6)
        bg_image_layout.addWidget(self.bg_image_le)
        bg_image_layout.addWidget(self.select_bg_image_btn)
        
        canvas_size_layout = QtWidgets.QHBoxLayout()
        canvas_size_layout.setSpacing(4)
        canvas_size_layout.addWidget(self.canvas_width_sb)
        canvas_size_layout.addWidget(QtWidgets.QLabel("x"))
        canvas_size_layout.addWidget(self.canvas_height_sb)
        canvas_size_layout.addSpacing(4)
        canvas_size_layout.addWidget(self.size_from_image_btn)
        canvas_size_layout.addStretch()
        canvas_size_layout.addWidget(self.canvas_color_btn)
        
        tab_properties_layout = QtWidgets.QFormLayout()
        tab_properties_layout.setContentsMargins(6, 6, 6, 6)
        tab_properties_layout.setSpacing(6)
        tab_properties_layout.addRow("Rig Name", self.name_le)
        tab_properties_layout.addRow("Title", self.title_le)
        tab_properties_layout.addRow("Image", bg_image_layout)
        tab_properties_layout.addRow("Canvas Size", canvas_size_layout)
        
        background_layout = QtWidgets.QHBoxLayout()
        background_layout.addWidget(self.x_sb)
        background_layout.addWidget(QtWidgets.QLabel("y"))
        background_layout.addWidget(self.y_sb)
        background_layout.addWidget(QtWidgets.QLabel("w"))
        background_layout.addWidget(self.width_sb)
        background_layout.addWidget(QtWidgets.QLabel("h"))
        background_layout.addWidget(self.height_sb)
        background_layout.addStretch()
        background_layout.addWidget(self.bg_color_btn)

        text_layout = QtWidgets.QHBoxLayout()
        text_layout.addWidget(self.btn_text_le)
        text_layout.addWidget(self.text_color_btn)
        
        edit_selection_layout = QtWidgets.QVBoxLayout()
        edit_selection_layout.addWidget(self.add_to_selection_btn)
        edit_selection_layout.addWidget(self.remove_from_selection_btn)
        edit_selection_layout.addStretch()
        
        selection_body_layout = QtWidgets.QHBoxLayout()
        selection_body_layout.setSpacing(6)
        selection_body_layout.addWidget(self.selection_list_wdg)
        selection_body_layout.addLayout(edit_selection_layout)
        
        selection_layout = QtWidgets.QVBoxLayout()
        selection_layout.setContentsMargins(10, 6, 6, 6)
        selection_layout.addWidget(PickerEditorHeaderWidget("Objects to Select"))
        selection_layout.addLayout(selection_body_layout)
        self.selection_wdg.setLayout(selection_layout)
        
        execute_script_layout = QtWidgets.QHBoxLayout()
        execute_script_layout.addStretch()
        execute_script_layout.addWidget(self.execute_script_btn)
        
        script_layout = QtWidgets.QVBoxLayout()
        script_layout.setContentsMargins(10, 6, 6, 6)
        script_layout.addWidget(PickerEditorHeaderWidget("Python Script"))
        script_layout.addWidget(self.script_text_edit)
        script_layout.addLayout(execute_script_layout)
        self.script_wdg.setLayout(script_layout)
        
        rb_layout = QtWidgets.QHBoxLayout()
        rb_layout.addWidget(self.selection_rb)
        rb_layout.addWidget(self.script_rb)
        rb_layout.addStretch()

        button_properties_layout = QtWidgets.QFormLayout()
        button_properties_layout.setContentsMargins(6, 6, 6, 6)
        button_properties_layout.setSpacing(6)
        button_properties_layout.addRow("x", background_layout)
        button_properties_layout.addRow("Text", text_layout)
        button_properties_layout.addRow("Type", rb_layout)
        
        button_layout = QtWidgets.QVBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addWidget(PickerEditorHeaderWidget("Button"))
        button_layout.addLayout(button_properties_layout)
        button_layout.addWidget(self.selection_wdg)
        button_layout.addWidget(self.script_wdg)
        self.button_wdg.setLayout(button_layout)
        
        stretch_layout = QtWidgets.QVBoxLayout()
        stretch_layout.addStretch()
        self.stretch_wdg.setLayout(stretch_layout)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(PickerEditorHeaderWidget("Canvas"))
        main_layout.addLayout(tab_properties_layout)
        main_layout.addWidget(self.button_wdg)
        main_layout.addWidget(self.stretch_wdg)

    def create_connections(self):
        self.name_le.editingFinished.connect(self.on_name_changed)
        self.title_le.editingFinished.connect(self.on_title_changed)
        self.bg_image_le.editingFinished.connect(self.on_bg_image_path_changed)
        self.select_bg_image_btn.clicked.connect(self.select_bg_image_path)
        
        self.canvas_width_sb.valueChanged.connect(self.on_canvas_size_changed)
        self.canvas_height_sb.valueChanged.connect(self.on_canvas_size_changed)
        self.size_from_image_btn.clicked.connect(self.set_canvas_size_from_bg_image)
        self.canvas_color_btn.color_changed.connect(self.update_canvas_color)
        
        self.x_sb.valueChanged.connect(self.update_button_properties)
        self.y_sb.valueChanged.connect(self.update_button_properties)
        self.width_sb.valueChanged.connect(self.update_button_properties)
        self.height_sb.valueChanged.connect(self.update_button_properties)
        
        self.btn_text_le.textChanged.connect(self.update_button_properties)
        
        self.text_color_btn.color_changed.connect(self.update_button_properties)
        self.bg_color_btn.color_changed.connect(self.update_button_properties)
        
        self.add_to_selection_btn.clicked.connect(self.add_current_to_selection)
        self.remove_from_selection_btn.clicked.connect(self.remove_selected_items_from_selection)
        
        self.script_text_edit.textChanged.connect(self.update_button_script)
        self.execute_script_btn.clicked.connect(self.test_button_script)
        
        self.selection_rb.toggled.connect(self.update_button_properties)
        self.selection_rb.toggled.connect(self.set_selection_wdg_visible)
        
        
    def set_button_wdg_visible(self, visible):
        self.button_wdg.setVisible(visible)
        self.stretch_wdg.setVisible(not visible)
        
    def set_selection_wdg_visible(self, visible):
        self.selection_wdg.setVisible(visible)
        
        self.script_wdg.setVisible(not visible)
        self.execute_script_btn.setVisible(not visible)
        
    def set_canvas(self, canvas):
        if self._canvas:
            self._canvas.set_buttons_for_edit(None)
            self._canvas.button_for_edit_changed.disconnect(self.set_button)
        
        self._canvas = canvas
        
        if self._canvas:
            self._canvas.button_for_edit_changed.connect(self.set_button)
            self._canvas.set_buttons_for_edit(None)
            
            self.set_name(self._canvas.rig_name())
            self.set_title(self._canvas.title())
            self.bg_image_le.setText(self._canvas.bg_image_path())
            
            canvas_size = self._canvas.canvas_size()
            self.canvas_width_sb.setValue(canvas_size.width())
            self.canvas_height_sb.setValue(canvas_size.height())
            
            self.canvas_color_btn.set_color(self._canvas.canvas_color())
        else:
            self.set_name("")
            self.set_title("")
            self.bg_image_le.setText("")

    def set_name(self, name):
        if name != self.name_le.text():
            self.name_le.setText(name)
            
    def on_name_changed(self):
        if self._canvas:
            self._canvas.set_rig_name(self.name_le.text())

    def set_title(self, name):
        if name != self.title_le.text():
            self.title_le.setText(name)

    def on_title_changed(self):
        if self._canvas:
            self._canvas.set_title(self.title_le.text())

    def on_bg_image_path_changed(self):
        if self._canvas:
            self._canvas.set_bg_image(self.bg_image_le.text())
        
    def on_canvas_size_changed(self):
        if self._canvas:
            self._canvas.set_canvas_size(self.canvas_width_sb.value(), self.canvas_height_sb.value())
            
    def set_canvas_size_from_bg_image(self):
        if self._canvas:
            image_size = self._canvas.bg_image_size()
            self.canvas_width_sb.setValue(image_size.width())
            self.canvas_height_sb.setValue(image_size.height())
            
    def update_canvas_color(self):
        if self._canvas:
            self._canvas.set_canvas_color(self.canvas_color_btn.get_color())

    def select_bg_image_path(self):
        if self._canvas:
            current_path = self.bg_image_le.text()

            new_path, self._selected_image_filter = QtWidgets.QFileDialog.getOpenFileName(self, "Select Background Image", current_path, PickerEditorWindow.IMAGE_FILE_FILTERS, self._selected_image_filter)
            if new_path:
                self._canvas.set_bg_image(new_path)
                self.bg_image_le.setText(self._canvas.bg_image_path())
                
    def set_button(self, button):
        self._button = button
        self.update_button_widgets()

        if self._button:
            self.set_button_wdg_visible(True)
        else:
            self.set_button_wdg_visible(False)
            
    def update_button_widgets(self):
        if not self._pause_property_updates:
            self._pause_property_updates = True
        
            if self._button:
                rect = self._button.base_geometry()
                self.x_sb.setValue(rect.x())
                self.y_sb.setValue(rect.y())
                self.width_sb.setValue(rect.width())
                self.height_sb.setValue(rect.height())
                self.btn_text_le.setText(self._button.text())
                self.text_color_btn.set_color(self._button.text_color())
                self.bg_color_btn.set_color(self._button.bg_color())
                self.script_text_edit.setPlainText(self._button.script())
                
                is_script = self._button.is_script_enabled()
                self.script_rb.setChecked(is_script)
                self.selection_rb.setChecked(not is_script)
                self.set_selection_wdg_visible(not is_script)
            else:
                self.x_sb.setValue(0)
                self.y_sb.setValue(0)
                self.width_sb.setValue(20)
                self.height_sb.setValue(20)
                self.btn_text_le.setText("")
                self.script_text_edit.setPlainText("")
                self.selection_rb.setChecked(True)
                
            self.update_selection_widget()
            
            self._pause_property_updates = False
            
    def update_selection_widget(self):
        self.selection_list_wdg.clear()
        if self._button:
            self.selection_list_wdg.addItems(self._button.objects_to_select())
        
    def update_button_properties(self):
        if not self._pause_property_updates:
            self._pause_property_updates = True
        
            if self._button:
                self._button.set_base_geometry(self.x_sb.value(), self.y_sb.value(), self.width_sb.value(), self.height_sb.value())
                self._button.set_text(self.btn_text_le.text())
                self._button.set_colors(self.text_color_btn.get_color(), self.bg_color_btn.get_color())
                self._button.set_script_enabled(self.script_rb.isChecked())
                
                if self._canvas:
                    self._canvas.update()
                    
            self._pause_property_updates = False
        
    def add_current_to_selection(self):
        if self._button:
            selection = cmds.ls(sl=True)
            if selection:
                selection.extend(self._button.objects_to_select())
                selection = list(set(selection))
                
                self._button.set_objects_to_select(selection)
                
                self.update_selection_widget()
        
    def remove_selected_items_from_selection(self):
        if self._button:
            selected_items = self.selection_list_wdg.selectedItems()
            
            for item in selected_items:
                self._button.remove_object_to_select(item.text())
                
            self.update_selection_widget()
                
    def update_button_script(self):
        if self._pause_property_updates:
            return
            
        if self._button:
            text = self.script_text_edit.toPlainText()
            self._button.set_script(text)
            
    def test_button_script(self):
        if self._button:
            self._button.execute_script

    def showEvent(self, e):
        if self._geometry:
            self.restoreGeometry(self._geometry)
        else:
            parent_pos = self.parentWidget().pos()
            parent_rect = self.parentWidget().rect()
            self.move(parent_pos.x() + parent_rect.width() + 10, parent_pos.y())
            
        PickerEditorWindow.edit_mode_enabled = True

    def closeEvent(self, e):
        self._geometry = self.saveGeometry()
        
        PickerEditorWindow.edit_mode_enabled = False
        if self._canvas:
            self._canvas.set_buttons_for_edit(None)
        
    def keyPressEvent(self, e):
        pass
            
            
class PickerHelpers:

    @classmethod
    def maya_main_window(cls):
        main_window_ptr = omui.MQtUtil.mainWindow()
        return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

    @classmethod
    def is_qt_5(cls):
        return QtCore.__version_info__[0] == 5  # pylint: disable=E1101
        
    @classmethod
    def mouse_pos_from_event(cls, e):
        if cls.is_qt_5():
            return e.pos()
        else:
            return e.position().toPoint()


class PickerCanvasBtn(QtCore.QObject):
    
    position_changed = QtCore.Signal(int, int)
    
    def __init__(self, x=0, y=0, width=20, height=20):
        super().__init__()
        
        self._selected = False
        self._editable = False
        
        self.set_base_geometry(x, y, width, height)
        self.set_colors(QtCore.Qt.white, QtCore.Qt.blue)
        self.set_text("")
        
        self._objects_to_select = []
        self._script = ""
        self._script_enabled = False
        
    def set_base_geometry(self, x, y, width, height):
        self._base_geometry = QtCore.QRectF(x, y, width, height)
        self._geometry = self._base_geometry
        
        self.position_changed.emit(x, y)
        
    def base_geometry(self):
        return self._base_geometry
        
    def set_base_pos(self, x, y):
        self.set_base_geometry(x, y, self._base_geometry.width(), self._base_geometry.height())
        
    def base_pos(self):
        return self._base_geometry.topLeft()
        
    def base_size(self):
        return self._base_geometry.size()
        
    def geometry(self):
        return self._geometry
        
    def contains(self, pos):
        return self._geometry.contains(pos)
        
    def set_colors(self, text_color, bg_color):
        self._text_color = QtGui.QColor(text_color)
        self._bg_color = QtGui.QColor(bg_color)
        
    def text_color(self):
        return self._text_color
        
    def bg_color(self):
        return self._bg_color
        
    def set_text(self, text):
        self._text = text
        
    def text(self):
        return self._text
        
    def set_objects_to_select(self, objects_to_select):
        self._objects_to_select = objects_to_select
        
    def objects_to_select(self):
        return self._objects_to_select
        
    def remove_object_to_select(self, name):
        if name in self._objects_to_select:
            self._objects_to_select.remove(name)
        
    def set_edit_enabled(self, enabled):
        self._editable = enabled
        
    def edit_enabled(self):
        return self._editable
        
    def set_script(self, script):
        self._script = script
        
    def script(self):
        return self._script
        
    def execute_script(self):
        if self._script:
            exec(self._script)
        
    def set_script_enabled(self, enabled):
        self._script_enabled = enabled
        
    def is_script_enabled(self):
        return self._script_enabled
        
    def is_selected(self):
        return self._selected
        
    def update_selected_state(self, current_selection):
        if len(self._objects_to_select) > 0:
            self._selected = True
            for obj in self._objects_to_select:
                if obj not in current_selection:
                    self._selected = False
                    return
                    
        else:
            self._selected = False


class PickerCanvas(QtWidgets.QWidget):

    DEFAULT_CANVAS_SIZE = QtCore.QSize(512, 512)
    DEFAULT_CANVAS_COLOR = QtGui.QColor(QtCore.Qt.darkGray)
    
    EDIT_BUTTON_COLOR = QtGui.QColor(0, 255, 0)
    
    BOX_SELECT_COLOR = QtGui.QColor(255, 0, 0)
    BOX_SELECT_EDIT_COLOR = QtGui.QColor(0, 255, 0)

    button_for_edit_changed = QtCore.Signal(PickerCanvasBtn)
    title_changed = QtCore.Signal(str)


    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._file_path = None
        self._rig_name = "Unnamed"
        self._namespace = ""
        self._title = "Untitled"
        self._bg_image_path = ""
        self._bg_pixmap = None

        test_button = PickerCanvasBtn(10, 10, 80, 20)
        test_button.set_text("Hello World")
        test_button.set_script_enabled(True)
        test_button.set_script("print('Hello World!!!')")

        btn1 = PickerCanvasBtn(10, 55, 20, 20)
        btn1.set_colors(QtCore.Qt.white, QtCore.Qt.red)
        btn1.set_objects_to_select(["pCone1"])

        btn2 = PickerCanvasBtn(40, 55, 20, 20)
        btn2.set_colors(QtCore.Qt.white, QtCore.Qt.green)
        btn2.set_objects_to_select(["pSphere1"])
        
        btn3 = PickerCanvasBtn(70, 55, 20, 20)
        btn3.set_colors(QtCore.Qt.white, QtCore.Qt.cyan)
        btn3.set_objects_to_select(["pCube1", "pCube2"])
        
        self._buttons = [test_button, btn1, btn2, btn3]
        
        self.set_canvas_size(PickerCanvas.DEFAULT_CANVAS_SIZE.width(), PickerCanvas.DEFAULT_CANVAS_SIZE.height())
        self.set_canvas_color(PickerCanvas.DEFAULT_CANVAS_COLOR)
        
        self.reset_box_select_rect()
        
        # temp_image_path = "E:/CharacterPicker/checkerboard.png"
        # self.set_bg_image(temp_image_path)
        
    def set_file_path(self, file_path):
        self._file_path = file_path
        
    def file_path(self):
        return self._file_path
        
    def set_rig_name(self, rig_name):
        self._rig_name = rig_name
        
    def rig_name(self):
        return self._rig_name
        
    def set_title(self, title):
        self._title = title
        self.title_changed.emit(self._title)
        
    def title(self):
        return self._title
        
    def set_canvas_size(self, width, height):
        self._canvas_size = QtCore.QSize(width, height)
        
        self.setFixedSize(self._canvas_size)
        self.update()
        
    def canvas_size(self):
        return self._canvas_size
        
    def set_canvas_color(self, color):
        self._canvas_color = QtGui.QColor(color)
        self.update()
        
    def canvas_color(self):
        return self._canvas_color
        
    def set_bg_image(self, image_path):
        self._bg_image_path = image_path
        
        bg_image = QtGui.QImage(self._bg_image_path)
        self._bg_pixmap = QtGui.QPixmap.fromImage(bg_image)
        
        self.update()
        
    def bg_image_path(self):
        return self._bg_image_path
        
    def bg_image_size(self):
        if self._bg_pixmap:
            return self._bg_pixmap.size()
            
        return self.DEFAULT_CANVAS_SIZE
        
    def add_button(self, pos):
        action = self.sender()
        if action:
            pos = action.data()
            
        btn = PickerCanvasBtn(pos.x(), pos.y())
        self._buttons.append(btn)
        
        self.set_buttons_for_edit([btn])
        
    def duplicate_buttons(self, pos):
        print("TODO: duplicate_buttons()")
        
    def delete_buttons(self):
        editable_buttons = self.get_editable_buttons()
        for btn in editable_buttons:
            self._buttons.remove(btn)
            
        self.set_buttons_for_edit(None)
        self.update()
        
    def update_selection(self):
        selection = cmds.ls(sl=True)
        
        for button in self._buttons:
            button.update_selected_state(selection)
            
        self.update()
        
    def trigger_selected_buttons(self, pos, modifiers):
        objects_to_select = []
        
        if self._box_select_rect.isNull():
            button = self.find_button_at_pos(pos)
            if button:
                if button.is_script_enabled():
                    if modifiers == QtCore.Qt.KeyboardModifier.NoModifier:
                        button.execute_script()
                        return
                        
                elif button.objects_to_select():
                    objects_to_select.extend(button.objects_to_select())
        else:
            buttons_to_trigger = self.buttons_in_box_select_rect()
            for button in buttons_to_trigger:
                objects_to_select.extend(button.objects_to_select())
                
                
        try:
            if modifiers == QtCore.Qt.KeyboardModifier.NoModifier:
                cmds.select(objects_to_select, replace=True)
            elif modifiers == (QtCore.Qt.KeyboardModifier.ControlModifier | QtCore.Qt.KeyboardModifier.ShiftModifier):
                cmds.select(objects_to_select, add=True)
            elif modifiers == QtCore.Qt.KeyboardModifier.ControlModifier:
                cmds.select(objects_to_select, deselect=True)
            elif modifiers == QtCore.Qt.KeyboardModifier.ShiftModifier:
                cmds.select(objects_to_select, toggle=True)
                
        except:
            print("Warning: Selection contains objects not found in scene.")
            
    def get_editable_buttons(self):
        editable_buttons = []
        for btn in self._buttons:
            if btn.edit_enabled():
                editable_buttons.append(btn)
                
        return editable_buttons
        
    def editable_button_count(self):
        return len(self.get_editable_buttons())
        
    def set_buttons_for_edit(self, buttons_for_edit, modifiers=QtCore.Qt.KeyboardModifier.NoModifier):
        if modifiers == QtCore.Qt.KeyboardModifier.NoModifier:
            # replace
            for btn in self._buttons:
                btn.set_edit_enabled(False)
                
        if buttons_for_edit:
            if modifiers == QtCore.Qt.KeyboardModifier.NoModifier or modifiers == (QtCore.Qt.KeyboardModifier.ControlModifier | QtCore.Qt.KeyboardModifier.ShiftModifier):
                # replace/add
                for btn in buttons_for_edit:
                    btn.set_edit_enabled(True)
                    
            elif modifiers == QtCore.Qt.KeyboardModifier.ControlModifier:
                # remove
                for btn in buttons_for_edit:
                    btn.set_edit_enabled(False)
            elif modifiers == QtCore.Qt.KeyboardModifier.ShiftModifier:
                # toggle
                for btn in buttons_for_edit:
                    btn.set_edit_enabled(not btn.edit_enabled())
                    
        updated_buttons_for_edit = self.get_editable_buttons()
        if len(updated_buttons_for_edit) == 1:
            self.button_for_edit_changed.emit(updated_buttons_for_edit[0])
        else:
            self.button_for_edit_changed.emit(None)
                    
        self.update()
                
    def update_buttons_to_edit(self, pos, modifiers):
        buttons_to_edit = []
        
        if self._box_select_rect.isNull():
            button_at_pos = self.find_button_at_pos(pos)
            if button_at_pos:
                buttons_to_edit.append(button_at_pos)
        else:
            buttons_to_edit = self.buttons_in_box_select_rect()
            
        self.set_buttons_for_edit(buttons_to_edit, modifiers)
        
    def find_button_at_pos(self, pos):
        for button in self._buttons:
            if button.contains(pos):
                return button
                
        return None
        
    def set_box_select_rect(self, rect):
        self._box_select_rect = rect
        self.update()
        
    def set_box_select_color(self, color):
        self._box_select_color = color
        
    def reset_box_select_rect(self):
        self._box_select_rect = QtCore.QRectF()
        self.set_box_select_color(PickerCanvas.BOX_SELECT_COLOR)
        self.update()
        
    def buttons_in_box_select_rect(self):
        btn_list = []
        for btn in self._buttons:
            if self._box_select_rect.intersects(btn.geometry()):
                btn_list.append(btn)
                
        return btn_list
        
    def save(self, file_path):
        json_dict = {
            "name": self.rig_name(),
            "title": self.title(),
            "bg_image_path": self.bg_image_path(),
            "canvas_size": [self.canvas_size().width(), self.canvas_size().height()],
            "canvas_color": self.canvas_color().name()
        }
        
        with open(file_path, "w") as file_for_write:
            json.dump(json_dict, file_for_write, indent=4)
            
            self.set_file_path(file_path)
            
        return True
        
    def open(self, file_path):
        json_dict = {}
        with open(file_path, "r") as file_for_read:
            json_dict = json.load(file_for_read)
            
        if json_dict:
            self.set_rig_name(json_dict["name"])
            self.set_title(json_dict["title"])
            self.set_bg_image(json_dict["bg_image_path"])
            self.set_canvas_size(json_dict["canvas_size"][0], json_dict["canvas_size"][1])
            self.set_canvas_color(json_dict["canvas_color"])
            
            self.set_file_path(file_path)
            
            return self.title()
            
        return None
        
    def paintEvent(self, e):
        painter = QtGui.QPainter(self)
        painter.fillRect(self.rect(), self._canvas_color)

        if self._bg_pixmap and not self._bg_pixmap.isNull():
            painter.drawPixmap(0, 0, self._bg_pixmap)
            
        pen = painter.pen()
            
        for button in self._buttons:
            if button.is_selected():
                text_color = QtCore.Qt.black
                bg_color = QtCore.Qt.white
            else:
                text_color = button.text_color()
                bg_color = button.bg_color()
            
            if button.edit_enabled():
                pen.setWidth(4)
                pen.setColor(PickerCanvas.EDIT_BUTTON_COLOR)
                painter.setPen(pen)
                painter.drawRect(button.geometry())
            
            painter.fillRect(button.geometry(), bg_color)
            
            text = button.text()
            if text:
                pen.setColor(text_color)
                painter.setPen(pen)
                text_option = QtGui.QTextOption()
                text_option.setAlignment(QtCore.Qt.AlignCenter)
                painter.drawText(button.geometry(), text, text_option)
                
        if not self._box_select_rect.isNull():
            pen.setWidth(1)
            pen.setColor(self._box_select_color)
            painter.setPen(pen)
            painter.drawRect(self._box_select_rect)


class PickerTab(QtWidgets.QWidget):
    
    title_changed = QtCore.Signal(QtWidgets.QWidget, str)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        
        self._canvas = PickerCanvas(self)
        self._canvas.title_changed.connect(self.on_title_changed)
        
        self.mouseDown = False
        
        self.create_actions()
        
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
        
    def create_actions(self):
        self.add_btn_action = QAction("Add Button")
        self.add_btn_action.triggered.connect(self._canvas.add_button)
        
        self.dup_btn_action = QAction("Duplicate Button")
        self.dup_btn_action.triggered.connect(self._canvas.duplicate_buttons)
        
        self.delete_btn_action = QAction("Delete Button")
        self.delete_btn_action.triggered.connect(self.confirm_delete)
        
    def edit_mode_enabled(self):
        return PickerEditorWindow.edit_mode_enabled
        
    def canvas(self):
        return self._canvas
        
    def confirm_delete(self):
        if self._canvas.editable_button_count() > 0:
            confirm = QtWidgets.QMessageBox.question(self, "Confirm Delete", "Are you sure you would like to delete?")
            if confirm == QtWidgets.QMessageBox.Yes:
                self._canvas.delete_buttons()
        
    def on_title_changed(self, title):
        self.title_changed.emit(self, title)

    def keyPressEvent(self, e):
        pass

    def mousePressEvent(self, e):
        if not self.mouseDown:
            self.mouseDown = True
            self.mouseButton = e.button()
            self.mouseModifiers = e.modifiers()
            self.mouseStartPos = PickerHelpers.mouse_pos_from_event(e)
            
            if self.edit_mode_enabled() and self.mouseButton == QtCore.Qt.MouseButton.LeftButton:
                self._canvas.set_box_select_color(PickerCanvas.BOX_SELECT_EDIT_COLOR)
            else:
                self._canvas.set_box_select_color(PickerCanvas.BOX_SELECT_COLOR)

    def mouseReleaseEvent(self, e):
        if self.mouseButton == e.button():
            self.mouseDown = False
            
            pos = PickerHelpers.mouse_pos_from_event(e)
            canvas_pos = self._canvas.mapFromParent(pos)
            
            if self.mouseButton == QtCore.Qt.LeftButton:
                if self.edit_mode_enabled():
                    self._canvas.update_buttons_to_edit(canvas_pos, self.mouseModifiers)
                else:
                    self._canvas.trigger_selected_buttons(canvas_pos, self.mouseModifiers)
            elif self.mouseButton == QtCore.Qt.MiddleButton:
                if self.edit_mode_enabled():
                    self._canvas.trigger_selected_buttons(canvas_pos, self.mouseModifiers)
                
            self._canvas.reset_box_select_rect()

    def mouseMoveEvent(self, e):
        mouse_pos = PickerHelpers.mouse_pos_from_event(e)
        
        if self.mouseButton == QtCore.Qt.LeftButton or (self.mouseButton == QtCore.Qt.MiddleButton and self.edit_mode_enabled()):
            top_left = self._canvas.mapFromParent(self.mouseStartPos)
            bottom_right = self._canvas.mapFromParent(mouse_pos)
            self._canvas.set_box_select_rect(QtCore.QRectF(top_left, bottom_right))

    def wheelEvent(self, e):
        pass

    def show_context_menu(self, pos):
        if QtGui.QGuiApplication.keyboardModifiers() != QtCore.Qt.KeyboardModifier.NoModifier:
            return
            
        if not self.edit_mode_enabled():
            return
            
        canvas_pos = self._canvas.mapFromParent(pos)
        button_under_mouse = self._canvas.find_button_at_pos(canvas_pos)
        
        self.add_btn_action.setData(canvas_pos)
        self.dup_btn_action.setData(canvas_pos)
        
        context_menu = QtWidgets.QMenu()
        
        if not button_under_mouse:
            context_menu.addAction(self.add_btn_action)
            if self._canvas.editable_button_count() > 0:
                context_menu.addSeparator()
                context_menu.addAction(self.dup_btn_action)
                
        elif button_under_mouse.edit_enabled():
            context_menu.addAction(self.delete_btn_action)
            
        if PickerHelpers.is_qt_5():
            context_menu.exec_(self.mapToGlobal(pos))
        else:
            context_menu.exec(self.mapToGlobal(pos))


class PickerUI(QtWidgets.QWidget):

    FILE_FILTERS = "JSON (*.json);;All Files (*.*)"
    
    
    def __init__(self, parent=PickerHelpers.maya_main_window()):
        super().__init__(parent)

        self.setWindowTitle("Zurbrigg Picker")
        self.setMinimumSize(256, 256)

        self.setWindowFlags(QtCore.Qt.Window)

        # On macOS make the window a Tool to keep it on top of Maya
        if sys.platform == "darwin":
            self.setWindowFlag(QtCore.Qt.Tool, True)

        self._script_job_number = -1
        self._selected_filter = None

        self.create_widgets()
        self.create_menus()
        self.create_layout()
        self.create_connections()
        
        self.update_namespace_cmb_state()

        self.editor_window = PickerEditorWindow(self)
        
        # self.new_tab()

    def create_widgets(self):
        self.tab_widget = QtWidgets.QTabWidget()
        self.tab_widget.setMovable(True)
        self.tab_widget.tabBar().setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        
        self.namespace_cmb = QtWidgets.QComboBox(self)
        self.namespace_cmb.setStyleSheet("background-color: #3f3f3f")
        self.namespace_cmb.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToContents)
        self.namespace_cmb.addItem("<none>")

    def create_menus(self):
        self.menu_bar = QtWidgets.QMenuBar()
        self.file_menu = self.menu_bar.addMenu("File")

        self.new_tab_action = self.file_menu.addAction("New")
        self.new_tab_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.New))
        self.file_menu.addSeparator()

        self.open_tab_action = self.file_menu.addAction("Open")
        self.open_tab_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.Open))

        self.save_action_action = self.file_menu.addAction("Save")
        self.save_action_action.setShortcut(QtGui.QKeySequence(QtGui.QKeySequence.Save))
        
        self.save_as_action_action = self.file_menu.addAction("Save As...")
        self.save_as_action_action.setShortcut(QtGui.QKeySequence("Ctrl+Shift+S"))
        self.file_menu.addSeparator()
        
        self.close_tab_action = self.file_menu.addAction("Close Tab")
        self.close_tab_action.setShortcut(QtGui.QKeySequence("Ctrl+Shift+C"))

        self.edit_menu = self.menu_bar.addMenu("Edit")
        
        self.toggle_editor_action = self.edit_menu.addAction("Edit Mode")
        self.toggle_editor_action.setShortcut(QtGui.QKeySequence("Ctrl+E"))
        self.toggle_editor_action.setCheckable(True)
        self.edit_menu.addSeparator()
        
        self.resize_to_canvas_action = self.edit_menu.addAction("Resize to Canvas")
        self.resize_to_canvas_action.setShortcut(QtGui.QKeySequence("Ctrl+R"))
        
        self.reset_pan_and_zoom_action = self.edit_menu.addAction("Reset Pan/Zoom")
        self.reset_pan_and_zoom_action.setShortcut(QtGui.QKeySequence("Ctrl+\\"))

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setMenuBar(self.menu_bar)
        main_layout.addWidget(self.tab_widget)

    def create_connections(self):
        self.new_tab_action.triggered.connect(self.new_tab)
        self.open_tab_action.triggered.connect(self.open_tab)
        self.save_action_action.triggered.connect(self.save_tab)
        self.save_as_action_action.triggered.connect(self.save_tab_as)
        self.close_tab_action.triggered.connect(self.close_tab)

        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        
        self.namespace_cmb.currentTextChanged.connect(self.on_namespace_changed)

        self.toggle_editor_action.toggled.connect(self.set_editor_visible)
        self.resize_to_canvas_action.triggered.connect(self.resize_to_canvas)
        self.reset_pan_and_zoom_action.triggered.connect(self.reset_pan_and_zoom)

        self.edit_menu.aboutToShow.connect(self.update_edit_menu)

    def current_index(self):
        return self.tab_widget.currentIndex()

    def current_tab(self):
        index = self.current_index()
        if index >= 0:
            picker_tab = self.tab_widget.widget(index)
            return picker_tab
            
        return None
            
    def current_canvas(self):
        picker_tab = self.current_tab()
        if picker_tab:
            return picker_tab.canvas()
            
        return None

    def new_tab(self, checked=False, show_editor=True):
        picker_tab = PickerTab()
        picker_tab.title_changed.connect(self.set_tab_name)
        
        index = self.tab_widget.addTab(picker_tab, "Untitled")
        self.tab_widget.setCurrentIndex(index)
        
        if self.tab_widget.count() == 1:
            self.resize_to_canvas()
            
        if show_editor:
            self.set_editor_visible(True)
        
        return index

    def open_tab(self, file_path):
        starting_tab_count = self.tab_widget.count()
        
        if file_path:
            file_paths = [file_path]
        else:
            file_paths, self._selected_filter = QtWidgets.QFileDialog.getOpenFileNames(self, "Select a File", "", PickerUI.FILE_FILTERS, self._selected_filter)
        
        for file_path in file_paths:
            index = self.new_tab(show_editor=False)
            
            picker_tab = self.tab_widget.widget(index)
            if picker_tab:
                tab_name = picker_tab.canvas().open(file_path)
                if tab_name:
                    self.tab_widget.setTabText(index, tab_name)
                    
        if starting_tab_count < self.tab_widget.count():
            if starting_tab_count == 0:
                self.resize_to_canvas()

    def save_tab(self, file_path=None):
        canvas= self.current_canvas()
        if canvas:
            if not file_path:
                file_path = canvas.file_path()
                if not file_path:
                    self.save_tab_as()
                    return
                    
            if canvas.save(file_path):
                print("Tab saved {0}".format(file_path))
            
    def save_tab_as(self):
        file_path, self._selected_filter = QtWidgets.QFileDialog.getSaveFileName(self, "Save File As", "", self.FILE_FILTERS, self._selected_filter)
        if file_path:
            self.save_tab(file_path)
            
    def close_tab(self):
        self.tab_widget.removeTab(self.current_index())

    def update_edit_menu(self):
        if self.editor_window:
            self.toggle_editor_action.setChecked(self.editor_window.isVisible())
        else:
            self.toggle_editor_action.setChecked(False)

    def set_editor_visible(self, visible):
        if visible:
            self.editor_window.show()
        else:
            self.editor_window.close()
            
    def resize_to_canvas(self):
        picker_tab = self.current_tab()
        if picker_tab:
            canvas = picker_tab.canvas()
            
            size_diff = canvas.size() - picker_tab.size()
            self.resize(self.size() + size_diff)
                
    def reset_pan_and_zoom(self):
        print("TODO: reset_pan_and_zoom()")

    def on_tab_changed(self, index):
        canvas = self.current_canvas()
        self.editor_window.set_canvas(canvas)
        
    def set_tab_name(self, picker_tab, name):
        index = self.tab_widget.indexOf(picker_tab)
        if index >= 0:
            self.tab_widget.setTabText(index, name)
            
    def on_namespace_changed(self, namespace):
        print("on_namespace_changed()")
        
    def update_namespace_cmb_state(self):
        x = self.width() - self.namespace_cmb.width() - 10
        y = self.menu_bar.height() + self.tab_widget.tabBar().height() + 10
        self.namespace_cmb.move(x, y)
        self.namespace_cmb.raise_()
        
        self.namespace_cmb.setVisible(self.current_index() >= 0)
        
    def update_selection(self):
        canvas = self.current_canvas()
        if canvas:
            canvas.update_selection()
            
    def set_script_job_enabled(self, enabled):
        if enabled and self._script_job_number < 0:
            self._script_job_number = cmds.scriptJob(event=["SelectionChanged", partial(self.update_selection)], protected=True)
        elif not enabled and self._script_job_number >= 0:
            cmds.scriptJob(kill=self._script_job_number, force=True)
            self._script_job_number = -1

    def showEvent(self, e):
        self.set_script_job_enabled(True)
        
        self.update_namespace_cmb_state()
        
        self.resize_to_canvas()

    def closeEvent(self, e):
        self.set_script_job_enabled(False)
        
        if self.editor_window and self.editor_window.isVisible():
            self.editor_window.close()
            
    def resizeEvent(self, e):
        self.update_namespace_cmb_state()

    def keyPressEvent(self, e):
        pass


if __name__ == "__main__":

    try:
        picker_ui_dialog.close() # pylint: disable=E0601
        picker_ui_dialog.deleteLater()
    except:
        pass

    picker_ui_dialog = PickerUI()
    picker_ui_dialog.show()
    
    
    
    
    
    
    
    
    
    
    
    
    
