import maya.cmds as cmds
import maya.api.OpenMaya as om

from cz_validation.test_cases.test_case import TestCase


class DuplicateNamesTest(TestCase):

    NAME = "Duplicate Names"
    DESCRIPTION = "Check for duplicate node names"

    PASSED_TEXT = "No duplicate node names"
    FAILED_TEXT = "Duplicate node names found"

    WARN_ON_FAILURE = False

    SELECT_ERRORS_ENABLED = True
    FIX_ENABLED = True
    CAN_RETRY_ON_FIX = False


    def __init__(self):
        super().__init__()

    def execute(self):
        transform_nodes = cmds.ls(transforms=True)
        for node in transform_nodes:
            if '|' in node:
                self._errors.append(node)

        return not self._errors

    def select_error_objs(self):
        super().select_error_objs()

    def fix_errors(self):
        super().fix_errors()

    def formatted_errors(self):
        return super().formatted_errors()



if __name__ == "__main__":
    test_case = DuplicateNamesTest()
    success = test_case.run_test()

    print(test_case.formatted_results())

    if not success and test_case.is_select_errors_enabled():
        test_case.select_error_objs()






