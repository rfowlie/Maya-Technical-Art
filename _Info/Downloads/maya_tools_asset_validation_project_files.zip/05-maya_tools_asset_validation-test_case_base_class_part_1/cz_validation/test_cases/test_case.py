import maya.cmds as cmds
import maya.api.OpenMaya as om


class TestCase(object):

    NAME = "<Test Case>"
    DESCRIPTION = "<Test Case Description>"

    PASSED_TEXT = "<Test Case Passed Test>"
    FAILED_TEXT = "<Test Case Failed Test>"

    WARN_ON_FAILURE = False

    SELECT_ERRORS_ENABLED = False
    FIX_ENABLED = False
    CAN_RETRY_ON_FIX = False


    def __init__(self):
        self.reset()

    def reset(self):
        self._run_completed = False
        self._passed = False

        self._errors = []


if __name__ == "__main__":
    test_case = TestCase()
