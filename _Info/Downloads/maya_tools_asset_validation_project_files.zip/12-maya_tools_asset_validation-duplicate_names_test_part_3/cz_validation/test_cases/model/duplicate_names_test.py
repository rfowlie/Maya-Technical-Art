import maya.cmds as cmds
import maya.api.OpenMaya as om

from cz_validation.test_cases.test_case import TestCase

from RenameTool_UI import renameTool  # https://github.com/Luca-Marri/Rename-Tool-for-Maya


class DuplicateNamesTest(TestCase):

    NAME = "Duplicate Names"
    DESCRIPTION = "Check for duplicate node names"

    PASSED_TEXT = "No duplicate node names"
    FAILED_TEXT = "Duplicate node names found"

    SELECT_ERRORS_ENABLED = True
    FIX_ENABLED = True


    def __init__(self):
        super().__init__()

    def execute(self):
        transform_nodes = cmds.ls(transforms=True)
        for node in transform_nodes:
            if '|' in node:
                self._errors.append(node)

        return not self._errors

    def select_error_objs(self):
        super().select_error_objs()

    def fix_errors(self):
        renameTool.show_dialog()


if __name__ == "__main__":
    test_case = DuplicateNamesTest()
    success = test_case.run_test()

    print(test_case.formatted_results())

    if not success:
        if test_case.is_select_errors_enabled():
            test_case.select_error_objs()

        if test_case.is_fix_errors_enabled():
            test_case.fix_errors()






