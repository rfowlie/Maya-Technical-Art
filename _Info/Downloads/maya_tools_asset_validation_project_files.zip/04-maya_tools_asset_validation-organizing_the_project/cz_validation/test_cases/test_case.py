import maya.cmds as cmds
import maya.api.OpenMaya as om


class TestCase(object):

    def __init__(self):
        print("TODO: __init__()")


if __name__ == "__main__":
    test_case = TestCase()
