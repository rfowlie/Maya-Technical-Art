import maya.cmds as cmds
import maya.api.OpenMaya as om

from cz_validation.test_cases.test_case import TestCase


class TemplateTest(TestCase):

    NAME = "<Template Test>"
    DESCRIPTION = "<Template Test Description>"

    PASSED_TEXT = "<Template Test Passed Text>"
    FAILED_TEXT = "<Template Test Failed Text>"

    WARN_ON_FAILURE = False

    SELECT_ERRORS_ENABLED = False
    FIX_ENABLED = False
    CAN_RETRY_ON_FIX = False


    def __init__(self):
        super().__init__()

    def execute(self):
        return super().execute()

    def select_error_objs(self):
        super().select_error_objs()

    def fix_errors(self):
        super().fix_errors()

    def formatted_errors(self):
        return super().formatted_errors()



if __name__ == "__main__":
    test_case = TemplateTest()
    success = test_case.run_test()

    print(test_case.formatted_results())

    if not success:
        if test_case.is_select_errors_enabled():
            test_case.select_error_objs()

        if test_case.is_fix_errors_enabled():
            test_case.fix_errors()




