import maya.cmds as cmds
import maya.api.OpenMaya as om

from cz_validation.test_cases.test_case import TestCase


class EmptyMeshTest(TestCase):

    NAME = "Empty meshes"
    DESCRIPTION = "Check for meshes with zero vertices"

    PASSED_TEXT = "No empty meshes"
    FAILED_TEXT = "Empty meshes found"

    SELECT_ERRORS_ENABLED = True
    FIX_ENABLED = True
    CAN_RETRY_ON_FIX = True


    def __init__(self):
        super().__init__()

    def execute(self):
        return super().execute()

    def fix_errors(self):
        super().fix_errors()


if __name__ == "__main__":
    test_case = EmptyMeshTest()
    success = test_case.run_test()

    print(test_case.formatted_results())

    if not success:
        if test_case.is_select_errors_enabled():
            test_case.select_error_objs()

        if test_case.is_fix_errors_enabled():
            test_case.fix_errors()




