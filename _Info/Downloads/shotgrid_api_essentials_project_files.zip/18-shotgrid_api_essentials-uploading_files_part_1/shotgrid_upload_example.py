from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="4liyzhgqnnbgAqwju*nqhjyof")

entity_id = 1184  # Shot ID for bunny_010_0005
file_path = "E:/Downloads/temp/bunny_010_0005_Storyboard.mov"

result = sg.upload("Shot", entity_id, file_path, field_name="sg_storyboard", display_name="Approved SB")
print(result)
