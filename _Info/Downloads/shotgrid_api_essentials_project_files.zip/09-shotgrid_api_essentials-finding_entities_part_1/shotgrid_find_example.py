from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

filters = [
    ["sg_status", "is", "Active"]
]
fields = ["name", "sg_type", "sg_status"]

projects = sg.find("Project", filters, fields=fields)
for project in projects:
    pprint(project)

