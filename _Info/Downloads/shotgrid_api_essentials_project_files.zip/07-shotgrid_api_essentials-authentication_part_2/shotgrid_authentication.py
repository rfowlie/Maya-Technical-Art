import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="script_name", api_key="api_key")

# for key, value in sg.info().items():
#     print(f"{key}: {value}")

try:
    print("Validating credentials")
    sg.get_session_token()
except:
    raise

print("Credentials validated")

filter=[["sg_status", "is", "Active"]]
result = sg.find("Project", filters=filter, fields=["name"])
print("Projects:")
for item in result:
    print(item)
