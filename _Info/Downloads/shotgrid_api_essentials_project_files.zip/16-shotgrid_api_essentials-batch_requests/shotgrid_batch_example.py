from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

project = {"type": "Project", "id": 70}

# batch_requests = [
#     {"request_type": "create", "entity_type": "Asset", "data": {"project": project, "code": "Tony"}},
#     {"request_type": "create", "entity_type": "Asset", "data": {"project": project, "code": "Terry"}},
#     {"request_type": "create", "entity_type": "Asset", "data": {"project": project, "code": "Susan"}},
# ]

batch_requests = [
    {"request_type": "update", "entity_type": "Asset", "entity_id": 1416, "data": {"code": "Toni"}},
    {"request_type": "delete", "entity_type": "Asset", "entity_id": 1417}
]

results = sg.batch(batch_requests)
pprint(results)
