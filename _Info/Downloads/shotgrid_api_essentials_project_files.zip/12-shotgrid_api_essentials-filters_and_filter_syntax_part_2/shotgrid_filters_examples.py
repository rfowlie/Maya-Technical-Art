from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

filters = [
    ["project", "is", {"type": "Project", "id": 70}],
    #["sg_sequence", "is", {"type": "Sequence", "id": 37}],
    #["sg_cut_duration", "less_than", 100],
    ["code", "ends_with", "0010"]
]

fields = ["code", "sg_sequence", "sg_cut_duration"]

projects = sg.find("Shot", filters, fields=fields)
for project in projects:
    pprint(project)
