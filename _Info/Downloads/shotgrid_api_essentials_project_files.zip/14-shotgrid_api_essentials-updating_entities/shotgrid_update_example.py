from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

assets = [
    {"type": "Asset", "id": 1228},  # Blue Jay
    {"type": "Asset", "id": 1230},  # Bunny
]

data = {
    "assets": assets
}

results = sg.update("Shot", 1184, data, multi_entity_update_modes={"assets": "set"})
pprint(results)