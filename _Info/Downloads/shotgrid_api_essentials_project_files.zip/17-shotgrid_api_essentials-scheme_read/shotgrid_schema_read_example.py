from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

project = {"type": "Project", "id": 70}

# results = sg.schema_entity_read(project_entity=project)
# pprint(results)

results = sg.schema_field_read("Shot", field_name="assets", project_entity=project)
# for field in results.keys():
#     print(field)

pprint(results)