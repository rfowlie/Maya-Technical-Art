from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

# filters = [
#     ["sg_type", "is", "Feature"],
#     ["sg_type", "is", "Game"],
#     # ["sg_status", "is", "Active"]
# ]

filters = [
    ["sg_status", "is", "Active"],
    {
        "filter_operator": "any",
        "filters": [
            ["sg_type", "is", "Feature"],
            ["sg_type", "is", "Game"]
        ]
    }

]

fields = ["name", "sg_type", "sg_status"]

projects = sg.find("Project", filters, fields=fields, filter_operator="all")
for project in projects:
    pprint(project)
