from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

filters = [
    ["sg_status", "is", "Active"]
]
fields = ["name", "sg_type", "sg_status"]

order = [
    {"field_name": "sg_type", "direction": "asc"},
    {"field_name": "name", "direction": "asc"}
]

projects = sg.find("Project", filters, fields=fields, order=order, limit=2, page=1)
for project in projects:
    pprint(project)

# project = sg.find_one("Project", filters=[["id", "is", 70]], fields=fields)
# pprint(project)
