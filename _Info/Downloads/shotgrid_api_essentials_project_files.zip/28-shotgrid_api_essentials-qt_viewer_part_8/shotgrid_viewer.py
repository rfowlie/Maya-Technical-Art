import sys
import urllib

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:
    from PySide2 import QtCore, QtGui, QtWidgets

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"


class LoginWidget(QtWidgets.QDialog):

    login_requested = QtCore.Signal(str, str)

    def __init__(self, parent=None):
        super(LoginWidget, self).__init__(parent=None)

        self.setWindowTitle("ShotGrid Login")
        self.setWindowFlag(QtCore.Qt.WindowContextHelpButtonHint, False)
        self.setModal(True)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.username_le = QtWidgets.QLineEdit()
        self.username_le.setPlaceholderText("Username")
        
        self.password_le = QtWidgets.QLineEdit()
        self.password_le.setPlaceholderText("Password")
        self.password_le.setEchoMode(QtWidgets.QLineEdit.Password)
        
        self.login_btn = QtWidgets.QPushButton("Login")

        self.invalid_pwd_label = QtWidgets.QLabel("Invalid Username/Password")
        self.invalid_pwd_label.setStyleSheet("QLabel {color: red}")
        self.invalid_pwd_label.setVisible(False)

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(self.username_le)
        main_layout.addWidget(self.password_le)
        main_layout.addWidget(self.login_btn)
        main_layout.addWidget(self.invalid_pwd_label)

    def create_connections(self):
        self.login_btn.clicked.connect(self.on_login)

    def invalid_credentials(self):
        self.invalid_pwd_label.setVisible(True)

    def on_login(self):
        username = self.username_le.text()
        password = self.password_le.text()

        if username and password:
            self.login_requested.emit(self.username_le.text(), self.password_le.text())


class EntityWidget(QtWidgets.QWidget):

    update_requested = QtCore.Signal(str, int, dict)

    def __init__(self):
        super(EntityWidget, self).__init__(parent=None)

        self.entity = None

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.preview_image_label = QtWidgets.QLabel()
        self.preview_image_label.setFixedSize(232, 130)

        self.code_label = QtWidgets.QLabel("")
        self.code_le = QtWidgets.QLineEdit()
        self.code_le.setReadOnly(True)

        self.other_details_label = QtWidgets.QLabel("")
        self.other_details_le = QtWidgets.QLineEdit()
        self.other_details_le.setReadOnly(True)

        self.status_label = QtWidgets.QLabel("Status:")
        self.status_le = QtWidgets.QLineEdit()
        self.status_le.setReadOnly(True)

        self.description_plaintext = QtWidgets.QPlainTextEdit()
        self.description_plaintext.setFixedHeight(100)

        self.update_btn = QtWidgets.QPushButton("Update")
        self.revert_btn = QtWidgets.QPushButton("Revert")

    def create_layout(self):
        details_layout = QtWidgets.QFormLayout()
        details_layout.addRow(self.code_label, self.code_le)
        details_layout.addRow(self.other_details_label, self.other_details_le)
        details_layout.addRow(self.status_label, self.status_le)

        top_layout = QtWidgets.QHBoxLayout()
        top_layout.addWidget(self.preview_image_label)
        top_layout.addLayout(details_layout)

        update_layout = QtWidgets.QHBoxLayout()
        update_layout.addStretch()
        update_layout.addWidget(self.update_btn)
        update_layout.addWidget(self.revert_btn)
        update_layout.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addLayout(top_layout)
        main_layout.addWidget(QtWidgets.QLabel("Description:"))
        main_layout.addWidget(self.description_plaintext)
        main_layout.addLayout(update_layout)
        main_layout.addStretch()

    def create_connections(self):
        pass


class ShotGridUi(QtWidgets.QWidget):

    def __init__(self):
        super(ShotGridUi, self).__init__(parent=None)

        self.setWindowTitle("ShotGrid Viewer")
        self.setMinimumSize(800, 480)

        self.shotgrid = None
        self.username = ""

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.projects_cmb = QtWidgets.QComboBox()
        self.projects_cmb.setMinimumWidth(200)
        self.projects_cmb.addItem("<Not Set>")

        self.shotgrid_tree_wdg = QtWidgets.QTreeWidget()
        self.shotgrid_tree_wdg.setFixedWidth(200)
        self.shotgrid_tree_wdg.setHeaderHidden(True)

        self.no_selection_wdg = QtWidgets.QWidget()
        self.entity_wdg = EntityWidget()

        self.stacked_wdg = QtWidgets.QStackedWidget()
        self.stacked_wdg.addWidget(self.no_selection_wdg)
        self.stacked_wdg.addWidget(self.entity_wdg)

        self.login_wdg = LoginWidget(self)

    def create_layout(self):
        project_layout = QtWidgets.QHBoxLayout()
        project_layout.setContentsMargins(0, 0, 0, 0)
        project_layout.addWidget(QtWidgets.QLabel("Project:"))
        project_layout.addWidget(self.projects_cmb)
        project_layout.addStretch()

        entity_layout = QtWidgets.QHBoxLayout()
        entity_layout.addWidget(self.shotgrid_tree_wdg)
        entity_layout.addWidget(self.stacked_wdg)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addLayout(project_layout)
        main_layout.addLayout(entity_layout)

    def create_connections(self):
        self.login_wdg.login_requested.connect(self.do_login)

        self.projects_cmb.currentIndexChanged.connect(self.on_project_changed)

        self.shotgrid_tree_wdg.itemExpanded.connect(self.on_entity_type_expanded)

    def refresh_projects(self):
        self.projects_cmb.clear()

        projects = self.get_projects()
        if projects:
            for project in projects:
                self.projects_cmb.addItem(project["name"], project["id"])

    def current_project_id(self):
        return self.projects_cmb.currentData()

    def on_project_changed(self):
        self.shotgrid_tree_wdg.clear()

        for top_level_text in ["Tasks", "Assets", "Shots"]:
            item = self.create_entity_type_item(top_level_text, {"type": top_level_text})
            self.shotgrid_tree_wdg.addTopLevelItem(item)

        self.stacked_wdg.setCurrentIndex(0)

    def get_projects(self):
        filters=[["sg_status", "is", "Active"], ["sg_type", "is", "Feature"]]
        return self.shotgrid.find("Project", filters=filters, fields=["name"])
    
    def get_asset_types(self):
        asset_types = self.shotgrid.schema_field_read("Asset", "sg_asset_type")
        return sorted(asset_types["sg_asset_type"]["properties"]["valid_values"]["value"])
    
    def get_assets(self, asset_type):
        filters = [
            ["project", "is", {"type": "Project", "id": self.current_project_id()}],
            ["sg_asset_type", "is", asset_type]
        ]
        fields = ["code"]
        order = [{"field_name" : "code", "direction": "asc"}]

        return self.shotgrid.find("Asset", filters, fields=fields, order=order)
    
    def get_sequences(self):
        filters = [
            ["project", "is", {"type": "Project", "id": self.current_project_id()}]
        ]
        fields = ["code"]
        order = [{"field_name" : "code", "direction": "asc"}]

        return self.shotgrid.find("Sequence", filters, fields=fields, order=order)
    
    def get_shots(self, sequence_id):
        filters = [
            ["project", "is", {"type": "Project", "id": self.current_project_id()}],
            ["sg_sequence", "is", {"type": "Sequence", "id": sequence_id}]
        ]
        fields = ["code"]
        order = [{"field_name" : "code", "direction": "asc"}]

        return self.shotgrid.find("Shot", filters, fields=fields, order=order)
    
    def create_entity_type_item(self, label, data, add_child=True):
        item = QtWidgets.QTreeWidgetItem([label])
        item.setFlags(QtCore.Qt.ItemIsEnabled)
        item.setData(0, QtCore.Qt.UserRole, data)
        if add_child:
            item.addChild(QtWidgets.QTreeWidgetItem(["<empty>"]))

        return item
    
    def create_entity_item(self, label, data):
        item = QtWidgets.QTreeWidgetItem([label])
        item.setData(0, QtCore.Qt.UserRole, data)
        return item
    
    def clear_child_items(self, item):
        for i in reversed(range(item.childCount())):
            item.removeChild(item.child(i))

    def on_entity_type_expanded(self, item):
        if not item.isExpanded():
            return
        
        self.clear_child_items(item)

        data = item.data(0, QtCore.Qt.UserRole)
        if not data:
            return
        
        item_to_expand = data["type"]

        if item_to_expand == "Tasks":
            asset_tasks_item = self.create_entity_type_item("Asset Tasks", None, False)
            item.addChild(asset_tasks_item)

            shot_tasks_item = self.create_entity_type_item("Shot Tasks", None, False)
            item.addChild(shot_tasks_item)

        elif item_to_expand == "Assets":
            asset_types = self.get_asset_types()
            for asset_type in asset_types:
                asset_type_item = self.create_entity_type_item(asset_type, {"type": "Asset Type"})
                item.addChild(asset_type_item)

        elif item_to_expand == "Asset Type":
            assets = self.get_assets(item.text(0))
            for asset in assets:
                asset_item = self.create_entity_item(asset["code"], asset)
                item.addChild(asset_item)

        elif item_to_expand == "Shots":
            sequences = self.get_sequences()
            for sequence in sequences:
                seq_item = self.create_entity_type_item(sequence["code"], sequence)
                item.addChild(seq_item)

        elif item_to_expand == "Sequence":
            shots = self.get_shots(data["id"])
            for shot in shots:
                shot_item = self.create_entity_item(shot["code"], shot)
                item.addChild(shot_item)

    def do_login(self, username, password):
        self.shotgrid = shotgun_api3.Shotgun(SERVER_PATH, login=username, password=password)

        human_user = self.shotgrid.authenticate_human_user(username, password)
        if not human_user:
            self.shotgrid = None
            self.login_wdg.invalid_credentials()
            return
        
        self.username = human_user["login"]
        self.user_id = human_user["id"]

        self.login_wdg.close()

        self.setWindowTitle(f"ShotGrid Viewer ({self.username})")

        self.refresh_projects()

    def showEvent(self, event):
        if not self.shotgrid:
            #self.login_wdg.show()

            # This is only for testing purposes to skip
            # the login dialog
            self.do_login("username", "password")
    

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ShotGridUi()
    window.show()

    # Enter Qt main loop (start event handling)
    try:
        app.exec() # Qt6
    except:
        app.exec_() # Qt5
