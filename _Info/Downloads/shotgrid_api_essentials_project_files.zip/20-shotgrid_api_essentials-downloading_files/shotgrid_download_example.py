from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

download_path = "E:/Downloads/temp/bunny_010_0005_Storyboard.mov"

# filters = [
#     ["id", "is", 1184]
# ]
# fields = ["sg_storyboard"]

# shot_entity = sg.find_one("Shot", filters, fields=fields)
# pprint(shot_entity)

# path = sg.download_attachment(shot_entity["sg_storyboard"], file_path=download_path)
# print(path)

filters = [
    ["attachment_links", "is", {"type": "Shot", "id": 1184}]
]
fields = ["this_file"]

attachment_entities = sg.find("Attachment", filters, fields=fields)
for attachment_entity in attachment_entities:
    pprint(attachment_entity)

path = sg.download_attachment(attachment_entities[0]["this_file"], file_path=download_path)
print(path)
