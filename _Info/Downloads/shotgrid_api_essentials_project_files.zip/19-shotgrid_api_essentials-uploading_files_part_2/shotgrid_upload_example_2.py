from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")


entity_id = 1184  # Shot ID for bunny_010_0005
file_path = "E:/Downloads/temp/bunny_010_0005.jpg"

result = sg.upload_thumbnail("Shot", entity_id, file_path)
print(result)
