import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, login="login", password="password")

# for key, value in sg.info().items():
#     print(f"{key}: {value}")

try:
    print("Validating user credentials")
    sg.get_session_token()
except:
    raise

print("User credentials validated")

filter=[["sg_status", "is", "Active"]]
projects = sg.find("Project", filters=filter, fields=["name"])
print("Projects:")
for project in projects:
    print(project)
