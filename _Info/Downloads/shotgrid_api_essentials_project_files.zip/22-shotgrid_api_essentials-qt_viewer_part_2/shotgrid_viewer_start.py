import sys
import urllib

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:
    from PySide2 import QtCore, QtGui, QtWidgets

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"


class LoginWidget(QtWidgets.QDialog):

    login_requested = QtCore.Signal(str, str)

    def __init__(self, parent=None):
        super(LoginWidget, self).__init__(parent=None)

        self.setWindowTitle("ShotGrid Login")
        self.setWindowFlag(QtCore.Qt.WindowContextHelpButtonHint, False)
        self.setModal(True)

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.username_le = QtWidgets.QLineEdit()
        self.username_le.setPlaceholderText("Username")
        
        self.password_le = QtWidgets.QLineEdit()
        self.password_le.setPlaceholderText("Password")
        self.password_le.setEchoMode(QtWidgets.QLineEdit.Password)
        
        self.login_btn = QtWidgets.QPushButton("Login")

        self.invalid_pwd_label = QtWidgets.QLabel("Invalid Username/Password")
        self.invalid_pwd_label.setStyleSheet("QLabel {color: red}")
        self.invalid_pwd_label.setVisible(False)

    def create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addWidget(self.username_le)
        main_layout.addWidget(self.password_le)
        main_layout.addWidget(self.login_btn)
        main_layout.addWidget(self.invalid_pwd_label)

    def create_connections(self):
        self.login_btn.clicked.connect(self.on_login)

    def invalid_credentials(self):
        self.invalid_pwd_label.setVisible(True)

    def on_login(self):
        username = self.username_le.text()
        password = self.password_le.text()

        if username and password:
            self.login_requested.emit(self.username_le.text(), self.password_le.text())


class EntityWidget(QtWidgets.QWidget):

    update_requested = QtCore.Signal(str, int, dict)

    def __init__(self):
        super(EntityWidget, self).__init__(parent=None)

        self.entity = None

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.preview_image_label = QtWidgets.QLabel()
        self.preview_image_label.setFixedSize(232, 130)

        self.code_label = QtWidgets.QLabel("")
        self.code_le = QtWidgets.QLineEdit()
        self.code_le.setReadOnly(True)

        self.other_details_label = QtWidgets.QLabel("")
        self.other_details_le = QtWidgets.QLineEdit()
        self.other_details_le.setReadOnly(True)

        self.status_label = QtWidgets.QLabel("Status:")
        self.status_le = QtWidgets.QLineEdit()
        self.status_le.setReadOnly(True)

        self.description_plaintext = QtWidgets.QPlainTextEdit()
        self.description_plaintext.setFixedHeight(100)

        self.update_btn = QtWidgets.QPushButton("Update")
        self.revert_btn = QtWidgets.QPushButton("Revert")

    def create_layout(self):
        details_layout = QtWidgets.QFormLayout()
        details_layout.addRow(self.code_label, self.code_le)
        details_layout.addRow(self.other_details_label, self.other_details_le)
        details_layout.addRow(self.status_label, self.status_le)

        top_layout = QtWidgets.QHBoxLayout()
        top_layout.addWidget(self.preview_image_label)
        top_layout.addLayout(details_layout)

        update_layout = QtWidgets.QHBoxLayout()
        update_layout.addStretch()
        update_layout.addWidget(self.update_btn)
        update_layout.addWidget(self.revert_btn)
        update_layout.addStretch()

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.addLayout(top_layout)
        main_layout.addWidget(QtWidgets.QLabel("Description:"))
        main_layout.addWidget(self.description_plaintext)
        main_layout.addLayout(update_layout)
        main_layout.addStretch()

    def create_connections(self):
        pass


class ShotGridUi(QtWidgets.QWidget):

    def __init__(self):
        super(ShotGridUi, self).__init__(parent=None)

        self.setWindowTitle("ShotGrid Viewer")
        self.setMinimumSize(800, 480)

        self.shotgrid = None
        self.username = ""

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.projects_cmb = QtWidgets.QComboBox()
        self.projects_cmb.setMinimumWidth(200)
        self.projects_cmb.addItem("<Not Set>")

        self.shotgrid_tree_wdg = QtWidgets.QTreeWidget()
        self.shotgrid_tree_wdg.setFixedWidth(200)
        self.shotgrid_tree_wdg.setHeaderHidden(True)

        self.no_selection_wdg = QtWidgets.QWidget()
        self.entity_wdg = EntityWidget()

        self.stacked_wdg = QtWidgets.QStackedWidget()
        self.stacked_wdg.addWidget(self.no_selection_wdg)
        self.stacked_wdg.addWidget(self.entity_wdg)

    def create_layout(self):
        project_layout = QtWidgets.QHBoxLayout()
        project_layout.setContentsMargins(0, 0, 0, 0)
        project_layout.addWidget(QtWidgets.QLabel("Project:"))
        project_layout.addWidget(self.projects_cmb)
        project_layout.addStretch()

        entity_layout = QtWidgets.QHBoxLayout()
        entity_layout.addWidget(self.shotgrid_tree_wdg)
        entity_layout.addWidget(self.stacked_wdg)

        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.addLayout(project_layout)
        main_layout.addLayout(entity_layout)

    def create_connections(self):
        pass
    

if __name__ == "__main__":
    # Create the main Qt application
    app = QtWidgets.QApplication(sys.argv)

    window = ShotGridUi()
    window.show()

    # Enter Qt main loop (start event handling)
    try:
        app.exec() # Qt6
    except:
        app.exec_() # Qt5
