from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

# data = {
#     "project": {"type": "Project", "id": 70},
#     "sg_sequence": {"type": "Sequence", "id": 23},
#     "code": "bunny_010_0005",
#     "sg_cut_in": 10,
#     "sg_cut_out": 90,
#     "sg_cut_duration": 80,
#     "image": "E:/learning/Shotgrid/bunny_010_0005.jpg"
# }

# return_fields = ["code"]

# new_entity = sg.create("Shot", data, return_fields=return_fields)
# pprint(new_entity)


data = {
    "project": {"type": "Project", "id": 70},
    "code": "Andrew",
    "sg_asset_type": "Character",
    "image": "E:/learning/Shotgrid/bunny_010_0005.jpg"
}

new_entity = sg.create("Asset", data)
pprint(new_entity)
