from pprint import pprint

import shotgun_api3

SERVER_PATH = "https://zurbrigg.shotgrid.autodesk.com"

sg = shotgun_api3.Shotgun(SERVER_PATH, script_name="test_script", api_key="api_key")

# result = sg.delete("Asset", 1413)
# pprint(result)

# result = sg.revive("Asset", 1413)
# pprint(result)

assets = sg.find("Asset", [], ["code"], retired_only=True)
for asset in assets:
    pprint(asset)
